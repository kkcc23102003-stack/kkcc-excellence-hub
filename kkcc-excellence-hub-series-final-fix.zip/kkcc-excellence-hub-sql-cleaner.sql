-- KKCC Excellence Hub SQL Cleaner
-- Run this ONLY when you want a fresh KKCC database reset.
-- It removes KKCC app tables, functions, policies and role enum.
-- It does NOT directly delete Supabase Storage files/buckets because Supabase blocks direct storage table deletion.
-- If needed, delete Storage files/buckets separately from Supabase Storage UI/API.
-- After this cleaner finishes, run kkcc-excellence-hub-one-combined.sql to recreate the full KKCC setup.

-- KKCC safe cleanup/reset SQL
-- Run this in Supabase SQL Editor if you want to remove KKCC database setup.
-- It does NOT directly delete storage.objects because Supabase blocks direct
-- storage table deletion. Delete the course-content bucket/files from the
-- Supabase Storage UI separately if you want storage fully clean.

BEGIN;

-- 1) Remove Storage policies first because they depend on public.has_role().
DROP POLICY IF EXISTS "Course content is readable" ON storage.objects;
DROP POLICY IF EXISTS "Admins read course content" ON storage.objects;
DROP POLICY IF EXISTS "Admins upload course content" ON storage.objects;
DROP POLICY IF EXISTS "Admins update course content" ON storage.objects;
DROP POLICY IF EXISTS "Admins delete course content" ON storage.objects;

-- 2) Remove the auth trigger that creates profiles.
DROP TRIGGER IF EXISTS on_auth_user_created_profile ON auth.users;

-- 3) Drop KKCC app tables. CASCADE also removes their policies/triggers/index dependencies.
DROP TABLE IF EXISTS public.admission_enquiries CASCADE;
DROP TABLE IF EXISTS public.student_doubts CASCADE;
DROP TABLE IF EXISTS public.notification_reads CASCADE;
DROP TABLE IF EXISTS public.notifications CASCADE;
DROP TABLE IF EXISTS public.test_questions CASCADE;
DROP TABLE IF EXISTS public.coupon_redemptions CASCADE;
DROP TABLE IF EXISTS public.coupon_codes CASCADE;
DROP TABLE IF EXISTS public.payment_transactions CASCADE;
DROP TABLE IF EXISTS public.private_settings CASCADE;
DROP TABLE IF EXISTS public.files CASCADE;
DROP TABLE IF EXISTS public.offline_access_grants CASCADE;
DROP TABLE IF EXISTS public.course_enrollments CASCADE;
DROP TABLE IF EXISTS public.coin_packages CASCADE;
DROP TABLE IF EXISTS public.coin_transactions CASCADE;
DROP TABLE IF EXISTS public.material_purchases CASCADE;
DROP TABLE IF EXISTS public.student_blocks CASCADE;
DROP TABLE IF EXISTS public.site_settings CASCADE;
DROP TABLE IF EXISTS public.profiles CASCADE;
DROP TABLE IF EXISTS public.tests CASCADE;
DROP TABLE IF EXISTS public.materials CASCADE;
DROP TABLE IF EXISTS public.lectures CASCADE;
DROP TABLE IF EXISTS public.courses CASCADE;
DROP TABLE IF EXISTS public.user_roles CASCADE;

-- 4) Drop KKCC helper functions.
DROP FUNCTION IF EXISTS public.list_public_materials(uuid) CASCADE;
DROP FUNCTION IF EXISTS public.has_my_material_purchase(uuid) CASCADE;
DROP FUNCTION IF EXISTS public.can_access_my_course(uuid) CASCADE;
DROP FUNCTION IF EXISTS public.handle_new_user_profile() CASCADE;
DROP FUNCTION IF EXISTS public.activate_offline_access_for_user(uuid, text) CASCADE;
DROP FUNCTION IF EXISTS public.redeem_coupon_for_course(text, uuid) CASCADE;
DROP FUNCTION IF EXISTS public.refresh_course_counts() CASCADE;
DROP FUNCTION IF EXISTS public.refresh_test_question_counts() CASCADE;
DROP FUNCTION IF EXISTS public.notify_admins_on_admission_enquiry() CASCADE;
DROP FUNCTION IF EXISTS public.claim_admin() CASCADE;
DROP FUNCTION IF EXISTS public.spend_23kaat_for_material(uuid) CASCADE;
DROP FUNCTION IF EXISTS public.get_my_material_access_url(uuid) CASCADE;
DROP FUNCTION IF EXISTS public.spend_23kaat_for_course(uuid) CASCADE;
DROP FUNCTION IF EXISTS public.grant_23kaat_to_user(uuid, integer, text, text, uuid) CASCADE;
DROP FUNCTION IF EXISTS public.get_23kaat_balance(uuid) CASCADE;
DROP FUNCTION IF EXISTS public.get_my_block_status() CASCADE;
DROP FUNCTION IF EXISTS public.is_user_blocked(uuid) CASCADE;
DROP FUNCTION IF EXISTS public.update_updated_at_column() CASCADE;

-- has_role() uses app_role in the function signature, so drop it only if the enum exists.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_type t
    JOIN pg_namespace n ON n.oid = t.typnamespace
    WHERE t.typname = 'app_role' AND n.nspname = 'public'
  ) THEN
    EXECUTE 'DROP FUNCTION IF EXISTS public.has_role(uuid, public.app_role) CASCADE';
  END IF;
END;
$$;

-- 5) Drop role enum last.
DROP TYPE IF EXISTS public.app_role CASCADE;

COMMIT;

SELECT 'KKCC database cleanup complete. If needed, delete course-content bucket/files from Supabase Storage UI separately.' AS status;
