import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { DB as Database, SyllabusNodeRow } from "@/integrations/supabase/db";
import type { SupabaseClient } from "@supabase/supabase-js";

async function assertAdmin(context: { supabase: SupabaseClient<Database>; userId: string }) {
  const { data, error } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "admin",
  });
  if (error || !data) throw new Error("Forbidden — admin access required");
}

export type ParsedSyllabusNode = { subject: string; chapter: string; topic: string };

export function parseSyllabusText(raw: string): ParsedSyllabusNode[] {
  const rows: ParsedSyllabusNode[] = [];
  let subject = "";
  let chapter = "";
  for (const original of raw.split(/\r?\n/)) {
    const line = original.replace(/^\s*[-*•]\s*/, "").trim();
    if (!line) continue;
    const path = line.split(/\s*>\s*/).map((x) => x.trim()).filter(Boolean);
    if (path.length >= 3) {
      rows.push({ subject: path[0]!, chapter: path[1]!, topic: path.slice(2).join(" > ") });
      continue;
    }
    const subjectMatch = line.match(/^subject\s*:\s*(.+)$/i);
    if (subjectMatch) { subject = subjectMatch[1]!.trim(); chapter = ""; continue; }
    const chapterMatch = line.match(/^(?:chapter|ch\.?|unit)\s*(?:\d+\s*[-:.]\s*)?(.+)$/i);
    if (chapterMatch) { chapter = chapterMatch[1]!.trim(); continue; }
    const topicMatch = line.match(/^(?:topic)\s*(?:\d+\s*[-:.]\s*)?(.+)$/i);
    if (topicMatch && subject && chapter) {
      rows.push({ subject, chapter, topic: topicMatch[1]!.trim() });
      continue;
    }
    // A plain line after a chapter is treated as a topic; a plain line before any
    // chapter becomes the subject. This keeps the builder friendly to copied syllabi.
    if (subject && chapter) rows.push({ subject, chapter, topic: line });
    else if (!subject) subject = line;
  }
  const seen = new Set<string>();
  return rows.filter((row) => {
    const key = `${row.subject}\u0000${row.chapter}\u0000${row.topic}`.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

export const listSyllabus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const { data, error } = await context.supabase
      .from("syllabus_nodes")
      .select("*")
      .order("sort_order", { ascending: true })
      .order("name", { ascending: true });
    if (error) throw new Error(error.message);
    return (data ?? []) as SyllabusNodeRow[];
  });

const saveSchema = z.object({ rows: z.array(z.object({ subject: z.string().trim().min(1), chapter: z.string().trim().min(1), topic: z.string().trim().min(1) })).max(10000) });

export const replaceSyllabus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => saveSchema.parse(input))
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const subjects = [...new Set(data.rows.map((r) => r.subject))];
    const chapters = new Map<string, string>();
    const topics = new Map<string, string>();
    for (const row of data.rows) {
      chapters.set(`${row.subject}\u0000${row.chapter}`, row.chapter);
      topics.set(`${row.subject}\u0000${row.chapter}\u0000${row.topic}`, row.topic);
    }
    const { data: existing, error: readError } = await context.supabase.from("syllabus_nodes").select("id");
    if (readError) throw new Error(readError.message);
    if ((existing ?? []).length) {
      const { error } = await context.supabase.from("syllabus_nodes").delete().not("id", "is", null);
      if (error) throw new Error(error.message);
    }
    const subjectIds = new Map<string, string>();
    for (let i = 0; i < subjects.length; i++) {
      const { data: node, error } = await context.supabase.from("syllabus_nodes").insert({ node_type: "subject", name: subjects[i]!, sort_order: i }).select().single();
      if (error) throw new Error(error.message);
      subjectIds.set(subjects[i]!, node.id);
    }
    const chapterIds = new Map<string, string>();
    let order = 0;
    for (const [key, name] of chapters) {
      const subject = key.split("\u0000")[0]!;
      const { data: node, error } = await context.supabase.from("syllabus_nodes").insert({ parent_id: subjectIds.get(subject)!, node_type: "chapter", name, sort_order: order++ }).select().single();
      if (error) throw new Error(error.message);
      chapterIds.set(key, node.id);
    }
    order = 0;
    for (const [key, name] of topics) {
      const [subject, chapter] = key.split("\u0000");
      const { data: node, error } = await context.supabase.from("syllabus_nodes").insert({ parent_id: chapterIds.get(`${subject}\u0000${chapter}`)!, node_type: "topic", name, sort_order: order++ }).select().single();
      if (error) throw new Error(error.message);
    }
    return { subjects: subjects.length, chapters: chapters.size, topics: topics.size };
  });
