import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { BookOpen, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { SiteLayout, PageHeader } from "@/components/kkcc/site-layout";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { listSyllabus, parseSyllabusText, replaceSyllabus } from "@/lib/syllabus.functions";

export const Route = createFileRoute("/_authenticated/admin/syllabus")({ component: SyllabusAdmin });

function SyllabusAdmin() {
  const qc = useQueryClient();
  const list = useServerFn(listSyllabus);
  const replace = useServerFn(replaceSyllabus);
  const [raw, setRaw] = useState(`Subject: Science\nChapter 1 - Life Processes\nNutrition\nRespiration\n\nChapter 2 - Control and Coordination\nNervous System\nHormones`);
  const parsed = useMemo(() => parseSyllabusText(raw), [raw]);
  const current = useQuery({ queryKey: ["admin", "syllabus"], queryFn: () => list(), retry: false });
  const save = useMutation({
    mutationFn: () => replace({ data: { rows: parsed } }),
    onSuccess: (r) => { toast.success(`${r.subjects} subjects, ${r.chapters} chapters and ${r.topics} topics saved`); void qc.invalidateQueries({ queryKey: ["admin", "syllabus"] }); },
    onError: (e: Error) => toast.error(e.message),
  });
  const subjectCount = new Set(parsed.map((r) => r.subject)).size;
  const chapterCount = new Set(parsed.map((r) => `${r.subject}\u0000${r.chapter}`)).size;
  return <SiteLayout>
    <PageHeader eyebrow="Admin panel" title="Syllabus Builder" description="Paste your full syllabus once. KKCC converts it into Subject → Chapter → Topic and makes it available to Test Builder." />
    <div className="mx-auto w-full max-w-6xl space-y-5 px-4 py-10 sm:px-6">
      <div className="flex flex-wrap justify-end gap-2"><Button asChild variant="outline" className="rounded-full"><Link to="/admin/tests">Test Builder</Link></Button><Button asChild variant="outline" className="rounded-full"><Link to="/admin/storage">Storage</Link></Button></div>
      <div className="grid gap-5 lg:grid-cols-[1.1fr_.9fr]">
        <section className="surface-panel p-5"><div className="flex items-center gap-2"><BookOpen className="h-5 w-5 text-primary"/><h2 className="font-bold">Paste syllabus</h2></div><p className="mt-2 text-sm text-muted-foreground">Supported: Subject:, Chapter:, Topic: lines or Subject &gt; Chapter &gt; Topic paths. Plain lines after a chapter become topics.</p><Textarea value={raw} onChange={(e) => setRaw(e.target.value)} className="mt-4 min-h-[430px] font-mono text-sm" /><div className="mt-4 flex items-center justify-between gap-3"><div className="flex flex-wrap gap-2"><Badge>{subjectCount} subjects</Badge><Badge>{chapterCount} chapters</Badge><Badge>{parsed.length} topics</Badge></div><Button className="rounded-full" disabled={!parsed.length || save.isPending} onClick={() => save.mutate()}><Sparkles className="mr-2 h-4 w-4"/>Generate syllabus</Button></div></section>
        <section className="surface-panel p-5"><h2 className="font-bold">Preview</h2><div className="mt-4 max-h-[500px] space-y-4 overflow-auto">{[...new Set(parsed.map(r=>r.subject))].map(subject => <div key={subject}><h3 className="font-semibold text-primary">{subject}</h3>{[...new Set(parsed.filter(r=>r.subject===subject).map(r=>r.chapter))].map(ch => <div key={ch} className="mt-2 pl-4"><div className="font-medium">{ch}</div><ul className="ml-4 mt-1 list-disc text-sm text-muted-foreground">{parsed.filter(r=>r.subject===subject && r.chapter===ch).map(r=><li key={r.topic}>{r.topic}</li>)}</ul></div>)}</div>)}</div><div className="mt-5 border-t pt-4 text-xs text-muted-foreground">Current saved nodes: {current.data?.length ?? 0}. Saving replaces the syllabus tree only; it does not delete courses, tests or questions.</div></section>
      </div>
    </div>
  </SiteLayout>;
}
