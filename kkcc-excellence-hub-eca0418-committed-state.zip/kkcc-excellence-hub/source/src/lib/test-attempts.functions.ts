import { randomUUID } from "node:crypto";
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { buildSelectedPaper, learningPlan, resolveTestExam, unwrap } from "@/lib/learning.server";
import { saveAttemptPaper, getAttemptPaper, type AttemptPaper } from "@/lib/attempt-papers.server";
import { gradePaper, publicQuestions } from "@/lib/test-scoring";
import type { LearningAttemptRow, LearningAttemptView } from "@/integrations/supabase/db";

const selection = z.object({
  request_id: z.string().uuid().optional(),
  test_id: z.string().uuid().optional(),
  series_id: z.string().max(200).optional(),
  subject: z.string().min(1).max(160),
  chapter: z.string().min(1).max(240),
});
const attemptId = z.object({ attempt_id: z.string().uuid() });
const responses = z
  .record(z.string().max(300), z.number().int().min(0).max(5))
  .refine((values) => Object.keys(values).length <= 1000, "Too many answers.");
const answerMap = (value: unknown) => responses.parse(value ?? {});
function attemptView(row: LearningAttemptRow, paper: AttemptPaper): LearningAttemptView {
  return {
    ...row,
    exam: resolveTestExam(paper.test),
    subject: paper.selection.subject,
    chapter: paper.selection.chapter,
  };
}

export const startLearningAttempt = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => selection.parse(input))
  .handler(async ({ context, data }) => {
    const learning = await learningPlan(context, data);
    const id = data.request_id ?? randomUUID();
    const existing = unwrap(
      await context.supabase
        .from("learning_attempts")
        .select("*")
        .eq("id", id)
        .eq("user_id", context.userId)
        .maybeSingle(),
    );
    if (existing) {
      const saved = await getAttemptPaper(id);
      if (saved.user_id !== context.userId) throw new Error("Forbidden");
      if (
        existing.test_id !== (data.test_id ?? null) ||
        saved.selection.subject !== data.subject ||
        saved.selection.chapter !== data.chapter ||
        (data.series_id && existing.series_id !== learning.series_id)
      )
        throw new Error("This start request belongs to another selection.");
      return {
        attempt: attemptView(existing, saved),
        test: saved.test,
        questions:
          existing.status === "submitted" ? saved.questions : publicQuestions(saved.questions),
        server_now: new Date().toISOString(),
      };
    }
    if (!learning.access.is_admin) {
      const limit = await context.supabase
        .from("learning_attempts")
        .select("id", { count: "exact", head: true })
        .eq("user_id", context.userId)
        .gte("started_at", new Date(Date.now() - 3_600_000).toISOString());
      if (limit.error) throw new Error(limit.error.message);
      if ((limit.count ?? 0) >= 30)
        throw new Error(
          "Practice start limit reached (30/hour). Resume an existing attempt or try later.",
        );
    }
    const seed = randomUUID();
    const generated = await buildSelectedPaper(context, data, seed);
    let paper: AttemptPaper = {
      user_id: context.userId,
      seed,
      selection: {
        test_id: data.test_id ?? null,
        series_id: learning.series_id ?? null,
        subject: data.subject,
        chapter: data.chapter,
      },
      ...generated,
    };
    try {
      await saveAttemptPaper(id, paper);
    } catch (error) {
      const code = (error as NodeJS.ErrnoException).code;
      const http = (error as { $metadata?: { httpStatusCode?: number } }).$metadata?.httpStatusCode;
      if (code !== "EEXIST" && http !== 412) throw error;
      const saved = await getAttemptPaper(id);
      if (
        saved.user_id !== context.userId ||
        JSON.stringify(saved.selection) !== JSON.stringify(paper.selection)
      )
        throw new Error("Start request cannot be reused for another account or selection.");
      paper = { ...paper, ...saved };
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const durationSeconds =
      paper.test.timer_mode === "unlimited"
        ? 0
        : paper.test.timer_mode === "question"
          ? paper.test.question_timer_seconds * paper.questions.length
          : paper.test.duration_minutes * 60;
    const result = await supabaseAdmin
      .from("learning_attempts")
      .insert({
        id,
        user_id: context.userId,
        test_id: data.test_id ?? null,
        series_id: learning.series_id ?? null,
        duration_seconds: durationSeconds,
        question_timer_seconds:
          paper.test.timer_mode === "question" ? paper.test.question_timer_seconds : 0,
        question_count: paper.questions.length,
        source_refs: paper.questions.map((question) => question.id),
        status: "started",
      })
      .select("*")
      .single();
    const row =
      result.error?.code === "23505"
        ? unwrap(
            await context.supabase
              .from("learning_attempts")
              .select("*")
              .eq("id", id)
              .eq("user_id", context.userId)
              .single(),
          )
        : unwrap(result);
    if (!row)
      throw new Error("Attempt could not be recorded. Retry Start Test with the same request.");
    return {
      attempt: attemptView(row, paper),
      test: paper.test,
      questions: publicQuestions(paper.questions),
      server_now: new Date().toISOString(),
    };
  });

export const getLearningAttempt = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => attemptId.parse(input))
  .handler(async ({ context, data }) => {
    const row = unwrap(
      await context.supabase
        .from("learning_attempts")
        .select("*")
        .eq("id", data.attempt_id)
        .eq("user_id", context.userId)
        .maybeSingle(),
    );
    if (!row) throw new Error("Attempt not found for this account.");
    // Own score history is retained after expiry/revocation. In-progress protected content is not.
    if (row.status !== "submitted")
      await learningPlan(context, {
        test_id: row.test_id ?? undefined,
        series_id: row.series_id ?? undefined,
      });
    const paper = await getAttemptPaper(row.id);
    if (paper.user_id !== context.userId) throw new Error("Forbidden");
    return {
      attempt: attemptView(row, paper),
      test: paper.test,
      questions: row.status === "submitted" ? paper.questions : publicQuestions(paper.questions),
      server_now: new Date().toISOString(),
    };
  });

export const saveLearningAttemptAnswers = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) =>
    attemptId
      .extend({ answers: responses, revision: z.number().int().min(1).max(1_000_000) })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const row = unwrap(
      await context.supabase
        .from("learning_attempts")
        .select("*")
        .eq("id", data.attempt_id)
        .eq("user_id", context.userId)
        .maybeSingle(),
    );
    if (!row || row.status !== "started") return { ok: false, reason: "submitted" };
    await learningPlan(context, {
      test_id: row.test_id ?? undefined,
      series_id: row.series_id ?? undefined,
    });
    const paper = await getAttemptPaper(row.id);
    if (paper.user_id !== context.userId) throw new Error("Forbidden");
    gradePaper(paper.questions, data.answers); // Validation only; answer key/score never returned by autosave.
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const saved = unwrap(
      await supabaseAdmin.rpc("save_learning_attempt_answers", {
        p_actor: context.userId,
        p_attempt: row.id,
        p_answers: data.answers,
        p_revision: data.revision,
      }),
    );
    return saved as { ok: boolean; reason?: string };
  });

export const submitLearningAttempt = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => attemptId.extend({ answers: responses }).parse(input))
  .handler(async ({ context, data }) => {
    const paper = await getAttemptPaper(data.attempt_id);
    if (paper.user_id !== context.userId) throw new Error("Attempt not found for this account.");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    for (let retry = 0; retry < 3; retry += 1) {
      const row = unwrap(
        await context.supabase
          .from("learning_attempts")
          .select("*")
          .eq("id", data.attempt_id)
          .eq("user_id", context.userId)
          .maybeSingle(),
      );
      if (!row) throw new Error("Attempt not found for this account.");
      if (row.status === "submitted")
        return { attempt: attemptView(row, paper), questions: paper.questions };
      await learningPlan(context, {
        test_id: row.test_id ?? undefined,
        series_id: row.series_id ?? undefined,
      });
      const savedAnswers = answerMap(row.answers);
      const freshResult = gradePaper(paper.questions, data.answers);
      const savedResult = gradePaper(paper.questions, savedAnswers);
      // Row-locked service-only SQL chooses the answer set using DATABASE time, never client time.
      // A concurrent autosave changes expected_saved_answers and causes a bounded re-grade retry.
      const result = await supabaseAdmin.rpc("finalize_learning_attempt", {
        p_actor: context.userId,
        p_attempt: row.id,
        p_answers: data.answers,
        p_expected_saved_answers: savedAnswers,
        p_fresh_result: freshResult,
        p_saved_result: savedResult,
      });
      if (result.error?.message.includes("ATTEMPT_RETRY")) continue;
      const submitted = unwrap(result) as unknown as LearningAttemptRow;
      return { attempt: attemptView(submitted, paper), questions: paper.questions };
    }
    throw new Error(
      "Answers changed during submission. Retry Submit Test; no result was overwritten.",
    );
  });

export const listMyLearningResults = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const rows =
      unwrap(
        await context.supabase
          .from("learning_attempts")
          .select("*")
          .eq("user_id", context.userId)
          .eq("status", "submitted")
          .order("submitted_at", { ascending: false })
          .limit(100),
      ) ?? [];
    return Promise.all(
      rows.map(async (row) => {
        try {
          const paper = await getAttemptPaper(row.id);
          if (paper.user_id !== context.userId) throw new Error("Forbidden");
          return attemptView(row, paper);
        } catch {
          return {
            ...row,
            exam: "Saved result",
            subject: "Archived selection",
            chapter: "Context temporarily unavailable",
          };
        }
      }),
    );
  });
