import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { GetObjectCommand, PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import type { TestRow } from "@/integrations/supabase/db";
import type { GeneratedTestQuestion } from "@/lib/generated-test";
import type { TestQuestionRow } from "@/integrations/supabase/db";

export type AttemptPaper = {
  user_id: string;
  seed: string;
  selection: { test_id: string | null; series_id: string | null; subject: string; chapter: string };
  test: TestRow;
  questions: (GeneratedTestQuestion | TestQuestionRow)[];
};
function address(id: string) {
  if (!/^[0-9a-f-]{36}$/i.test(id)) throw new Error("Invalid attempt ID.");
  return `kkcc/private-attempt-papers/${id}.json`;
}
function client() {
  return new S3Client({
    region: process.env["KKCC_CONTENT_REGION"] || "auto",
    ...(process.env["KKCC_CONTENT_ENDPOINT"]
      ? { endpoint: process.env["KKCC_CONTENT_ENDPOINT"], forcePathStyle: true }
      : {}),
    ...(process.env["KKCC_CONTENT_ACCESS_KEY_ID"]
      ? {
          credentials: {
            accessKeyId: process.env["KKCC_CONTENT_ACCESS_KEY_ID"]!,
            secretAccessKey: process.env["KKCC_CONTENT_SECRET_ACCESS_KEY"] || "",
          },
        }
      : {}),
  });
}
function localFile(id: string) {
  return resolve(
    dirname(process.env["KKCC_CONTENT_FILE"] || "data/project-content.runtime.json"),
    "private-attempt-papers",
    `${id}.json`,
  );
}
export async function saveAttemptPaper(id: string, paper: AttemptPaper) {
  const key = address(id);
  if (process.env["KKCC_CONTENT_BACKEND"] === "s3") {
    await client().send(
      new PutObjectCommand({
        Bucket: process.env["KKCC_CONTENT_BUCKET"],
        Key: key,
        Body: JSON.stringify(paper),
        ContentType: "application/json",
        CacheControl: "private,no-store",
        IfNoneMatch: "*",
      }),
    );
    return;
  }
  if (
    process.env["KKCC_CONTENT_BACKEND"] === "readonly" ||
    (process.env["VERCEL"] && !process.env["KKCC_CONTENT_BACKEND"])
  )
    throw new Error("Configure persistent private project storage before starting tests.");
  const file = localFile(id);
  await mkdir(dirname(file), { recursive: true });
  await writeFile(file, JSON.stringify(paper), { mode: 0o600, flag: "wx" });
}
export async function getAttemptPaper(id: string): Promise<AttemptPaper> {
  const key = address(id);
  if (process.env["KKCC_CONTENT_BACKEND"] === "s3") {
    const object = await client().send(
      new GetObjectCommand({ Bucket: process.env["KKCC_CONTENT_BUCKET"], Key: key }),
    );
    const body = await object.Body?.transformToString();
    if (!body) throw new Error("Attempt paper not found.");
    return JSON.parse(body) as AttemptPaper;
  }
  return JSON.parse(await readFile(localFile(id), "utf8")) as AttemptPaper;
}
