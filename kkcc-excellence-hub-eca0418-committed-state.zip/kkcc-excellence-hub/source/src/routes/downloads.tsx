import { createFileRoute } from "@tanstack/react-router";
import { Download, Database, FileArchive, ShieldCheck } from "lucide-react";
import { SiteLayout } from "@/components/kkcc/site-layout";

export const Route = createFileRoute("/downloads")({
  head: () => ({
    meta: [
      { title: "Downloads — KKCC Excellence Hub" },
      {
        name: "description",
        content:
          "Download the KKCC Excellence Hub website ZIP, SQL cleaner and one combined SQL setup file.",
      },
    ],
  }),
  component: DownloadsPage,
});

const DOWNLOADS = [
  {
    title: "KKCC Excellence Hub Website ZIP",
    description: "Complete Termux/Vercel source ZIP for the full website app.",
    href: "/downloads/kkcc-excellence-hub.zip",
    button: "Download ZIP",
    icon: FileArchive,
    sha256: "Generated fresh with each ZIP rebuild; use the final hash shared after packaging.",
  },
  {
    title: "KKCC Excellence Hub SQL Cleaner",
    description:
      "Use this only when you want to clean/reset KKCC database objects before a fresh setup.",
    href: "/downloads/kkcc-excellence-hub-sql-cleaner.sql",
    button: "Download SQL Cleaner",
    icon: ShieldCheck,
    sha256: "468f38d36b8770a6d2e6036763e718e0f3b5ac4aacf1fbc5d4aaa7a317df5cea",
  },
  {
    title: "KKCC Excellence Hub One Combined SQL",
    description: "Run this after the cleaner, or directly on a fresh database project.",
    href: "/downloads/kkcc-excellence-hub-one-combined.sql",
    button: "Download Combined SQL",
    icon: Database,
    sha256: "60b68502ba88fd4c6b003355e391fce0af8bc43044116dd4f0428ab3129cb85e",
  },
] as const;

function DownloadsPage() {
  return (
    <SiteLayout>
      <section className="relative overflow-hidden border-b">
        <div className="pointer-events-none absolute -top-40 left-1/2 h-[520px] w-[820px] -translate-x-1/2 rounded-full bg-primary/10 blur-3xl" />
        <div className="relative mx-auto w-full max-w-5xl px-4 py-14 sm:px-6 lg:py-20">
          <div className="surface-panel p-6 sm:p-8 lg:p-10">
            <div className="inline-flex items-center gap-2 rounded-full border border-primary/25 bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-primary">
              <Download className="h-3.5 w-3.5" /> Server Downloads
            </div>
            <h1 className="neon-text mt-5 text-3xl font-black tracking-tight sm:text-5xl">
              KKCC Excellence Hub Files
            </h1>
            <p className="mt-4 max-w-3xl text-sm leading-relaxed text-muted-foreground sm:text-base">
              Download the website ZIP, SQL cleaner and one combined SQL file directly from this
              server page.
            </p>

            <div className="mt-8 grid gap-5">
              {DOWNLOADS.map(({ title, description, href, button, icon: Icon, sha256 }) => (
                <article key={href} className="rounded-3xl border bg-background/65 p-5 shadow-soft">
                  <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                    <div className="min-w-0">
                      <div className="flex items-center gap-3">
                        <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-primary/10 text-primary">
                          <Icon className="h-5 w-5" />
                        </span>
                        <div className="min-w-0">
                          <h2 className="text-lg font-bold">{title}</h2>
                          <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                            {description}
                          </p>
                        </div>
                      </div>
                      <p className="mt-4 break-all rounded-2xl bg-muted/50 p-3 font-mono text-[11px] leading-relaxed text-accent">
                        Checksum: {sha256}
                      </p>
                    </div>
                    <a
                      href={href}
                      download
                      className="inline-flex shrink-0 items-center justify-center rounded-full bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground shadow-[0_0_24px_color-mix(in_oklab,var(--primary)_24%,transparent)] transition-colors hover:bg-primary/90"
                    >
                      <Download className="mr-2 h-4 w-4" /> {button}
                    </a>
                  </div>
                </article>
              ))}
            </div>

            <div className="mt-7 rounded-3xl border border-accent/25 bg-accent/10 p-5 text-sm leading-relaxed text-muted-foreground">
              <p className="font-semibold text-foreground">Fresh database reset order:</p>
              <ol className="mt-2 list-decimal space-y-1 pl-5">
                <li>Run the SQL Cleaner file first.</li>
                <li>Then run the One Combined SQL file.</li>
                <li>
                  Storage files/buckets should be cleaned separately from the storage dashboard/API
                  if needed.
                </li>
              </ol>
              <p className="mt-3 font-semibold text-foreground">
                Existing live projects: do not use the cleaner. Run only the two newest timestamped
                security migrations in order.
              </p>
            </div>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
