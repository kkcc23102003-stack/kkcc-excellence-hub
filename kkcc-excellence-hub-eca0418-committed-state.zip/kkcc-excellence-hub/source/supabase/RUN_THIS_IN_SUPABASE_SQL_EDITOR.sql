-- HISTORICAL CMS SQL / RETAINED FOR ORIGINAL-PROJECT REFERENCE.
-- DO NOT use for a fresh student-only install or run blindly in production.
-- Use supabase/STUDENT_ONLY_SCHEMA.sql and docs/DEPLOYMENT_STUDENT_ONLY.md after a verified export.
-- KKCC-excellence-hub complete Supabase setup
-- Paste this whole file in Supabase Dashboard -> SQL Editor -> Run.
-- It is safe to run on a fresh or partially-created project; it avoids the
-- "type app_role already exists" error and refreshes policies/triggers.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- 1) Roles / helpers ---------------------------------------------------------
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_type t
    JOIN pg_namespace n ON n.oid = t.typnamespace
    WHERE t.typname = 'app_role' AND n.nspname = 'public'
  ) THEN
    CREATE TYPE public.app_role AS ENUM ('admin', 'user');
  END IF;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TABLE IF NOT EXISTS public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'user_roles_user_id_role_key'
      AND conrelid = 'public.user_roles'::regclass
  ) THEN
    ALTER TABLE public.user_roles ADD CONSTRAINT user_roles_user_id_role_key UNIQUE (user_id, role);
  END IF;
END;
$$;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

GRANT SELECT, INSERT, UPDATE, DELETE ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view their own roles" ON public.user_roles;
CREATE POLICY "Users can view their own roles"
  ON public.user_roles FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admins can view all roles" ON public.user_roles;
CREATE POLICY "Admins can view all roles"
  ON public.user_roles FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins can manage roles" ON public.user_roles;
CREATE POLICY "Admins can manage roles"
  ON public.user_roles FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated, service_role;

-- 2) Courses / lectures / materials / tests ---------------------------------
CREATE TABLE IF NOT EXISTS public.courses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  title text NOT NULL,
  category text NOT NULL DEFAULT 'School',
  class_level text NOT NULL DEFAULT '',
  subject text NOT NULL DEFAULT '',
  faculty text NOT NULL DEFAULT '',
  course_type text NOT NULL DEFAULT 'Recorded',
  thumbnail_url text,
  hue integer NOT NULL DEFAULT 187,
  summary text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  outcomes text[] NOT NULL DEFAULT '{}',
  price integer NOT NULL DEFAULT 0,
  original_price integer NOT NULL DEFAULT 0,
  discount_percent integer NOT NULL DEFAULT 0,
  duration_hours integer NOT NULL DEFAULT 0,
  lectures_count integer NOT NULL DEFAULT 0,
  tests_count integer NOT NULL DEFAULT 0,
  materials_count integer NOT NULL DEFAULT 0,
  rating numeric(2,1) NOT NULL DEFAULT 4.5,
  status text NOT NULL DEFAULT 'draft',
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.courses
  ADD COLUMN IF NOT EXISTS thumbnail_url text,
  ADD COLUMN IF NOT EXISTS hue integer NOT NULL DEFAULT 187,
  ADD COLUMN IF NOT EXISTS summary text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS description text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS outcomes text[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS price integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS original_price integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS discount_percent integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS duration_hours integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS lectures_count integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS tests_count integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS materials_count integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS rating numeric(2,1) NOT NULL DEFAULT 4.5,
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'draft',
  ADD COLUMN IF NOT EXISTS sort_order integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

CREATE UNIQUE INDEX IF NOT EXISTS courses_slug_unique_idx ON public.courses(slug);
CREATE INDEX IF NOT EXISTS idx_courses_status ON public.courses(status, sort_order);

GRANT SELECT ON public.courses TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.courses TO authenticated;
GRANT ALL ON public.courses TO service_role;
ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Published courses are viewable by everyone" ON public.courses;
CREATE POLICY "Published courses are viewable by everyone"
  ON public.courses FOR SELECT
  USING (status = 'published');

DROP POLICY IF EXISTS "Admins can view all courses" ON public.courses;
CREATE POLICY "Admins can view all courses"
  ON public.courses FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins can manage courses" ON public.courses;
CREATE POLICY "Admins can manage courses"
  ON public.courses FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_courses_updated_at ON public.courses;
CREATE TRIGGER update_courses_updated_at
  BEFORE UPDATE ON public.courses
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE IF NOT EXISTS public.lectures (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid NOT NULL REFERENCES public.courses(id) ON DELETE CASCADE,
  module_title text NOT NULL DEFAULT 'Module 01',
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  video_url text,
  duration text NOT NULL DEFAULT '00:00',
  is_free boolean NOT NULL DEFAULT false,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.lectures
  ADD COLUMN IF NOT EXISTS module_title text NOT NULL DEFAULT 'Module 01',
  ADD COLUMN IF NOT EXISTS description text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS video_url text,
  ADD COLUMN IF NOT EXISTS duration text NOT NULL DEFAULT '00:00',
  ADD COLUMN IF NOT EXISTS is_free boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS sort_order integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

CREATE INDEX IF NOT EXISTS idx_lectures_course ON public.lectures(course_id, sort_order);

GRANT SELECT ON public.lectures TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.lectures TO authenticated;
GRANT ALL ON public.lectures TO service_role;
ALTER TABLE public.lectures ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Lectures of published courses are viewable by everyone" ON public.lectures;
CREATE POLICY "Lectures of published courses are viewable by everyone"
  ON public.lectures FOR SELECT
  USING (EXISTS (SELECT 1 FROM public.courses c WHERE c.id = course_id AND c.status = 'published'));

DROP POLICY IF EXISTS "Admins can view all lectures" ON public.lectures;
CREATE POLICY "Admins can view all lectures"
  ON public.lectures FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins can manage lectures" ON public.lectures;
CREATE POLICY "Admins can manage lectures"
  ON public.lectures FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_lectures_updated_at ON public.lectures;
CREATE TRIGGER update_lectures_updated_at
  BEFORE UPDATE ON public.lectures
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE IF NOT EXISTS public.materials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid REFERENCES public.courses(id) ON DELETE CASCADE,
  title text NOT NULL,
  material_type text NOT NULL DEFAULT 'Notes',
  subject text NOT NULL DEFAULT '',
  chapter text NOT NULL DEFAULT '',
  class_level text NOT NULL DEFAULT '',
  pages integer NOT NULL DEFAULT 0,
  file_url text,
  is_published boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  description text NOT NULL DEFAULT '',
  thumbnail_url text,
  module_title text NOT NULL DEFAULT '',
  batch text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.materials
  ADD COLUMN IF NOT EXISTS course_id uuid REFERENCES public.courses(id) ON DELETE CASCADE,
  ADD COLUMN IF NOT EXISTS material_type text NOT NULL DEFAULT 'Notes',
  ADD COLUMN IF NOT EXISTS subject text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS chapter text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS class_level text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS pages integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS file_url text,
  ADD COLUMN IF NOT EXISTS is_published boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS sort_order integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS description text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS thumbnail_url text,
  ADD COLUMN IF NOT EXISTS module_title text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS batch text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

CREATE INDEX IF NOT EXISTS idx_materials_course ON public.materials(course_id, sort_order);

GRANT SELECT ON public.materials TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.materials TO authenticated;
GRANT ALL ON public.materials TO service_role;
ALTER TABLE public.materials ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Published materials are viewable by everyone" ON public.materials;
CREATE POLICY "Published materials are viewable by everyone"
  ON public.materials FOR SELECT
  USING (
    is_published
    AND (course_id IS NULL OR EXISTS (SELECT 1 FROM public.courses c WHERE c.id = course_id AND c.status = 'published'))
  );

DROP POLICY IF EXISTS "Admins can view all materials" ON public.materials;
CREATE POLICY "Admins can view all materials"
  ON public.materials FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins can manage materials" ON public.materials;
CREATE POLICY "Admins can manage materials"
  ON public.materials FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_materials_updated_at ON public.materials;
CREATE TRIGGER update_materials_updated_at
  BEFORE UPDATE ON public.materials
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE IF NOT EXISTS public.tests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid REFERENCES public.courses(id) ON DELETE CASCADE,
  title text NOT NULL,
  instructions text NOT NULL DEFAULT '',
  subject text NOT NULL DEFAULT '',
  duration_minutes integer NOT NULL DEFAULT 60,
  questions_count integer NOT NULL DEFAULT 0,
  total_marks integer NOT NULL DEFAULT 0,
  is_published boolean NOT NULL DEFAULT false,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.tests TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tests TO authenticated;
GRANT ALL ON public.tests TO service_role;
ALTER TABLE public.tests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Published tests are viewable by everyone" ON public.tests;
CREATE POLICY "Published tests are viewable by everyone"
  ON public.tests FOR SELECT
  USING (is_published AND (course_id IS NULL OR EXISTS (
    SELECT 1 FROM public.courses c WHERE c.id = tests.course_id AND c.status = 'published'
  )));

DROP POLICY IF EXISTS "Admins can view all tests" ON public.tests;
CREATE POLICY "Admins can view all tests"
  ON public.tests FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins can manage tests" ON public.tests;
CREATE POLICY "Admins can manage tests"
  ON public.tests FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_tests_updated_at ON public.tests;
CREATE TRIGGER update_tests_updated_at
  BEFORE UPDATE ON public.tests
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.refresh_course_counts()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  cid uuid;
BEGIN
  cid := COALESCE(NEW.course_id, OLD.course_id);
  IF cid IS NULL THEN RETURN COALESCE(NEW, OLD); END IF;
  UPDATE public.courses c SET
    lectures_count = (SELECT count(*) FROM public.lectures l WHERE l.course_id = cid),
    materials_count = (SELECT count(*) FROM public.materials m WHERE m.course_id = cid),
    tests_count = (SELECT count(*) FROM public.tests t WHERE t.course_id = cid)
  WHERE c.id = cid;
  RETURN COALESCE(NEW, OLD);
END;
$$;

DROP TRIGGER IF EXISTS lectures_refresh_counts ON public.lectures;
CREATE TRIGGER lectures_refresh_counts
  AFTER INSERT OR UPDATE OR DELETE ON public.lectures
  FOR EACH ROW EXECUTE FUNCTION public.refresh_course_counts();

DROP TRIGGER IF EXISTS materials_refresh_counts ON public.materials;
CREATE TRIGGER materials_refresh_counts
  AFTER INSERT OR UPDATE OR DELETE ON public.materials
  FOR EACH ROW EXECUTE FUNCTION public.refresh_course_counts();

DROP TRIGGER IF EXISTS tests_refresh_counts ON public.tests;
CREATE TRIGGER tests_refresh_counts
  AFTER INSERT OR UPDATE OR DELETE ON public.tests
  FOR EACH ROW EXECUTE FUNCTION public.refresh_course_counts();

-- 3) Public/admin editable settings -----------------------------------------
CREATE TABLE IF NOT EXISTS public.site_settings (
  key text PRIMARY KEY,
  value text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.site_settings TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.site_settings TO authenticated;
GRANT ALL ON public.site_settings TO service_role;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Site settings are readable by everyone" ON public.site_settings;
CREATE POLICY "Site settings are readable by everyone"
  ON public.site_settings FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Admins can manage site settings" ON public.site_settings;
CREATE POLICY "Admins can manage site settings"
  ON public.site_settings FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_site_settings_updated_at ON public.site_settings;
CREATE TRIGGER update_site_settings_updated_at
  BEFORE UPDATE ON public.site_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.site_settings (key, value) VALUES
  ('social_youtube', ''),
  ('social_instagram', ''),
  ('social_facebook', ''),
  ('social_telegram', ''),
  ('social_whatsapp', ''),
  ('social_links_json', ''),
  ('app_builder_json', ''),
  ('brand_app_name', 'Kusum Kartik Coaching Centre'),
  ('brand_short_name', 'KKCC'),
  ('brand_tagline', 'Learn Better. Understand Deeper. Achieve More.'),
  ('brand_logo_url', '/logo.png'),
  ('brand_logo_alt', 'KKCC logo'),
  ('brand_show_logo_text', 'true'),
  ('brand_primary_color', '#18f4d6'),
  ('brand_accent_color', '#f5d78e'),
  ('brand_background_color', '#050605'),
  ('brand_foreground_color', '#fff8e7'),
  ('brand_hero_eyebrow', 'Learn Better. Understand Deeper. Achieve More.'),
  ('brand_hero_title', 'KKCC Excellence Hub — Study That Makes You Return.'),
  ('brand_hero_highlight', 'Learn with clarity. Practice with courage. Rise with confidence.'),
  ('brand_hero_description', 'KKCC turns lectures, notes, tests, and progress into a bright daily learning loop — so students know exactly what to open next and feel excited to continue.'),
  ('brand_cta_primary_label', 'Find My Next Win'),
  ('brand_cta_secondary_label', 'Continue Learning'),
  ('website_content_json', ''),
  ('payment_provider', 'razorpay'),
  ('payment_enabled', 'false'),
  ('payment_mode', 'test'),
  ('razorpay_key_id', ''),
  ('offline_payment_instructions', 'Use the KKCC inquiry flow for UPI, cash or bank-transfer access. Course access is activated after the KKCC team confirms the payment.'),
  ('storage_provider', 'supabase'),
  ('storage_bucket', 'course-content'),
  ('storage_region', ''),
  ('storage_endpoint', ''),
  ('storage_public_base_url', ''),
  ('storage_migration_status', 'idle')
ON CONFLICT (key) DO NOTHING;

-- 4) Profiles / auth trigger / owner admin ----------------------------------
CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL DEFAULT '',
  full_name text NOT NULL DEFAULT '',
  mobile text NOT NULL DEFAULT '',
  class_level text NOT NULL DEFAULT '',
  target_exam text NOT NULL DEFAULT '',
  avatar_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS email text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS full_name text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS mobile text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS class_level text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS target_exam text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS avatar_url text,
  ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

CREATE INDEX IF NOT EXISTS idx_profiles_email ON public.profiles (lower(email));

GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
CREATE POLICY "Users can view own profile"
  ON public.profiles FOR SELECT TO authenticated
  USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can insert own profile" ON public.profiles;
CREATE POLICY "Users can insert own profile"
  ON public.profiles FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "Admins can view all profiles" ON public.profiles;
CREATE POLICY "Admins can view all profiles"
  ON public.profiles FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_profiles_updated_at ON public.profiles;
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.handle_new_user_profile()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, mobile, class_level, target_exam)
  VALUES (
    NEW.id,
    COALESCE(NEW.email, ''),
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', NEW.raw_user_meta_data ->> 'name', ''),
    COALESCE(NEW.raw_user_meta_data ->> 'mobile', ''),
    COALESCE(NEW.raw_user_meta_data ->> 'class_level', ''),
    COALESCE(NEW.raw_user_meta_data ->> 'target_exam', '')
  )
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    full_name = COALESCE(NULLIF(EXCLUDED.full_name, ''), public.profiles.full_name),
    mobile = COALESCE(NULLIF(EXCLUDED.mobile, ''), public.profiles.mobile),
    class_level = COALESCE(NULLIF(EXCLUDED.class_level, ''), public.profiles.class_level),
    target_exam = COALESCE(NULLIF(EXCLUDED.target_exam, ''), public.profiles.target_exam),
    updated_at = now();

  IF lower(COALESCE(NEW.email, '')) = 'kkcc23102003@gmail.com' THEN
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created_profile ON auth.users;
CREATE TRIGGER on_auth_user_created_profile
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user_profile();

INSERT INTO public.profiles (id, email, full_name, mobile, class_level, target_exam)
SELECT
  u.id,
  COALESCE(u.email, ''),
  COALESCE(u.raw_user_meta_data ->> 'full_name', u.raw_user_meta_data ->> 'name', ''),
  COALESCE(u.raw_user_meta_data ->> 'mobile', ''),
  COALESCE(u.raw_user_meta_data ->> 'class_level', ''),
  COALESCE(u.raw_user_meta_data ->> 'target_exam', '')
FROM auth.users u
ON CONFLICT (id) DO UPDATE SET
  email = EXCLUDED.email,
  full_name = COALESCE(NULLIF(EXCLUDED.full_name, ''), public.profiles.full_name),
  mobile = COALESCE(NULLIF(EXCLUDED.mobile, ''), public.profiles.mobile),
  class_level = COALESCE(NULLIF(EXCLUDED.class_level, ''), public.profiles.class_level),
  target_exam = COALESCE(NULLIF(EXCLUDED.target_exam, ''), public.profiles.target_exam),
  updated_at = now();

INSERT INTO public.user_roles (user_id, role)
SELECT id, 'admin'::public.app_role
FROM auth.users
WHERE lower(email) = 'kkcc23102003@gmail.com'
ON CONFLICT (user_id, role) DO NOTHING;

-- Disable legacy first-user admin claim.
CREATE OR REPLACE FUNCTION public.claim_admin()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RAISE EXCEPTION 'Admin claiming is disabled. Assign admins in public.user_roles from Supabase/Admin panel.';
END;
$$;

REVOKE EXECUTE ON FUNCTION public.claim_admin() FROM anon, public, authenticated;
GRANT EXECUTE ON FUNCTION public.claim_admin() TO service_role;

-- 5) Storage bucket / upload policies ---------------------------------------
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('course-content', 'course-content', false, 209715200, NULL)
ON CONFLICT (id) DO UPDATE SET
  public = EXCLUDED.public,
  file_size_limit = EXCLUDED.file_size_limit,
  allowed_mime_types = EXCLUDED.allowed_mime_types;

DROP POLICY IF EXISTS "Course content is readable" ON storage.objects;
CREATE POLICY "Course content is readable"
  ON storage.objects FOR SELECT TO anon, authenticated
  USING (bucket_id = 'course-content');

DROP POLICY IF EXISTS "Admins upload course content" ON storage.objects;
CREATE POLICY "Admins upload course content"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'course-content' AND public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins update course content" ON storage.objects;
CREATE POLICY "Admins update course content"
  ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'course-content' AND public.has_role(auth.uid(), 'admin'))
  WITH CHECK (bucket_id = 'course-content' AND public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins delete course content" ON storage.objects;
CREATE POLICY "Admins delete course content"
  ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'course-content' AND public.has_role(auth.uid(), 'admin'));

-- 6) Enrolments / files / private settings / payments -----------------------
CREATE TABLE IF NOT EXISTS public.course_enrollments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  course_id uuid NOT NULL REFERENCES public.courses(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'active',
  source text NOT NULL DEFAULT 'manual',
  payment_method text NOT NULL DEFAULT 'manual',
  amount_paid integer NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'INR',
  admin_note text NOT NULL DEFAULT '',
  expires_at timestamptz,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, course_id)
);

CREATE INDEX IF NOT EXISTS idx_course_enrollments_user ON public.course_enrollments(user_id, status);
CREATE INDEX IF NOT EXISTS idx_course_enrollments_course ON public.course_enrollments(course_id, status);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.course_enrollments TO authenticated;
GRANT ALL ON public.course_enrollments TO service_role;
ALTER TABLE public.course_enrollments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own enrollments" ON public.course_enrollments;
CREATE POLICY "Users can view own enrollments"
  ON public.course_enrollments FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admins can view all enrollments" ON public.course_enrollments;
CREATE POLICY "Admins can view all enrollments"
  ON public.course_enrollments FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Users can claim free published enrollments" ON public.course_enrollments;
CREATE POLICY "Users can claim free published enrollments"
  ON public.course_enrollments FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = user_id
    AND source = 'free'
    AND amount_paid = 0
    AND EXISTS (
      SELECT 1 FROM public.courses c
      WHERE c.id = course_enrollments.course_id
        AND c.status = 'published'
        AND c.price = 0
    )
  );

DROP POLICY IF EXISTS "Admins can manage enrollments" ON public.course_enrollments;
CREATE POLICY "Admins can manage enrollments"
  ON public.course_enrollments FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_course_enrollments_updated_at ON public.course_enrollments;
CREATE TRIGGER update_course_enrollments_updated_at
  BEFORE UPDATE ON public.course_enrollments
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE IF NOT EXISTS public.files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider text NOT NULL DEFAULT 'supabase',
  bucket text NOT NULL DEFAULT 'course-content',
  path text NOT NULL,
  public_url text NOT NULL DEFAULT '',
  original_url text NOT NULL DEFAULT '',
  mime_type text NOT NULL DEFAULT '',
  size_bytes bigint NOT NULL DEFAULT 0,
  linked_table text NOT NULL DEFAULT '',
  linked_id uuid,
  migration_status text NOT NULL DEFAULT 'active',
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_files_provider ON public.files(provider, migration_status);
CREATE INDEX IF NOT EXISTS idx_files_linked ON public.files(linked_table, linked_id);

GRANT SELECT ON public.files TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.files TO authenticated;
GRANT ALL ON public.files TO service_role;
ALTER TABLE public.files ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Published file metadata is readable" ON public.files;
CREATE POLICY "Published file metadata is readable"
  ON public.files FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Admins can manage file metadata" ON public.files;
CREATE POLICY "Admins can manage file metadata"
  ON public.files FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_files_updated_at ON public.files;
CREATE TRIGGER update_files_updated_at
  BEFORE UPDATE ON public.files
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE IF NOT EXISTS public.private_settings (
  key text PRIMARY KEY,
  value text NOT NULL DEFAULT '',
  updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.private_settings TO authenticated;
GRANT ALL ON public.private_settings TO service_role;
ALTER TABLE public.private_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Admins can manage private settings" ON public.private_settings;
CREATE POLICY "Admins can manage private settings"
  ON public.private_settings FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_private_settings_updated_at ON public.private_settings;
CREATE TRIGGER update_private_settings_updated_at
  BEFORE UPDATE ON public.private_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE IF NOT EXISTS public.payment_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  course_id uuid REFERENCES public.courses(id) ON DELETE SET NULL,
  provider text NOT NULL DEFAULT 'manual',
  status text NOT NULL DEFAULT 'pending',
  amount integer NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'INR',
  provider_order_id text NOT NULL DEFAULT '',
  provider_payment_id text NOT NULL DEFAULT '',
  admin_note text NOT NULL DEFAULT '',
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.payment_transactions TO authenticated;
GRANT ALL ON public.payment_transactions TO service_role;
ALTER TABLE public.payment_transactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own payment transactions" ON public.payment_transactions;
CREATE POLICY "Users can view own payment transactions"
  ON public.payment_transactions FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admins can manage payment transactions" ON public.payment_transactions;
CREATE POLICY "Admins can manage payment transactions"
  ON public.payment_transactions FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_payment_transactions_updated_at ON public.payment_transactions;
CREATE TRIGGER update_payment_transactions_updated_at
  BEFORE UPDATE ON public.payment_transactions
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- 7) Offline payment access grants -----------------------------------------
CREATE TABLE IF NOT EXISTS public.offline_access_grants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  full_name text NOT NULL DEFAULT '',
  course_id uuid NOT NULL REFERENCES public.courses(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'pending',
  amount_paid integer NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'INR',
  payment_method text NOT NULL DEFAULT 'offline',
  admin_note text NOT NULL DEFAULT '',
  expires_at timestamptz,
  activated_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (email, course_id)
);

ALTER TABLE public.offline_access_grants
  ADD COLUMN IF NOT EXISTS email text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS full_name text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS course_id uuid REFERENCES public.courses(id) ON DELETE CASCADE,
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS amount_paid integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS currency text NOT NULL DEFAULT 'INR',
  ADD COLUMN IF NOT EXISTS payment_method text NOT NULL DEFAULT 'offline',
  ADD COLUMN IF NOT EXISTS admin_note text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS expires_at timestamptz,
  ADD COLUMN IF NOT EXISTS activated_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

CREATE UNIQUE INDEX IF NOT EXISTS idx_offline_access_email_course
  ON public.offline_access_grants (email, course_id);
CREATE INDEX IF NOT EXISTS idx_offline_access_status ON public.offline_access_grants(status);
CREATE INDEX IF NOT EXISTS idx_offline_access_activated_user ON public.offline_access_grants(activated_user_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.offline_access_grants TO authenticated;
GRANT ALL ON public.offline_access_grants TO service_role;
ALTER TABLE public.offline_access_grants ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Admins can manage offline access grants" ON public.offline_access_grants;
CREATE POLICY "Admins can manage offline access grants"
  ON public.offline_access_grants FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_offline_access_grants_updated_at ON public.offline_access_grants;
CREATE TRIGGER update_offline_access_grants_updated_at
  BEFORE UPDATE ON public.offline_access_grants
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.activate_offline_access_for_user(_user_id uuid, _email text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.course_enrollments (
    user_id,
    course_id,
    status,
    source,
    payment_method,
    amount_paid,
    currency,
    admin_note,
    expires_at,
    created_by
  )
  SELECT
    _user_id,
    g.course_id,
    'active',
    'offline',
    g.payment_method,
    g.amount_paid,
    g.currency,
    g.admin_note,
    g.expires_at,
    g.created_by
  FROM public.offline_access_grants g
  WHERE lower(g.email) = lower(COALESCE(_email, ''))
    AND g.status IN ('pending', 'activated')
  ON CONFLICT (user_id, course_id) DO UPDATE SET
    status = 'active',
    source = 'offline',
    payment_method = EXCLUDED.payment_method,
    amount_paid = EXCLUDED.amount_paid,
    currency = EXCLUDED.currency,
    admin_note = EXCLUDED.admin_note,
    expires_at = EXCLUDED.expires_at,
    created_by = COALESCE(EXCLUDED.created_by, public.course_enrollments.created_by),
    updated_at = now();

  UPDATE public.profiles p
  SET full_name = COALESCE(
      NULLIF((
        SELECT g.full_name
        FROM public.offline_access_grants g
        WHERE lower(g.email) = lower(COALESCE(_email, ''))
          AND g.full_name <> ''
        ORDER BY g.updated_at DESC
        LIMIT 1
      ), ''),
      p.full_name
    ),
    updated_at = now()
  WHERE p.id = _user_id;

  UPDATE public.offline_access_grants
  SET status = 'activated',
      activated_user_id = _user_id,
      updated_at = now()
  WHERE lower(email) = lower(COALESCE(_email, ''))
    AND status IN ('pending', 'activated');
END;
$$;

REVOKE EXECUTE ON FUNCTION public.activate_offline_access_for_user(uuid, text) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.activate_offline_access_for_user(uuid, text) TO authenticated, service_role;

CREATE OR REPLACE FUNCTION public.handle_new_user_profile()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, mobile, class_level, target_exam)
  VALUES (
    NEW.id,
    COALESCE(NEW.email, ''),
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', NEW.raw_user_meta_data ->> 'name', ''),
    COALESCE(NEW.raw_user_meta_data ->> 'mobile', ''),
    COALESCE(NEW.raw_user_meta_data ->> 'class_level', ''),
    COALESCE(NEW.raw_user_meta_data ->> 'target_exam', '')
  )
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    full_name = COALESCE(NULLIF(EXCLUDED.full_name, ''), public.profiles.full_name),
    mobile = COALESCE(NULLIF(EXCLUDED.mobile, ''), public.profiles.mobile),
    class_level = COALESCE(NULLIF(EXCLUDED.class_level, ''), public.profiles.class_level),
    target_exam = COALESCE(NULLIF(EXCLUDED.target_exam, ''), public.profiles.target_exam),
    updated_at = now();

  IF lower(COALESCE(NEW.email, '')) = 'kkcc23102003@gmail.com' THEN
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;

  PERFORM public.activate_offline_access_for_user(NEW.id, NEW.email);

  RETURN NEW;
END;
$$;

-- Activate pending offline grants for already-existing users.
SELECT public.activate_offline_access_for_user(id, email)
FROM auth.users
WHERE email IS NOT NULL;


-- 8) Coupon codes / limited redemptions -------------------------------------
CREATE TABLE IF NOT EXISTS public.coupon_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL,
  title text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  discount_percent integer NOT NULL DEFAULT 0,
  max_uses integer NOT NULL DEFAULT 0,
  used_count integer NOT NULL DEFAULT 0,
  per_user_limit integer NOT NULL DEFAULT 1,
  starts_at timestamptz,
  expires_at timestamptz,
  is_active boolean NOT NULL DEFAULT true,
  applies_to_course_id uuid REFERENCES public.courses(id) ON DELETE SET NULL,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.coupon_codes
  ADD COLUMN IF NOT EXISTS code text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS title text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS description text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS discount_percent integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS max_uses integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS used_count integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS per_user_limit integer NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS starts_at timestamptz,
  ADD COLUMN IF NOT EXISTS expires_at timestamptz,
  ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS applies_to_course_id uuid REFERENCES public.courses(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

CREATE UNIQUE INDEX IF NOT EXISTS idx_coupon_codes_upper_code ON public.coupon_codes (upper(code));
CREATE INDEX IF NOT EXISTS idx_coupon_codes_active ON public.coupon_codes(is_active, expires_at);
CREATE INDEX IF NOT EXISTS idx_coupon_codes_course ON public.coupon_codes(applies_to_course_id);

CREATE TABLE IF NOT EXISTS public.coupon_redemptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  coupon_id uuid NOT NULL REFERENCES public.coupon_codes(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  course_id uuid NOT NULL REFERENCES public.courses(id) ON DELETE CASCADE,
  discount_percent integer NOT NULL DEFAULT 0,
  discount_amount integer NOT NULL DEFAULT 0,
  original_amount integer NOT NULL DEFAULT 0,
  final_amount integer NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'INR',
  status text NOT NULL DEFAULT 'redeemed',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (coupon_id, user_id, course_id)
);

ALTER TABLE public.coupon_redemptions
  ADD COLUMN IF NOT EXISTS coupon_id uuid REFERENCES public.coupon_codes(id) ON DELETE CASCADE,
  ADD COLUMN IF NOT EXISTS user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  ADD COLUMN IF NOT EXISTS course_id uuid REFERENCES public.courses(id) ON DELETE CASCADE,
  ADD COLUMN IF NOT EXISTS discount_percent integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS discount_amount integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS original_amount integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS final_amount integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS currency text NOT NULL DEFAULT 'INR',
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'redeemed',
  ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();

CREATE UNIQUE INDEX IF NOT EXISTS idx_coupon_redemptions_unique
  ON public.coupon_redemptions(coupon_id, user_id, course_id);
CREATE INDEX IF NOT EXISTS idx_coupon_redemptions_user ON public.coupon_redemptions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_coupon_redemptions_coupon ON public.coupon_redemptions(coupon_id, created_at DESC);

GRANT SELECT ON public.coupon_codes TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.coupon_codes TO authenticated;
GRANT ALL ON public.coupon_codes TO service_role;
ALTER TABLE public.coupon_codes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public can read active coupon codes" ON public.coupon_codes;
CREATE POLICY "Public can read active coupon codes"
  ON public.coupon_codes FOR SELECT
  USING (is_active = true);

DROP POLICY IF EXISTS "Admins can manage coupon codes" ON public.coupon_codes;
CREATE POLICY "Admins can manage coupon codes"
  ON public.coupon_codes FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_coupon_codes_updated_at ON public.coupon_codes;
CREATE TRIGGER update_coupon_codes_updated_at
  BEFORE UPDATE ON public.coupon_codes
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

GRANT SELECT ON public.coupon_redemptions TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.coupon_redemptions TO authenticated;
GRANT ALL ON public.coupon_redemptions TO service_role;
ALTER TABLE public.coupon_redemptions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own coupon redemptions" ON public.coupon_redemptions;
CREATE POLICY "Users can view own coupon redemptions"
  ON public.coupon_redemptions FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admins can manage coupon redemptions" ON public.coupon_redemptions;
CREATE POLICY "Admins can manage coupon redemptions"
  ON public.coupon_redemptions FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE FUNCTION public.redeem_coupon_for_course(_code text, _course_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _user_id uuid := auth.uid();
  _coupon public.coupon_codes%ROWTYPE;
  _course public.courses%ROWTYPE;
  _existing public.coupon_redemptions%ROWTYPE;
  _user_redeem_count integer := 0;
  _original_amount integer := 0;
  _discount_amount integer := 0;
  _final_amount integer := 0;
BEGIN
  IF _user_id IS NULL THEN
    RAISE EXCEPTION 'Login required to redeem coupon.';
  END IF;

  SELECT * INTO _course
  FROM public.courses
  WHERE id = _course_id AND status = 'published';
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Course not found.';
  END IF;

  SELECT * INTO _coupon
  FROM public.coupon_codes
  WHERE upper(code) = upper(trim(_code))
  FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Coupon code not found.';
  END IF;

  IF _coupon.is_active IS NOT TRUE THEN
    RAISE EXCEPTION 'Coupon is inactive or expired.';
  END IF;
  IF _coupon.starts_at IS NOT NULL AND _coupon.starts_at > now() THEN
    RAISE EXCEPTION 'Coupon is not active yet.';
  END IF;
  IF _coupon.expires_at IS NOT NULL AND _coupon.expires_at <= now() THEN
    UPDATE public.coupon_codes SET is_active = false, updated_at = now() WHERE id = _coupon.id;
    RAISE EXCEPTION 'Coupon validity has ended.';
  END IF;
  IF _coupon.applies_to_course_id IS NOT NULL AND _coupon.applies_to_course_id <> _course_id THEN
    RAISE EXCEPTION 'Coupon is not valid for this course.';
  END IF;

  SELECT * INTO _existing
  FROM public.coupon_redemptions
  WHERE coupon_id = _coupon.id AND user_id = _user_id AND course_id = _course_id
  LIMIT 1;

  IF FOUND THEN
    IF _existing.final_amount <= 0 THEN
      INSERT INTO public.course_enrollments (
        user_id, course_id, status, source, payment_method, amount_paid, currency, admin_note
      ) VALUES (
        _user_id, _course_id, 'active', 'coupon', 'coupon', 0, 'INR', 'Coupon ' || _coupon.code || ' already redeemed'
      )
      ON CONFLICT (user_id, course_id) DO UPDATE SET
        status = 'active',
        source = 'coupon',
        payment_method = 'coupon',
        amount_paid = 0,
        admin_note = EXCLUDED.admin_note,
        updated_at = now();
    END IF;

    RETURN jsonb_build_object(
      'ok', true,
      'already_redeemed', true,
      'code', _coupon.code,
      'course_id', _course_id,
      'discount_percent', _existing.discount_percent,
      'discount_amount', _existing.discount_amount,
      'final_amount', _existing.final_amount,
      'enrolled', _existing.final_amount <= 0,
      'message', 'Coupon already redeemed for this course.'
    );
  END IF;

  SELECT count(*) INTO _user_redeem_count
  FROM public.coupon_redemptions
  WHERE coupon_id = _coupon.id AND user_id = _user_id AND status = 'redeemed';
  IF _coupon.per_user_limit > 0 AND _user_redeem_count >= _coupon.per_user_limit THEN
    RAISE EXCEPTION 'Per-student coupon limit is already used.';
  END IF;

  IF _coupon.max_uses > 0 AND _coupon.used_count >= _coupon.max_uses THEN
    UPDATE public.coupon_codes SET is_active = false, updated_at = now() WHERE id = _coupon.id;
    RAISE EXCEPTION 'Coupon usage limit is full.';
  END IF;

  _original_amount := GREATEST(COALESCE(_course.price, 0), 0);
  _discount_amount := LEAST(_original_amount, ROUND((_original_amount * _coupon.discount_percent) / 100.0)::integer);
  _final_amount := GREATEST(_original_amount - _discount_amount, 0);

  INSERT INTO public.coupon_redemptions (
    coupon_id, user_id, course_id, discount_percent, discount_amount, original_amount, final_amount, currency, status
  ) VALUES (
    _coupon.id, _user_id, _course_id, _coupon.discount_percent, _discount_amount, _original_amount, _final_amount, 'INR', 'redeemed'
  );

  UPDATE public.coupon_codes
  SET used_count = used_count + 1,
      is_active = CASE
        WHEN max_uses > 0 AND used_count + 1 >= max_uses THEN false
        ELSE is_active
      END,
      updated_at = now()
  WHERE id = _coupon.id;

  IF _final_amount <= 0 THEN
    INSERT INTO public.course_enrollments (
      user_id, course_id, status, source, payment_method, amount_paid, currency, admin_note
    ) VALUES (
      _user_id, _course_id, 'active', 'coupon', 'coupon', 0, 'INR', 'Coupon ' || _coupon.code || ' gave 100% discount'
    )
    ON CONFLICT (user_id, course_id) DO UPDATE SET
      status = 'active',
      source = 'coupon',
      payment_method = 'coupon',
      amount_paid = 0,
      admin_note = EXCLUDED.admin_note,
      updated_at = now();

    INSERT INTO public.payment_transactions (
      user_id, course_id, provider, status, amount, currency, admin_note, metadata
    ) VALUES (
      _user_id,
      _course_id,
      'coupon',
      'paid',
      0,
      'INR',
      'Coupon ' || _coupon.code || ' redeemed',
      jsonb_build_object(
        'coupon_id', _coupon.id,
        'code', _coupon.code,
        'discount_percent', _coupon.discount_percent,
        'discount_amount', _discount_amount,
        'original_amount', _original_amount
      )
    );
  END IF;

  RETURN jsonb_build_object(
    'ok', true,
    'already_redeemed', false,
    'code', _coupon.code,
    'course_id', _course_id,
    'discount_percent', _coupon.discount_percent,
    'discount_amount', _discount_amount,
    'final_amount', _final_amount,
    'enrolled', _final_amount <= 0,
    'message', 'Coupon redeemed successfully.'
  );
END;
$$;

REVOKE EXECUTE ON FUNCTION public.redeem_coupon_for_course(text, uuid) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.redeem_coupon_for_course(text, uuid) TO authenticated, service_role;


-- 9) Notifications + MCQ test questions --------------------------------------
-- Admin notifications + text-to-MCQ test questions.

CREATE TABLE IF NOT EXISTS public.test_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  test_id uuid NOT NULL REFERENCES public.tests(id) ON DELETE CASCADE,
  question_text text NOT NULL,
  subject text NOT NULL DEFAULT '',
  options text[] NOT NULL DEFAULT '{}',
  correct_index integer NOT NULL DEFAULT 0,
  marks integer NOT NULL DEFAULT 4,
  negative_marks integer NOT NULL DEFAULT 1,
  explanation text NOT NULL DEFAULT '',
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT test_questions_options_min CHECK (array_length(options, 1) >= 2),
  CONSTRAINT test_questions_correct_index_range CHECK (correct_index >= 0 AND correct_index < COALESCE(array_length(options, 1), 0)),
  CONSTRAINT test_questions_marks_nonnegative CHECK (marks >= 0 AND negative_marks >= 0)
);

ALTER TABLE public.test_questions
  ADD COLUMN IF NOT EXISTS subject text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS options text[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS correct_index integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS marks integer NOT NULL DEFAULT 4,
  ADD COLUMN IF NOT EXISTS negative_marks integer NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS explanation text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS sort_order integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

CREATE INDEX IF NOT EXISTS idx_test_questions_test_order ON public.test_questions(test_id, sort_order);

GRANT SELECT ON public.test_questions TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.test_questions TO authenticated;
GRANT ALL ON public.test_questions TO service_role;
ALTER TABLE public.test_questions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Published test questions are viewable by everyone" ON public.test_questions;
CREATE POLICY "Published test questions are viewable by everyone"
  ON public.test_questions FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM public.tests t
    WHERE t.id = test_questions.test_id
      AND t.is_published = true
      AND (t.course_id IS NULL OR EXISTS (
        SELECT 1 FROM public.courses c WHERE c.id = t.course_id AND c.status = 'published'
      ))
  ));

DROP POLICY IF EXISTS "Admins can manage test questions" ON public.test_questions;
CREATE POLICY "Admins can manage test questions"
  ON public.test_questions FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_test_questions_updated_at ON public.test_questions;
CREATE TRIGGER update_test_questions_updated_at
  BEFORE UPDATE ON public.test_questions
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.refresh_test_question_counts()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  tid uuid;
BEGIN
  tid := COALESCE(NEW.test_id, OLD.test_id);
  IF tid IS NULL THEN RETURN COALESCE(NEW, OLD); END IF;
  UPDATE public.tests t SET
    questions_count = (SELECT count(*) FROM public.test_questions q WHERE q.test_id = tid),
    total_marks = COALESCE((SELECT sum(q.marks) FROM public.test_questions q WHERE q.test_id = tid), 0),
    updated_at = now()
  WHERE t.id = tid;
  RETURN COALESCE(NEW, OLD);
END;
$$;

DROP TRIGGER IF EXISTS test_questions_refresh_counts ON public.test_questions;
CREATE TRIGGER test_questions_refresh_counts
  AFTER INSERT OR UPDATE OR DELETE ON public.test_questions
  FOR EACH ROW EXECUTE FUNCTION public.refresh_test_question_counts();

CREATE TABLE IF NOT EXISTS public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  message text NOT NULL DEFAULT '',
  type text NOT NULL DEFAULT 'announcement',
  audience text NOT NULL DEFAULT 'all',
  course_id uuid REFERENCES public.courses(id) ON DELETE SET NULL,
  priority text NOT NULL DEFAULT 'normal',
  action_label text NOT NULL DEFAULT '',
  action_url text NOT NULL DEFAULT '',
  is_published boolean NOT NULL DEFAULT true,
  send_at timestamptz,
  expires_at timestamptz,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT notifications_audience_check CHECK (audience IN ('all', 'students', 'admins', 'course')),
  CONSTRAINT notifications_priority_check CHECK (priority IN ('low', 'normal', 'high'))
);

ALTER TABLE public.notifications
  ADD COLUMN IF NOT EXISTS type text NOT NULL DEFAULT 'announcement',
  ADD COLUMN IF NOT EXISTS audience text NOT NULL DEFAULT 'all',
  ADD COLUMN IF NOT EXISTS course_id uuid REFERENCES public.courses(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS priority text NOT NULL DEFAULT 'normal',
  ADD COLUMN IF NOT EXISTS action_label text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS action_url text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS is_published boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS send_at timestamptz,
  ADD COLUMN IF NOT EXISTS expires_at timestamptz,
  ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

CREATE INDEX IF NOT EXISTS idx_notifications_visible ON public.notifications(is_published, send_at, expires_at, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_audience ON public.notifications(audience, course_id);

GRANT SELECT ON public.notifications TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public can read general published notifications" ON public.notifications;
CREATE POLICY "Public can read general published notifications"
  ON public.notifications FOR SELECT TO anon
  USING (
    is_published = true
    AND audience IN ('all', 'students')
    AND (send_at IS NULL OR send_at <= now())
    AND (expires_at IS NULL OR expires_at > now())
  );

DROP POLICY IF EXISTS "Authenticated users can read targeted published notifications" ON public.notifications;
CREATE POLICY "Authenticated users can read targeted published notifications"
  ON public.notifications FOR SELECT TO authenticated
  USING (
    is_published = true
    AND (send_at IS NULL OR send_at <= now())
    AND (expires_at IS NULL OR expires_at > now())
    AND (
      audience IN ('all', 'students')
      OR (audience = 'admins' AND public.has_role(auth.uid(), 'admin'))
      OR (
        audience = 'course'
        AND EXISTS (
          SELECT 1 FROM public.course_enrollments ce
          WHERE ce.user_id = auth.uid()
            AND ce.course_id = notifications.course_id
            AND ce.status = 'active'
        )
      )
    )
  );

DROP POLICY IF EXISTS "Admins can manage notifications" ON public.notifications;
CREATE POLICY "Admins can manage notifications"
  ON public.notifications FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_notifications_updated_at ON public.notifications;
CREATE TRIGGER update_notifications_updated_at
  BEFORE UPDATE ON public.notifications
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE IF NOT EXISTS public.notification_reads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  notification_id uuid NOT NULL REFERENCES public.notifications(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  read_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (notification_id, user_id)
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_notification_reads_unique ON public.notification_reads(notification_id, user_id);
CREATE INDEX IF NOT EXISTS idx_notification_reads_user ON public.notification_reads(user_id, read_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.notification_reads TO authenticated;
GRANT ALL ON public.notification_reads TO service_role;
ALTER TABLE public.notification_reads ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view their notification reads" ON public.notification_reads;
CREATE POLICY "Users can view their notification reads"
  ON public.notification_reads FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can mark their notifications read" ON public.notification_reads;
CREATE POLICY "Users can mark their notifications read"
  ON public.notification_reads FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can update their notification reads" ON public.notification_reads;
CREATE POLICY "Users can update their notification reads"
  ON public.notification_reads FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admins can view all notification reads" ON public.notification_reads;
CREATE POLICY "Admins can view all notification reads"
  ON public.notification_reads FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));



-- 10) Doubt centre + personal notifications -------------------------------
-- Student Doubt Centre + personal notifications + future-ready content update notifications.

ALTER TABLE IF EXISTS public.notifications
  ADD COLUMN IF NOT EXISTS target_user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE;

ALTER TABLE IF EXISTS public.notifications
  DROP CONSTRAINT IF EXISTS notifications_audience_check;

ALTER TABLE public.notifications
  ADD CONSTRAINT notifications_audience_check
  CHECK (audience IN ('all', 'students', 'admins', 'course', 'user'));

CREATE INDEX IF NOT EXISTS idx_notifications_target_user ON public.notifications(target_user_id, created_at DESC);

DROP POLICY IF EXISTS "Authenticated users can read targeted published notifications" ON public.notifications;
CREATE POLICY "Authenticated users can read targeted published notifications"
  ON public.notifications FOR SELECT TO authenticated
  USING (
    is_published = true
    AND (send_at IS NULL OR send_at <= now())
    AND (expires_at IS NULL OR expires_at > now())
    AND (
      audience IN ('all', 'students')
      OR (audience = 'admins' AND public.has_role(auth.uid(), 'admin'))
      OR (audience = 'user' AND target_user_id = auth.uid())
      OR (
        audience = 'course'
        AND EXISTS (
          SELECT 1 FROM public.course_enrollments ce
          WHERE ce.user_id = auth.uid()
            AND ce.course_id = notifications.course_id
            AND ce.status = 'active'
        )
      )
    )
  );

CREATE TABLE IF NOT EXISTS public.student_doubts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  course_id uuid REFERENCES public.courses(id) ON DELETE SET NULL,
  subject text NOT NULL DEFAULT 'General',
  title text NOT NULL,
  message text NOT NULL,
  attachment_url text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'open',
  priority text NOT NULL DEFAULT 'normal',
  admin_reply text NOT NULL DEFAULT '',
  answered_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  answered_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT student_doubts_status_check CHECK (status IN ('open', 'answered', 'closed')),
  CONSTRAINT student_doubts_priority_check CHECK (priority IN ('low', 'normal', 'high'))
);

ALTER TABLE public.student_doubts
  ADD COLUMN IF NOT EXISTS course_id uuid REFERENCES public.courses(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS subject text NOT NULL DEFAULT 'General',
  ADD COLUMN IF NOT EXISTS attachment_url text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'open',
  ADD COLUMN IF NOT EXISTS priority text NOT NULL DEFAULT 'normal',
  ADD COLUMN IF NOT EXISTS admin_reply text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS answered_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS answered_at timestamptz,
  ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

CREATE INDEX IF NOT EXISTS idx_student_doubts_user ON public.student_doubts(user_id, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_student_doubts_course ON public.student_doubts(course_id, status);
CREATE INDEX IF NOT EXISTS idx_student_doubts_status ON public.student_doubts(status, priority, updated_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.student_doubts TO authenticated;
GRANT ALL ON public.student_doubts TO service_role;
ALTER TABLE public.student_doubts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Students can create their own doubts" ON public.student_doubts;
CREATE POLICY "Students can create their own doubts"
  ON public.student_doubts FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Students can view their own doubts" ON public.student_doubts;
CREATE POLICY "Students can view their own doubts"
  ON public.student_doubts FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admins can manage all doubts" ON public.student_doubts;
CREATE POLICY "Admins can manage all doubts"
  ON public.student_doubts FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_student_doubts_updated_at ON public.student_doubts;
CREATE TRIGGER update_student_doubts_updated_at
  BEFORE UPDATE ON public.student_doubts
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();



-- 11) Admission enquiry CRM ----------------------------------------------
-- Admission / enquiry CRM for future admissions and follow-ups.

CREATE TABLE IF NOT EXISTS public.admission_enquiries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL DEFAULT '',
  class_level text NOT NULL DEFAULT '',
  interest text NOT NULL DEFAULT '',
  message text NOT NULL DEFAULT '',
  source text NOT NULL DEFAULT 'support',
  status text NOT NULL DEFAULT 'new',
  priority text NOT NULL DEFAULT 'normal',
  admin_note text NOT NULL DEFAULT '',
  last_contacted_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT admission_enquiries_status_check CHECK (status IN ('new', 'contacted', 'admitted', 'closed', 'spam')),
  CONSTRAINT admission_enquiries_priority_check CHECK (priority IN ('low', 'normal', 'high'))
);

ALTER TABLE public.admission_enquiries
  ADD COLUMN IF NOT EXISTS phone text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS class_level text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS interest text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS source text NOT NULL DEFAULT 'support',
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'new',
  ADD COLUMN IF NOT EXISTS priority text NOT NULL DEFAULT 'normal',
  ADD COLUMN IF NOT EXISTS admin_note text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS last_contacted_at timestamptz,
  ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

CREATE INDEX IF NOT EXISTS idx_admission_enquiries_status ON public.admission_enquiries(status, priority, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_admission_enquiries_email ON public.admission_enquiries(lower(email));
CREATE INDEX IF NOT EXISTS idx_admission_enquiries_phone ON public.admission_enquiries(phone);

GRANT INSERT ON public.admission_enquiries TO anon;
GRANT INSERT, SELECT, UPDATE, DELETE ON public.admission_enquiries TO authenticated;
GRANT ALL ON public.admission_enquiries TO service_role;
ALTER TABLE public.admission_enquiries ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anyone can submit admission enquiries" ON public.admission_enquiries;
CREATE POLICY "Anyone can submit admission enquiries"
  ON public.admission_enquiries FOR INSERT
  WITH CHECK (
    status = 'new'
    AND admin_note = ''
    AND last_contacted_at IS NULL
  );

DROP POLICY IF EXISTS "Admins can manage admission enquiries" ON public.admission_enquiries;
CREATE POLICY "Admins can manage admission enquiries"
  ON public.admission_enquiries FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_admission_enquiries_updated_at ON public.admission_enquiries;
CREATE TRIGGER update_admission_enquiries_updated_at
  BEFORE UPDATE ON public.admission_enquiries
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.notify_admins_on_admission_enquiry()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.notifications (
    title,
    message,
    type,
    audience,
    course_id,
    priority,
    action_label,
    action_url,
    is_published,
    send_at,
    expires_at,
    created_by
  ) VALUES (
    'New admission enquiry: ' || NEW.name,
    concat_ws(E'\n',
      'Name: ' || NEW.name,
      'Email: ' || NEW.email,
      CASE WHEN NEW.phone <> '' THEN 'Phone: ' || NEW.phone ELSE NULL END,
      CASE WHEN NEW.class_level <> '' THEN 'Class/target: ' || NEW.class_level ELSE NULL END,
      CASE WHEN NEW.interest <> '' THEN 'Interest: ' || NEW.interest ELSE NULL END,
      NEW.message
    ),
    'enquiry',
    'admins',
    NULL,
    NEW.priority,
    'Open enquiry',
    '/admin/enquiries',
    true,
    NULL,
    NULL,
    NULL
  );
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS admission_enquiries_notify_admins ON public.admission_enquiries;
CREATE TRIGGER admission_enquiries_notify_admins
  AFTER INSERT ON public.admission_enquiries
  FOR EACH ROW EXECUTE FUNCTION public.notify_admins_on_admission_enquiry();


-- Refresh counters for existing rows.
UPDATE public.tests t SET
  questions_count = (SELECT count(*) FROM public.test_questions q WHERE q.test_id = t.id),
  total_marks = COALESCE((SELECT sum(q.marks) FROM public.test_questions q WHERE q.test_id = t.id), 0);

UPDATE public.courses c SET
  lectures_count = (SELECT count(*) FROM public.lectures l WHERE l.course_id = c.id),
  materials_count = (SELECT count(*) FROM public.materials m WHERE m.course_id = c.id),
  tests_count = (SELECT count(*) FROM public.tests t WHERE t.course_id = c.id);

-- Final check message appears in SQL Results if everything above succeeded.
SELECT 'KKCC Supabase setup complete. Now sign up/login with kkcc23102003@gmail.com and open /admin.' AS status;

-- ============================================================================
-- 20260925000000_public_platform_stats.sql
-- Public aggregate counters for the website homepage.
-- This exposes only safe totals (no student names, emails, phones, or private data).
CREATE OR REPLACE FUNCTION public.get_public_platform_stats()
RETURNS TABLE (
  students_joined bigint,
  active_students bigint,
  published_courses bigint,
  published_lectures bigint,
  published_materials bigint,
  published_tests bigint
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    (
      SELECT count(*)
      FROM public.profiles p
      WHERE NOT EXISTS (
        SELECT 1
        FROM public.user_roles ur
        WHERE ur.user_id = p.id
          AND ur.role = 'admin'
      )
    ) AS students_joined,
    (
      SELECT count(DISTINCT ce.user_id)
      FROM public.course_enrollments ce
      WHERE ce.status = 'active'
        AND (ce.expires_at IS NULL OR ce.expires_at > now())
        AND NOT EXISTS (
          SELECT 1
          FROM public.user_roles ur
          WHERE ur.user_id = ce.user_id
            AND ur.role = 'admin'
        )
    ) AS active_students,
    (
      SELECT count(*)
      FROM public.courses c
      WHERE c.status = 'published'
    ) AS published_courses,
    (
      SELECT count(*)
      FROM public.lectures l
      INNER JOIN public.courses c ON c.id = l.course_id
      WHERE c.status = 'published'
    ) AS published_lectures,
    (
      SELECT count(*)
      FROM public.materials m
      WHERE m.is_published = true
    ) AS published_materials,
    (
      SELECT count(*)
      FROM public.tests t
      WHERE t.is_published = true
    ) AS published_tests;
$$;

REVOKE ALL ON FUNCTION public.get_public_platform_stats() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_public_platform_stats() TO anon, authenticated;

-- ============================================================================
-- 20260926000000_uv_logo_branding_refresh.sql
-- Refresh default logo/theme values to the new UV neon KKCC look.
-- This is safe for existing projects: it only replaces old bundled defaults or blank values.
UPDATE public.site_settings
SET value = CASE key
  WHEN 'brand_logo_url' THEN '/logo.png'
  WHEN 'brand_primary_color' THEN '#18f4d6'
  WHEN 'brand_accent_color' THEN '#f5d78e'
  WHEN 'brand_background_color' THEN '#050605'
  WHEN 'brand_foreground_color' THEN '#fff8e7'
  WHEN 'brand_hero_title' THEN 'KKCC Excellence Hub — Study That Makes You Return.'
  WHEN 'brand_hero_highlight' THEN 'Learn with clarity. Practice with courage. Rise with confidence.'
  WHEN 'brand_hero_description' THEN 'KKCC turns lectures, notes, tests, and progress into a bright daily learning loop — so students know exactly what to open next and feel excited to continue.'
  ELSE value
END,
updated_at = now()
WHERE (key = 'brand_logo_url' AND value IN ('', '/favicon.png'))
   OR (key = 'brand_primary_color' AND value IN ('', '#0f766e', '#ff174f'))
   OR (key = 'brand_accent_color' AND value IN ('', '#d9b66f', '#00e5ff'))
   OR (key = 'brand_background_color' AND value = '')
   OR (key = 'brand_foreground_color' AND value = '')
   OR (key = 'brand_hero_title' AND value IN ('Education That Builds Understanding.', 'KKCC Excellence Hub — Learn with Power.', 'KKCC Excellence Hub — Study That Makes You Return.'))
   OR (key = 'brand_hero_highlight' AND value IN ('Logo-Inspired UV Learning for Bright Futures.', 'Neon Smart Learning for Bright Futures.', 'Learning That Builds Futures.', 'KKCC Excellence Learning for Bright Futures.', 'Learn with clarity. Practice with courage. Rise with confidence.'))
   OR (key = 'brand_hero_description' AND value IN ('A bold digital classroom for real KKCC students — courses, lectures, notes, tests and progress in one colourful learning hub.', 'Learn from structured courses, expert guidance, smart practice and powerful study tools — all in one place.', 'KKCC brings courses, lectures, notes, tests, and progress tracking together in one colourful learning hub.', 'KKCC brings courses, lectures, notes, tests, and progress tracking together in one colorful learning hub.', 'KKCC turns lectures, notes, tests, and progress into a bright daily learning loop — so students know exactly what to open next and feel excited to continue.'));

INSERT INTO public.site_settings (key, value)
VALUES
  ('brand_logo_url', '/logo.png'),
  ('brand_primary_color', '#18f4d6'),
  ('brand_accent_color', '#f5d78e'),
  ('brand_background_color', '#050605'),
  ('brand_foreground_color', '#fff8e7'),
  ('brand_hero_title', 'KKCC Excellence Hub — Study That Makes You Return.'),
  ('brand_hero_highlight', 'Learn with clarity. Practice with courage. Rise with confidence.'),
  ('brand_hero_description', 'KKCC turns lectures, notes, tests, and progress into a bright daily learning loop — so students know exactly what to open next and feel excited to continue.')
ON CONFLICT (key) DO NOTHING;

-- ============================================================================
-- 20260926001000_logo_uv_palette_correction.sql
-- Correct the UV palette to match the supplied KKCC K-logo.
-- This safely replaces the earlier temporary red/cyan defaults if they were already applied.
UPDATE public.site_settings
SET value = CASE key
  WHEN 'brand_primary_color' THEN '#18f4d6'
  WHEN 'brand_accent_color' THEN '#f5d78e'
  WHEN 'brand_background_color' THEN '#050605'
  WHEN 'brand_foreground_color' THEN '#fff8e7'
  WHEN 'brand_hero_highlight' THEN 'Learn with clarity. Practice with courage. Rise with confidence.'
  ELSE value
END,
updated_at = now()
WHERE (key = 'brand_primary_color' AND value IN ('#ff174f', '#0f766e', ''))
   OR (key = 'brand_accent_color' AND value IN ('#00e5ff', '#d9b66f', ''))
   OR (key = 'brand_background_color' AND value IN ('#07040d', ''))
   OR (key = 'brand_foreground_color' AND value IN ('#fff7ff', ''))
   OR (key = 'brand_hero_highlight' AND value IN ('Logo-Inspired UV Learning for Bright Futures.', 'Neon Smart Learning for Bright Futures.', 'Learning That Builds Futures.', 'KKCC Excellence Learning for Bright Futures.', 'Learn with clarity. Practice with courage. Rise with confidence.'));

-- 20260926002000_student_comeback_copy_refresh.sql
-- Refresh default KKCC hero copy to the sharper student-comeback wording.
-- Safe for existing projects: only old bundled defaults are replaced, not custom admin text.
UPDATE public.site_settings
SET value = CASE key
  WHEN 'brand_hero_title' THEN 'KKCC Excellence Hub — Study That Makes You Return.'
  WHEN 'brand_hero_highlight' THEN 'Learn with clarity. Practice with courage. Rise with confidence.'
  WHEN 'brand_hero_description' THEN 'KKCC turns lectures, notes, tests, and progress into a bright daily learning loop — so students know exactly what to open next and feel excited to continue.'
  WHEN 'brand_cta_primary_label' THEN 'Find My Next Win'
  WHEN 'brand_cta_secondary_label' THEN 'Continue Learning'
  ELSE value
END,
updated_at = now()
WHERE (key = 'brand_hero_title' AND value IN ('Education That Builds Understanding.', 'KKCC Excellence Hub — Learn with Power.'))
   OR (key = 'brand_hero_highlight' AND value IN ('Logo-Inspired UV Learning for Bright Futures.', 'Neon Smart Learning for Bright Futures.', 'Learning That Builds Futures.', 'KKCC Excellence Learning for Bright Futures.'))
   OR (key = 'brand_hero_description' AND value IN ('A bold digital classroom for real KKCC students — courses, lectures, notes, tests and progress in one colourful learning hub.', 'Learn from structured courses, expert guidance, smart practice and powerful study tools — all in one place.', 'KKCC brings courses, lectures, notes, tests, and progress tracking together in one colourful learning hub.', 'KKCC brings courses, lectures, notes, tests, and progress tracking together in one colorful learning hub.'))
   OR (key = 'brand_cta_primary_label' AND value = 'Explore Courses')
   OR (key = 'brand_cta_secondary_label' AND value = 'Start Learning');

INSERT INTO public.site_settings (key, value)
VALUES
  ('brand_hero_title', 'KKCC Excellence Hub — Study That Makes You Return.'),
  ('brand_hero_highlight', 'Learn with clarity. Practice with courage. Rise with confidence.'),
  ('brand_hero_description', 'KKCC turns lectures, notes, tests, and progress into a bright daily learning loop — so students know exactly what to open next and feel excited to continue.'),
  ('brand_cta_primary_label', 'Find My Next Win'),
  ('brand_cta_secondary_label', 'Continue Learning')
ON CONFLICT (key) DO NOTHING;

-- 20260926003000_kaat_philosophy_hero_highlight.sql
-- Refresh default hero highlight to the KKCC 2-3-KAAT philosophy line.
-- Safe for existing projects: only old bundled/default hero highlights are replaced.
UPDATE public.site_settings
SET value = 'Learn with clarity. Practice with courage. Rise with confidence.',
updated_at = now()
WHERE key = 'brand_hero_highlight'
  AND value IN (
    'Logo-Inspired UV Learning for Bright Futures.',
    'Neon Smart Learning for Bright Futures.',
    'Learning That Builds Futures.',
    'KKCC Excellence Learning for Bright Futures.',
    'One focused session. One clear win. Every day.'
  );

INSERT INTO public.site_settings (key, value)
VALUES
  ('brand_hero_highlight', 'Learn with clarity. Practice with courage. Rise with confidence.')
ON CONFLICT (key) DO NOTHING;


-- 20260926004000_23kaat_hero_highlight.sql
-- Refresh default hero highlight to the 23KAAT philosophy line.
-- Safe for existing projects: only old bundled/default hero highlights are replaced.
UPDATE public.site_settings
SET value = 'Learn with clarity. Practice with courage. Rise with confidence.',
updated_at = now()
WHERE key = 'brand_hero_highlight'
  AND value IN (
    'Logo-Inspired UV Learning for Bright Futures.',
    'Neon Smart Learning for Bright Futures.',
    'Learning That Builds Futures.',
    'KKCC Excellence Learning for Bright Futures.',
    'One focused session. One clear win. Every day.',
    '2 — Double Vision · 3 — Three Tiers: Courage, Patience, Victory · K — Knowledge · A — Action · A — Ambition · T — Trust',
    '23KAAT :– 2 — Double Vision (aim and reality) · 3 — Three Tiers: Courage, Patience, Victory · K — Knowledge · A — Action · A — Ambition · T — Trust'
  );

INSERT INTO public.site_settings (key, value)
VALUES
  ('brand_hero_highlight', 'Learn with clarity. Practice with courage. Rise with confidence.')
ON CONFLICT (key) DO NOTHING;

-- 20260926005000_23kaat_rule_of_success_hero_highlight.sql
-- Refresh default hero highlight to the exact 23KAAT rule-of-success text.
-- Safe for existing projects: only old bundled/default hero highlights are replaced.
UPDATE public.site_settings
SET value = 'Learn with clarity. Practice with courage. Rise with confidence.',
updated_at = now()
WHERE key = 'brand_hero_highlight'
  AND value IN (
    'Logo-Inspired UV Learning for Bright Futures.',
    'Neon Smart Learning for Bright Futures.',
    'Learning That Builds Futures.',
    'KKCC Excellence Learning for Bright Futures.',
    'One focused session. One clear win. Every day.',
    '2 — Double Vision · 3 — Three Tiers: Courage, Patience, Victory · K — Knowledge · A — Action · A — Ambition · T — Trust',
    '23KAAT :– 2 — Double Vision (aim and reality) · 3 — Three Tiers: Courage, Patience, Victory · K — Knowledge · A — Action · A — Ambition · T — Trust',
    '23KAAT :– 2 — Double Vision ( aim and reality )· 3 — Three Tiers: Courage, Patience, Victory · K — Knowledge · A — Action · A — Ambition · T — Trust'
  );

INSERT INTO public.site_settings (key, value)
VALUES
  ('brand_hero_highlight', 'Learn with clarity. Practice with courage. Rise with confidence.')
ON CONFLICT (key) DO NOTHING;

-- 20260926006000_confidence_hero_highlight.sql
-- Refresh default hero highlight to a cleaner confidence-focused line.
-- Safe for existing projects: only old bundled/default/23KAAT hero highlights are replaced.
UPDATE public.site_settings
SET value = 'Learn with clarity. Practice with courage. Rise with confidence.',
updated_at = now()
WHERE key = 'brand_hero_highlight'
  AND (
    value IN (
    'Logo-Inspired UV Learning for Bright Futures.',
    'Neon Smart Learning for Bright Futures.',
    'Learning That Builds Futures.',
    'KKCC Excellence Learning for Bright Futures.',
    'One focused session. One clear win. Every day.',
    '2 — Double Vision · 3 — Three Tiers: Courage, Patience, Victory · K — Knowledge · A — Action · A — Ambition · T — Trust',
    '23KAAT :– 2 — Double Vision (aim and reality) · 3 — Three Tiers: Courage, Patience, Victory · K — Knowledge · A — Action · A — Ambition · T — Trust',
    '23KAAT :– 2 — Double Vision ( aim and reality )· 3 — Three Tiers: Courage, Patience, Victory · K — Knowledge · A — Action · A — Ambition · T — Trust'
    )
    OR value = $kkcc_old_23kaat$23KAAT is the rule of success

2 — Double Vision ( aim and reality )·

3 — Three Tiers (Courage, Patience, Victory) ·

K — Knowledge ·

A — Action ·

A — Ambition ·

T — Trust$kkcc_old_23kaat$
  );

INSERT INTO public.site_settings (key, value)
VALUES
  ('brand_hero_highlight', 'Learn with clarity. Practice with courage. Rise with confidence.')
ON CONFLICT (key) DO NOTHING;

-- 20260926007000_hybrid_ui_text_manager.sql
-- Seed safe hybrid UI text defaults for the admin Text Manager.
-- Safe for existing projects: this only inserts the key when it is missing.
INSERT INTO public.site_settings (key, value)
VALUES
  ('ui_text_json', $kkcc_ui_text${"auth":{"side_heading":"Education That Builds Understanding. Learning That Builds Futures.","side_description":"Learn Better. Understand Deeper. Achieve More.","login_title":"Welcome back","login_description":"Sign in to continue your lectures, tests and revision.","login_submit_label":"Sign in","login_footer_prompt":"New to KKCC?","login_footer_link":"Create an account","forgot_password_label":"Forgot password?","secure_login_title":"Secure student login","secure_login_description":"Your session is safely stored in this browser; dashboard and admin routes stay protected.","signup_title":"Create your KKCC account","signup_description":"Join KKCC to access courses, tests, notes and your learning progress.","signup_submit_label":"Create account","signup_footer_prompt":"Already have an account?","signup_footer_link":"Sign in","signup_success_title":"Check your email","signup_success_description":"Your KKCC account was created. If email confirmation is enabled, open the verification link before signing in.","forgot_title":"Reset your password","forgot_description":"Enter your registered email and we will send a secure reset link.","forgot_submit_label":"Send reset link","forgot_back_label":"Back to login","forgot_success_title":"Check your email","forgot_success_description":"If this email is registered with KKCC, a password reset link has been sent.","reset_title":"Set a new password","reset_description":"Choose a strong password to continue your KKCC learning journey.","reset_submit_label":"Update password","reset_success_title":"Password updated","reset_success_description":"You can now sign in with your new password."},"dashboard":{"welcome_eyebrow":"Welcome back","welcome_title":"Your learning today","student_section_label":"Student Section","student_profile_title":"Profile & batch validity","student_profile_description":"View your profile, enrolled batches/courses, payment source, and remaining validity in one place.","active_batches_title":"My active batches","no_active_batch_title":"No active batch right now","no_active_batch_description":"Start a free batch or contact KKCC support to activate paid/offline access.","browse_courses_label":"Explore courses","support_cta_title":"Need access extension?","support_cta_description":"If your validity is about to expire, send a message from the Support page for renewal help.","support_cta_label":"Contact support"},"system":{"not_found_title":"Page not found","not_found_description":"The page you're looking for doesn't exist or has been moved.","not_found_home_label":"Go home","error_title":"This page didn't load","error_description":"Something went wrong on our end. You can try refreshing or head back home.","error_retry_label":"Try again","error_home_label":"Go home","install_title":"Install KKCC for a faster app feel","install_chrome_description":"Add it from Chrome to open full screen, launch quickly, and keep core files cached.","install_ios_description":"On iPhone or iPad, open the browser share menu and choose Add to Home Screen.","install_button_label":"Install app","offline_title":"You are offline","offline_description":"KKCC is ready to continue when your connection returns. Some recently opened pages and app files may still work from cache.","offline_retry_label":"Try again"}}$kkcc_ui_text$)
ON CONFLICT (key) DO NOTHING;

-- Migration: 20260929090000_lecture_linked_materials_and_tests.sql
-- KKCC lecture-linked study packs + optional paid notes
-- Run this after the previous KKCC migrations. It is additive and non-destructive.

ALTER TABLE public.materials
  ADD COLUMN IF NOT EXISTS lecture_id uuid REFERENCES public.lectures(id) ON DELETE SET NULL;

ALTER TABLE public.materials
  ADD COLUMN IF NOT EXISTS access_type text NOT NULL DEFAULT 'course';

ALTER TABLE public.materials
  ADD COLUMN IF NOT EXISTS price integer NOT NULL DEFAULT 0;

ALTER TABLE public.tests
  ADD COLUMN IF NOT EXISTS lecture_id uuid REFERENCES public.lectures(id) ON DELETE SET NULL;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'materials_access_type_check'
      AND conrelid = 'public.materials'::regclass
  ) THEN
    ALTER TABLE public.materials
      ADD CONSTRAINT materials_access_type_check
      CHECK (access_type IN ('course', 'free', 'paid'));
  END IF;

  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'materials_price_check'
      AND conrelid = 'public.materials'::regclass
  ) THEN
    ALTER TABLE public.materials
      ADD CONSTRAINT materials_price_check
      CHECK (price >= 0);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_materials_lecture ON public.materials(lecture_id, sort_order);
CREATE INDEX IF NOT EXISTS idx_materials_access_type ON public.materials(access_type, price);
CREATE INDEX IF NOT EXISTS idx_tests_lecture ON public.tests(lecture_id, sort_order);

COMMENT ON COLUMN public.materials.lecture_id IS 'Optional lecture this note/PDF/resource is attached to.';
COMMENT ON COLUMN public.materials.access_type IS 'course = included with course access, free = open/free note, paid = standalone paid note.';
COMMENT ON COLUMN public.materials.price IS 'Standalone material price in INR paise-free whole rupees for KKCC admin UI.';
COMMENT ON COLUMN public.tests.lecture_id IS 'Optional lecture this test/practice set is attached to.';

-- Migration: 20260929100000_student_blocks_and_secure_video.sql
-- KKCC student app block/unblock security
-- Additive and non-destructive. Students cannot remove their own block.

CREATE TABLE IF NOT EXISTS public.student_blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  is_active boolean NOT NULL DEFAULT true,
  reason text NOT NULL DEFAULT '',
  blocked_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  blocked_at timestamptz NOT NULL DEFAULT now(),
  unblocked_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  unblocked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id)
);

ALTER TABLE public.student_blocks
  ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS reason text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS blocked_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS blocked_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS unblocked_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS unblocked_at timestamptz,
  ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'student_blocks_user_id_key'
      AND conrelid = 'public.student_blocks'::regclass
  ) THEN
    ALTER TABLE public.student_blocks ADD CONSTRAINT student_blocks_user_id_key UNIQUE (user_id);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_student_blocks_active ON public.student_blocks(user_id, is_active);
CREATE INDEX IF NOT EXISTS idx_student_blocks_blocked_at ON public.student_blocks(blocked_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.student_blocks TO authenticated;
GRANT ALL ON public.student_blocks TO service_role;
ALTER TABLE public.student_blocks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own block status" ON public.student_blocks;
CREATE POLICY "Users can view own block status"
  ON public.student_blocks FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admins can view all student blocks" ON public.student_blocks;
CREATE POLICY "Admins can view all student blocks"
  ON public.student_blocks FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins can manage student blocks" ON public.student_blocks;
CREATE POLICY "Admins can manage student blocks"
  ON public.student_blocks FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_student_blocks_updated_at ON public.student_blocks;
CREATE TRIGGER update_student_blocks_updated_at
  BEFORE UPDATE ON public.student_blocks
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.is_user_blocked(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.student_blocks sb
    WHERE sb.user_id = _user_id
      AND sb.is_active = true
  )
$$;

CREATE OR REPLACE FUNCTION public.get_my_block_status()
RETURNS TABLE(is_blocked boolean, reason text, blocked_at timestamptz)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    COALESCE(sb.is_active, false) AS is_blocked,
    COALESCE(sb.reason, '') AS reason,
    sb.blocked_at
  FROM (SELECT auth.uid() AS uid) me
  LEFT JOIN public.student_blocks sb
    ON sb.user_id = me.uid
   AND sb.is_active = true
  LIMIT 1
$$;

REVOKE EXECUTE ON FUNCTION public.is_user_blocked(uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.get_my_block_status() FROM anon, public;
GRANT EXECUTE ON FUNCTION public.is_user_blocked(uuid) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.get_my_block_status() TO authenticated, service_role;

-- Migration: 20260929110000_23kaat_coin_wallet.sql
-- KKCC 23KAAT coin currency wallet
-- 1 coin = ₹1 app credit for KKCC purchases unless admin changes pricing copy later.
-- All grant/spend operations are server-side database functions; students cannot edit their balance.

CREATE TABLE IF NOT EXISTS public.coin_packages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT '23KAAT Coin Pack',
  coins integer NOT NULL DEFAULT 0,
  bonus_coins integer NOT NULL DEFAULT 0,
  price integer NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'INR',
  description text NOT NULL DEFAULT '',
  is_active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (coins >= 0),
  CHECK (bonus_coins >= 0),
  CHECK (price >= 0)
);

CREATE TABLE IF NOT EXISTS public.coin_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount integer NOT NULL,
  source text NOT NULL DEFAULT 'admin_grant',
  reason text NOT NULL DEFAULT '',
  related_type text NOT NULL DEFAULT '',
  related_id uuid,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (amount <> 0)
);

CREATE TABLE IF NOT EXISTS public.material_purchases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  material_id uuid NOT NULL REFERENCES public.materials(id) ON DELETE CASCADE,
  paid_coins integer NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'active',
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, material_id),
  CHECK (paid_coins >= 0)
);

CREATE INDEX IF NOT EXISTS idx_coin_transactions_user ON public.coin_transactions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_coin_transactions_source ON public.coin_transactions(source, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_coin_packages_active ON public.coin_packages(is_active, sort_order);
CREATE INDEX IF NOT EXISTS idx_material_purchases_user ON public.material_purchases(user_id, status);
CREATE INDEX IF NOT EXISTS idx_material_purchases_material ON public.material_purchases(material_id, status);

GRANT SELECT ON public.coin_packages TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.coin_packages TO authenticated;
GRANT SELECT ON public.coin_transactions TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.coin_transactions TO authenticated;
GRANT SELECT ON public.material_purchases TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.material_purchases TO authenticated;
GRANT ALL ON public.coin_packages, public.coin_transactions, public.material_purchases TO service_role;

ALTER TABLE public.coin_packages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.coin_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.material_purchases ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Active coin packages are public" ON public.coin_packages;
CREATE POLICY "Active coin packages are public"
  ON public.coin_packages FOR SELECT
  USING (is_active OR public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins manage coin packages" ON public.coin_packages;
CREATE POLICY "Admins manage coin packages"
  ON public.coin_packages FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Users view own coin transactions" ON public.coin_transactions;
CREATE POLICY "Users view own coin transactions"
  ON public.coin_transactions FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admins view all coin transactions" ON public.coin_transactions;
CREATE POLICY "Admins view all coin transactions"
  ON public.coin_transactions FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins manage coin transactions" ON public.coin_transactions;
CREATE POLICY "Admins manage coin transactions"
  ON public.coin_transactions FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Users view own material purchases" ON public.material_purchases;
CREATE POLICY "Users view own material purchases"
  ON public.material_purchases FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admins view all material purchases" ON public.material_purchases;
CREATE POLICY "Admins view all material purchases"
  ON public.material_purchases FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins manage material purchases" ON public.material_purchases;
CREATE POLICY "Admins manage material purchases"
  ON public.material_purchases FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_coin_packages_updated_at ON public.coin_packages;
CREATE TRIGGER update_coin_packages_updated_at
  BEFORE UPDATE ON public.coin_packages
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

DROP TRIGGER IF EXISTS update_material_purchases_updated_at ON public.material_purchases;
CREATE TRIGGER update_material_purchases_updated_at
  BEFORE UPDATE ON public.material_purchases
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.get_23kaat_balance(_user_id uuid)
RETURNS integer
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(SUM(amount), 0)::integer
  FROM public.coin_transactions
  WHERE user_id = _user_id
$$;

CREATE OR REPLACE FUNCTION public.grant_23kaat_to_user(
  _user_id uuid,
  _amount integer,
  _reason text DEFAULT 'Admin grant',
  _related_type text DEFAULT '',
  _related_id uuid DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  next_balance integer;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Login required';
  END IF;
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Forbidden — admin access required';
  END IF;
  IF _amount IS NULL OR _amount <= 0 OR _amount > 10000000 THEN
    RAISE EXCEPTION 'Enter a valid 23KAAT amount';
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext(_user_id::text));

  INSERT INTO public.coin_transactions(user_id, amount, source, reason, related_type, related_id, created_by)
  VALUES (_user_id, _amount, 'admin_grant', COALESCE(NULLIF(_reason, ''), 'Admin grant'), COALESCE(_related_type, ''), _related_id, auth.uid());

  next_balance := public.get_23kaat_balance(_user_id);
  RETURN jsonb_build_object('ok', true, 'user_id', _user_id, 'amount', _amount, 'balance', next_balance);
END;
$$;

CREATE OR REPLACE FUNCTION public.spend_23kaat_for_course(_course_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid uuid := auth.uid();
  course_row public.courses%ROWTYPE;
  current_balance integer;
  cost integer;
BEGIN
  IF uid IS NULL THEN
    RAISE EXCEPTION 'Login required';
  END IF;
  IF public.is_user_blocked(uid) THEN
    RAISE EXCEPTION 'Account blocked by admin';
  END IF;

  SELECT * INTO course_row
  FROM public.courses
  WHERE id = _course_id AND status = 'published';
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Course not found';
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.course_enrollments
    WHERE user_id = uid AND course_id = _course_id AND status = 'active'
      AND (expires_at IS NULL OR expires_at > now())
  ) THEN
    RETURN jsonb_build_object('ok', true, 'already_owned', true, 'balance', public.get_23kaat_balance(uid));
  END IF;

  cost := GREATEST(0, COALESCE(course_row.price, 0));
  IF cost = 0 THEN
    INSERT INTO public.course_enrollments(user_id, course_id, status, source, payment_method, amount_paid, currency, admin_note)
    VALUES (uid, _course_id, 'active', 'free', 'free', 0, 'INR', 'Free course self-start')
    ON CONFLICT (user_id, course_id) DO UPDATE SET
      status = 'active', source = 'free', payment_method = 'free', amount_paid = 0, currency = 'INR', updated_at = now();
    RETURN jsonb_build_object('ok', true, 'free', true, 'balance', public.get_23kaat_balance(uid));
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext(uid::text));
  current_balance := public.get_23kaat_balance(uid);
  IF current_balance < cost THEN
    RAISE EXCEPTION 'Not enough 23KAAT coins. Need %, available %.', cost, current_balance;
  END IF;

  INSERT INTO public.coin_transactions(user_id, amount, source, reason, related_type, related_id, created_by)
  VALUES (uid, -cost, 'course_purchase', 'Course purchase: ' || course_row.title, 'course', _course_id, uid);

  INSERT INTO public.course_enrollments(user_id, course_id, status, source, payment_method, amount_paid, currency, admin_note, created_by)
  VALUES (uid, _course_id, 'active', '23kaat', '23KAAT Coins', cost, '23KAAT', 'Unlocked with 23KAAT coins', uid)
  ON CONFLICT (user_id, course_id) DO UPDATE SET
    status = 'active', source = '23kaat', payment_method = '23KAAT Coins', amount_paid = cost,
    currency = '23KAAT', admin_note = 'Unlocked with 23KAAT coins', updated_at = now();

  RETURN jsonb_build_object('ok', true, 'spent', cost, 'balance', public.get_23kaat_balance(uid));
END;
$$;

CREATE OR REPLACE FUNCTION public.get_my_material_access_url(_material_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid uuid := auth.uid();
  material_row public.materials%ROWTYPE;
  course_price integer;
  has_course_access boolean;
  has_purchase boolean;
  balance integer;
BEGIN
  IF uid IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'locked', true, 'reason', 'login_required');
  END IF;
  IF public.is_user_blocked(uid) THEN
    RETURN jsonb_build_object('ok', false, 'locked', true, 'reason', 'blocked');
  END IF;

  SELECT * INTO material_row
  FROM public.materials
  WHERE id = _material_id AND is_published = true;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'locked', true, 'reason', 'not_found');
  END IF;

  IF COALESCE(material_row.access_type, 'course') = 'free' THEN
    RETURN jsonb_build_object('ok', true, 'locked', false, 'file_url', material_row.file_url, 'price', 0);
  END IF;

  IF COALESCE(material_row.access_type, 'course') = 'paid' THEN
    SELECT EXISTS(
      SELECT 1 FROM public.material_purchases
      WHERE user_id = uid AND material_id = _material_id AND status = 'active'
    ) INTO has_purchase;
    IF has_purchase THEN
      RETURN jsonb_build_object('ok', true, 'locked', false, 'file_url', material_row.file_url, 'price', material_row.price);
    END IF;
    balance := public.get_23kaat_balance(uid);
    RETURN jsonb_build_object('ok', true, 'locked', true, 'reason', 'paid', 'price', material_row.price, 'balance', balance);
  END IF;

  IF material_row.course_id IS NULL THEN
    RETURN jsonb_build_object('ok', true, 'locked', false, 'file_url', material_row.file_url, 'price', 0);
  END IF;

  SELECT COALESCE(price, 0) INTO course_price FROM public.courses WHERE id = material_row.course_id AND status = 'published';
  IF COALESCE(course_price, 0) <= 0 THEN
    RETURN jsonb_build_object('ok', true, 'locked', false, 'file_url', material_row.file_url, 'price', 0);
  END IF;

  SELECT EXISTS(
    SELECT 1 FROM public.course_enrollments
    WHERE user_id = uid AND course_id = material_row.course_id AND status = 'active'
      AND (expires_at IS NULL OR expires_at > now())
  ) INTO has_course_access;

  IF has_course_access THEN
    RETURN jsonb_build_object('ok', true, 'locked', false, 'file_url', material_row.file_url, 'price', 0);
  END IF;

  RETURN jsonb_build_object('ok', true, 'locked', true, 'reason', 'course_required', 'price', course_price, 'balance', public.get_23kaat_balance(uid));
END;
$$;

CREATE OR REPLACE FUNCTION public.spend_23kaat_for_material(_material_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid uuid := auth.uid();
  material_row public.materials%ROWTYPE;
  current_balance integer;
  cost integer;
BEGIN
  IF uid IS NULL THEN
    RAISE EXCEPTION 'Login required';
  END IF;
  IF public.is_user_blocked(uid) THEN
    RAISE EXCEPTION 'Account blocked by admin';
  END IF;

  SELECT * INTO material_row
  FROM public.materials
  WHERE id = _material_id AND is_published = true;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Material not found';
  END IF;

  IF COALESCE(material_row.access_type, 'course') <> 'paid' THEN
    RETURN public.get_my_material_access_url(_material_id);
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.material_purchases
    WHERE user_id = uid AND material_id = _material_id AND status = 'active'
  ) THEN
    RETURN jsonb_build_object('ok', true, 'already_owned', true, 'file_url', material_row.file_url, 'balance', public.get_23kaat_balance(uid));
  END IF;

  cost := GREATEST(0, COALESCE(material_row.price, 0));
  IF cost <= 0 THEN
    INSERT INTO public.material_purchases(user_id, material_id, paid_coins, status, created_by)
    VALUES (uid, _material_id, 0, 'active', uid)
    ON CONFLICT (user_id, material_id) DO UPDATE SET status = 'active', updated_at = now();
    RETURN jsonb_build_object('ok', true, 'free', true, 'file_url', material_row.file_url, 'balance', public.get_23kaat_balance(uid));
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext(uid::text));
  current_balance := public.get_23kaat_balance(uid);
  IF current_balance < cost THEN
    RAISE EXCEPTION 'Not enough 23KAAT coins. Need %, available %.', cost, current_balance;
  END IF;

  INSERT INTO public.coin_transactions(user_id, amount, source, reason, related_type, related_id, created_by)
  VALUES (uid, -cost, 'material_purchase', 'Notes/material purchase: ' || material_row.title, 'material', _material_id, uid);

  INSERT INTO public.material_purchases(user_id, material_id, paid_coins, status, created_by)
  VALUES (uid, _material_id, cost, 'active', uid)
  ON CONFLICT (user_id, material_id) DO UPDATE SET
    paid_coins = EXCLUDED.paid_coins,
    status = 'active',
    updated_at = now();

  RETURN jsonb_build_object('ok', true, 'spent', cost, 'file_url', material_row.file_url, 'balance', public.get_23kaat_balance(uid));
END;
$$;

REVOKE EXECUTE ON FUNCTION public.get_23kaat_balance(uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.grant_23kaat_to_user(uuid, integer, text, text, uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.spend_23kaat_for_course(uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.get_my_material_access_url(uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.spend_23kaat_for_material(uuid) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.get_23kaat_balance(uuid) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.grant_23kaat_to_user(uuid, integer, text, text, uuid) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.spend_23kaat_for_course(uuid) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.get_my_material_access_url(uuid) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.spend_23kaat_for_material(uuid) TO authenticated, service_role;

INSERT INTO public.coin_packages(title, coins, bonus_coins, price, description, sort_order)
VALUES
  ('Starter 23KAAT Pack', 100, 0, 100, 'Use 23KAAT coins for courses and paid notes.', 1),
  ('Smart 23KAAT Pack', 500, 50, 500, 'Bonus coins for regular KKCC learners.', 2),
  ('Champion 23KAAT Pack', 1000, 150, 1000, 'Best for full batches and notes.', 3)
ON CONFLICT DO NOTHING;

-- MIGRATION: 20260929120000_coin_price_and_standalone_coin_buy.sql
-- KKCC 23KAAT coin pricing refresh
-- Adds separate coin prices for courses/batches and standalone paid notes/materials.
-- Rupee price and 23KAAT price can now be different; when coin_price is 0/blank,
-- paid content falls back to the rupee price to avoid accidental free unlocks.

ALTER TABLE public.courses
  ADD COLUMN IF NOT EXISTS coin_price integer NOT NULL DEFAULT 0;

ALTER TABLE public.materials
  ADD COLUMN IF NOT EXISTS coin_price integer NOT NULL DEFAULT 0;

UPDATE public.courses
SET coin_price = GREATEST(0, COALESCE(price, 0))
WHERE COALESCE(coin_price, 0) = 0 AND COALESCE(price, 0) > 0;

UPDATE public.materials
SET coin_price = GREATEST(0, COALESCE(price, 0))
WHERE COALESCE(coin_price, 0) = 0 AND COALESCE(price, 0) > 0;

ALTER TABLE public.courses
  DROP CONSTRAINT IF EXISTS courses_coin_price_non_negative;
ALTER TABLE public.courses
  ADD CONSTRAINT courses_coin_price_non_negative CHECK (coin_price >= 0);

ALTER TABLE public.materials
  DROP CONSTRAINT IF EXISTS materials_coin_price_non_negative;
ALTER TABLE public.materials
  ADD CONSTRAINT materials_coin_price_non_negative CHECK (coin_price >= 0);

CREATE OR REPLACE FUNCTION public.spend_23kaat_for_course(_course_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid uuid := auth.uid();
  course_row public.courses%ROWTYPE;
  current_balance integer;
  cost integer;
BEGIN
  IF uid IS NULL THEN
    RAISE EXCEPTION 'Login required';
  END IF;
  IF public.is_user_blocked(uid) THEN
    RAISE EXCEPTION 'Account blocked by admin';
  END IF;

  SELECT * INTO course_row
  FROM public.courses
  WHERE id = _course_id AND status = 'published';
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Course not found';
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.course_enrollments
    WHERE user_id = uid AND course_id = _course_id AND status = 'active'
      AND (expires_at IS NULL OR expires_at > now())
  ) THEN
    RETURN jsonb_build_object('ok', true, 'already_owned', true, 'balance', public.get_23kaat_balance(uid));
  END IF;

  cost := CASE
    WHEN COALESCE(course_row.price, 0) <= 0 THEN 0
    WHEN COALESCE(course_row.coin_price, 0) > 0 THEN GREATEST(0, course_row.coin_price)
    ELSE GREATEST(0, COALESCE(course_row.price, 0))
  END;

  IF cost = 0 THEN
    INSERT INTO public.course_enrollments(user_id, course_id, status, source, payment_method, amount_paid, currency, admin_note)
    VALUES (uid, _course_id, 'active', 'free', 'free', 0, 'INR', 'Free course self-start')
    ON CONFLICT (user_id, course_id) DO UPDATE SET
      status = 'active', source = 'free', payment_method = 'free', amount_paid = 0, currency = 'INR', updated_at = now();
    RETURN jsonb_build_object('ok', true, 'free', true, 'spent', 0, 'price', 0, 'rupee_price', COALESCE(course_row.price, 0), 'coin_price', 0, 'balance', public.get_23kaat_balance(uid));
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext(uid::text));
  current_balance := public.get_23kaat_balance(uid);
  IF current_balance < cost THEN
    RAISE EXCEPTION 'Not enough 23KAAT coins. Need %, available %.', cost, current_balance;
  END IF;

  INSERT INTO public.coin_transactions(user_id, amount, source, reason, related_type, related_id, created_by)
  VALUES (uid, -cost, 'course_purchase', 'Course purchase: ' || course_row.title, 'course', _course_id, uid);

  INSERT INTO public.course_enrollments(user_id, course_id, status, source, payment_method, amount_paid, currency, admin_note, created_by)
  VALUES (uid, _course_id, 'active', '23kaat', '23KAAT Coins', cost, '23KAAT', 'Unlocked with 23KAAT coins', uid)
  ON CONFLICT (user_id, course_id) DO UPDATE SET
    status = 'active', source = '23kaat', payment_method = '23KAAT Coins', amount_paid = cost,
    currency = '23KAAT', admin_note = 'Unlocked with 23KAAT coins', updated_at = now();

  RETURN jsonb_build_object('ok', true, 'spent', cost, 'price', cost, 'rupee_price', COALESCE(course_row.price, 0), 'coin_price', cost, 'balance', public.get_23kaat_balance(uid));
END;
$$;

CREATE OR REPLACE FUNCTION public.get_my_material_access_url(_material_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid uuid := auth.uid();
  material_row public.materials%ROWTYPE;
  course_price integer;
  course_coin_price integer;
  course_cost integer;
  material_cost integer;
  has_course_access boolean;
  has_purchase boolean;
  balance integer;
BEGIN
  IF uid IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'locked', true, 'reason', 'login_required');
  END IF;
  IF public.is_user_blocked(uid) THEN
    RETURN jsonb_build_object('ok', false, 'locked', true, 'reason', 'blocked');
  END IF;

  SELECT * INTO material_row
  FROM public.materials
  WHERE id = _material_id AND is_published = true;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'locked', true, 'reason', 'not_found');
  END IF;

  IF COALESCE(material_row.access_type, 'course') = 'free' THEN
    RETURN jsonb_build_object('ok', true, 'locked', false, 'file_url', material_row.file_url, 'price', 0, 'rupee_price', 0, 'coin_price', 0);
  END IF;

  IF COALESCE(material_row.access_type, 'course') = 'paid' THEN
    material_cost := CASE
      WHEN COALESCE(material_row.price, 0) <= 0 THEN 0
      WHEN COALESCE(material_row.coin_price, 0) > 0 THEN GREATEST(0, material_row.coin_price)
      ELSE GREATEST(0, COALESCE(material_row.price, 0))
    END;

    SELECT EXISTS(
      SELECT 1 FROM public.material_purchases
      WHERE user_id = uid AND material_id = _material_id AND status = 'active'
    ) INTO has_purchase;
    IF has_purchase THEN
      RETURN jsonb_build_object('ok', true, 'locked', false, 'file_url', material_row.file_url, 'price', material_cost, 'rupee_price', COALESCE(material_row.price, 0), 'coin_price', material_cost);
    END IF;
    balance := public.get_23kaat_balance(uid);
    RETURN jsonb_build_object('ok', true, 'locked', true, 'reason', 'paid', 'price', material_cost, 'rupee_price', COALESCE(material_row.price, 0), 'coin_price', material_cost, 'balance', balance);
  END IF;

  IF material_row.course_id IS NULL THEN
    RETURN jsonb_build_object('ok', true, 'locked', false, 'file_url', material_row.file_url, 'price', 0, 'rupee_price', 0, 'coin_price', 0);
  END IF;

  SELECT COALESCE(price, 0), COALESCE(coin_price, 0)
  INTO course_price, course_coin_price
  FROM public.courses
  WHERE id = material_row.course_id AND status = 'published';

  course_cost := CASE
    WHEN COALESCE(course_price, 0) <= 0 THEN 0
    WHEN COALESCE(course_coin_price, 0) > 0 THEN GREATEST(0, course_coin_price)
    ELSE GREATEST(0, COALESCE(course_price, 0))
  END;

  IF COALESCE(course_price, 0) <= 0 THEN
    RETURN jsonb_build_object('ok', true, 'locked', false, 'file_url', material_row.file_url, 'price', 0, 'rupee_price', 0, 'coin_price', 0);
  END IF;

  SELECT EXISTS(
    SELECT 1 FROM public.course_enrollments
    WHERE user_id = uid AND course_id = material_row.course_id AND status = 'active'
      AND (expires_at IS NULL OR expires_at > now())
  ) INTO has_course_access;

  IF has_course_access THEN
    RETURN jsonb_build_object('ok', true, 'locked', false, 'file_url', material_row.file_url, 'price', 0, 'rupee_price', 0, 'coin_price', 0);
  END IF;

  RETURN jsonb_build_object('ok', true, 'locked', true, 'reason', 'course_required', 'price', course_cost, 'rupee_price', course_price, 'coin_price', course_cost, 'balance', public.get_23kaat_balance(uid));
END;
$$;

CREATE OR REPLACE FUNCTION public.spend_23kaat_for_material(_material_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid uuid := auth.uid();
  material_row public.materials%ROWTYPE;
  current_balance integer;
  cost integer;
BEGIN
  IF uid IS NULL THEN
    RAISE EXCEPTION 'Login required';
  END IF;
  IF public.is_user_blocked(uid) THEN
    RAISE EXCEPTION 'Account blocked by admin';
  END IF;

  SELECT * INTO material_row
  FROM public.materials
  WHERE id = _material_id AND is_published = true;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Material not found';
  END IF;

  IF COALESCE(material_row.access_type, 'course') <> 'paid' THEN
    RETURN public.get_my_material_access_url(_material_id);
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.material_purchases
    WHERE user_id = uid AND material_id = _material_id AND status = 'active'
  ) THEN
    RETURN jsonb_build_object('ok', true, 'already_owned', true, 'file_url', material_row.file_url, 'balance', public.get_23kaat_balance(uid));
  END IF;

  cost := CASE
    WHEN COALESCE(material_row.price, 0) <= 0 THEN 0
    WHEN COALESCE(material_row.coin_price, 0) > 0 THEN GREATEST(0, material_row.coin_price)
    ELSE GREATEST(0, COALESCE(material_row.price, 0))
  END;

  IF cost <= 0 THEN
    INSERT INTO public.material_purchases(user_id, material_id, paid_coins, status, created_by)
    VALUES (uid, _material_id, 0, 'active', uid)
    ON CONFLICT (user_id, material_id) DO UPDATE SET status = 'active', updated_at = now();
    RETURN jsonb_build_object('ok', true, 'free', true, 'spent', 0, 'price', 0, 'rupee_price', COALESCE(material_row.price, 0), 'coin_price', 0, 'file_url', material_row.file_url, 'balance', public.get_23kaat_balance(uid));
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext(uid::text));
  current_balance := public.get_23kaat_balance(uid);
  IF current_balance < cost THEN
    RAISE EXCEPTION 'Not enough 23KAAT coins. Need %, available %.', cost, current_balance;
  END IF;

  INSERT INTO public.coin_transactions(user_id, amount, source, reason, related_type, related_id, created_by)
  VALUES (uid, -cost, 'material_purchase', 'Notes/material purchase: ' || material_row.title, 'material', _material_id, uid);

  INSERT INTO public.material_purchases(user_id, material_id, paid_coins, status, created_by)
  VALUES (uid, _material_id, cost, 'active', uid)
  ON CONFLICT (user_id, material_id) DO UPDATE SET
    paid_coins = EXCLUDED.paid_coins,
    status = 'active',
    updated_at = now();

  RETURN jsonb_build_object('ok', true, 'spent', cost, 'price', cost, 'rupee_price', COALESCE(material_row.price, 0), 'coin_price', cost, 'file_url', material_row.file_url, 'balance', public.get_23kaat_balance(uid));
END;
$$;

REVOKE EXECUTE ON FUNCTION public.spend_23kaat_for_course(uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.get_my_material_access_url(uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.spend_23kaat_for_material(uuid) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.spend_23kaat_for_course(uuid) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.get_my_material_access_url(uuid) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.spend_23kaat_for_material(uuid) TO authenticated, service_role;

-- ============================================================================
-- 20260929140000_test_question_timer_and_ai_drafts.sql
-- ============================================================================
-- Per-test question timer controls for admin-created tests.

ALTER TABLE public.tests
  ADD COLUMN IF NOT EXISTS question_timer_seconds integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS timer_mode text NOT NULL DEFAULT 'test';

ALTER TABLE public.tests
  DROP CONSTRAINT IF EXISTS tests_timer_mode_check;
ALTER TABLE public.tests
  ADD CONSTRAINT tests_timer_mode_check CHECK (timer_mode IN ('test', 'question', 'unlimited'));

ALTER TABLE public.tests
  DROP CONSTRAINT IF EXISTS tests_question_timer_seconds_check;
ALTER TABLE public.tests
  ADD CONSTRAINT tests_question_timer_seconds_check CHECK (question_timer_seconds >= 0 AND question_timer_seconds <= 7200);

COMMENT ON COLUMN public.tests.question_timer_seconds IS 'Per-question timer in seconds when timer_mode is question. 0 means no per-question limit.';
COMMENT ON COLUMN public.tests.timer_mode IS 'test = normal whole-test timer, question = per-question timer, unlimited = no timer; next question appears when student clicks Next.';

-- ============================================================================
-- ============================================================================
-- ============================================================================
-- ============================================================================
-- 20260929150000_security_app_controls_and_health.sql
-- ============================================================================
-- KKCC security/app controls and admin system health.
-- Safe additive migration: no student, course, wallet, storage or payment data is changed.
-- Run this file once in Supabase SQL Editor after the earlier KKCC migrations.

-- Public-safe app flags. Admin writes through existing site_settings RLS admin policies.
INSERT INTO public.site_settings (key, value) VALUES
  ('app_maintenance_mode', 'false'),
  ('app_maintenance_message', 'KKCC learning services are temporarily being refreshed. Please check back shortly.'),
  ('security_protection_enabled', 'true'),
  ('security_copy_guard_enabled', 'true'),
  ('security_context_menu_guard_enabled', 'true'),
  ('security_shortcut_guard_enabled', 'true'),
  ('security_watermark_enabled', 'true'),
  ('security_screenshot_blur_enabled', 'true'),
  ('security_print_guard_enabled', 'true'),
  ('feature_kittu_quiz_enabled', 'true'),
  ('feature_test_series_enabled', 'true'),
  ('feature_study_material_enabled', 'true'),
  ('kittu_daily_reward_cap', '160'),
  ('kittu_daily_practice_hours', '8'),
  ('kittu_daily_gift', '5'),
  ('kittu_practice_batches', '[]')
ON CONFLICT (key) DO NOTHING;

-- Refresh the earlier placeholder-style offline payment instruction only when it is
-- still the exact old default; admin-edited custom text is preserved.
UPDATE public.site_settings
SET value = 'Use the KKCC inquiry flow for UPI, cash or bank-transfer access. Course access is activated after the KKCC team confirms the payment.', updated_at = now()
WHERE key = 'offline_payment_instructions'
  AND value = 'Contact admin for UPI/cash/bank-transfer access. After payment, admin will unlock your course.';

-- Refresh old auto-default UI text in saved public JSON. Exact placeholder sentences only;
-- custom admin edits remain untouched.
UPDATE public.site_settings
SET value = replace(
    replace(
      value,
      'Start a free batch or ask admin to activate access after paid/offline payment.',
      'Start a free batch or contact KKCC support to activate paid/offline access.'
    ),
    'If your validity is about to expire, send a message from the Support page or contact admin.',
    'If your validity is about to expire, send a message from the Support page for renewal help.'
  ),
  updated_at = now()
WHERE key = 'ui_text_json'
  AND (
    value LIKE '%Start a free batch or ask admin to activate access after paid/offline payment.%'
    OR value LIKE '%If your validity is about to expire, send a message from the Support page or contact admin.%'
  );

-- Compact, read-only health metrics for admins. This exposes no emails, user IDs,
-- secrets, file URLs, payment keys, student personal data or quiz progress.
CREATE OR REPLACE FUNCTION public.get_kkcc_admin_system_health()
RETURNS TABLE (area text, label text, value text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_catalog
AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Forbidden — admin access required';
  END IF;

  RETURN QUERY
    SELECT
      'database'::text AS area,
      'database used'::text AS label,
      pg_size_pretty(pg_database_size(current_database()))::text AS value
    UNION ALL
    SELECT 'database', 'students', count(*)::text FROM public.profiles
    UNION ALL
    SELECT 'database', 'courses', count(*)::text FROM public.courses
    UNION ALL
    SELECT 'database', 'lectures', count(*)::text FROM public.lectures
    UNION ALL
    SELECT 'database', 'materials', count(*)::text FROM public.materials
    UNION ALL
    SELECT 'database', 'tests', count(*)::text FROM public.tests
    UNION ALL
    SELECT 'database', 'question rows', count(*)::text FROM public.test_questions
    UNION ALL
    SELECT 'database', 'enrollments', count(*)::text FROM public.course_enrollments
    UNION ALL
    SELECT 'database', 'file metadata rows', count(*)::text FROM public.files
    UNION ALL
    SELECT 'database', 'coin packages', count(*)::text FROM public.coin_packages
    UNION ALL
    SELECT 'database', 'coin transactions', count(*)::text FROM public.coin_transactions
    UNION ALL
    SELECT 'database', 'notifications', count(*)::text FROM public.notifications
    UNION ALL
    SELECT 'database', 'student doubts', count(*)::text FROM public.student_doubts
    UNION ALL
    SELECT 'database', 'admission enquiries', count(*)::text FROM public.admission_enquiries
    UNION ALL
    SELECT 'database', 'payment transactions', count(*)::text FROM public.payment_transactions
    UNION ALL
    SELECT 'database', 'settings rows', count(*)::text FROM public.site_settings
    UNION ALL
    SELECT 'largest tables', 'courses size', pg_size_pretty(pg_total_relation_size('public.courses'))
    UNION ALL
    SELECT 'largest tables', 'lectures size', pg_size_pretty(pg_total_relation_size('public.lectures'))
    UNION ALL
    SELECT 'largest tables', 'materials size', pg_size_pretty(pg_total_relation_size('public.materials'))
    UNION ALL
    SELECT 'largest tables', 'tests size', pg_size_pretty(pg_total_relation_size('public.tests'))
    UNION ALL
    SELECT 'largest tables', 'test questions size', pg_size_pretty(pg_total_relation_size('public.test_questions'))
    UNION ALL
    SELECT 'largest tables', 'files metadata size', pg_size_pretty(pg_total_relation_size('public.files'))
    UNION ALL
    SELECT 'storage', 'storage objects row', count(*)::text FROM storage.objects
    UNION ALL
    SELECT 'free-plan', 'database shared budget', '500 MB on Supabase Free'
    UNION ALL
    SELECT 'free-plan', 'storage shared budget', '1 GB file storage on Supabase Free'
    UNION ALL
    SELECT 'recommendation', 'large media', 'Keep videos on YouTube; move large files to external storage before storage quota is near.'
    UNION ALL
    SELECT 'recommendation', 'Kit 2 Coins Quiz data', 'Browser-local rewards and recent-question signatures do not use Supabase storage.';
END;
$$;

REVOKE ALL ON FUNCTION public.get_kkcc_admin_system_health() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_kkcc_admin_system_health() TO authenticated;

COMMENT ON FUNCTION public.get_kkcc_admin_system_health() IS
  'Admin-only read-only KKCC platform health summary. Returns counts and sizes only; never secrets, PII, URLs, or quiz progress.';

-- ============================================================================
-- 20260930103000_secure_course_media_and_upload_limit.sql
-- ============================================================================
-- KKCC paid-course media hardening and scanned-PDF upload limit alignment.
-- Safe update: no student, course, wallet, payment or storage object data is changed.

-- Let policies check the signed-in student's active, unexpired course entitlement
-- without exposing other students' enrollment data through function arguments.
CREATE OR REPLACE FUNCTION public.can_access_my_course(_course_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_catalog
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.courses c
    WHERE c.id = _course_id
      AND c.status = 'published'
      AND COALESCE(c.price, 0) <= 0
  )
  OR EXISTS (
    SELECT 1
    FROM public.course_enrollments e
    WHERE e.user_id = auth.uid()
      AND e.course_id = _course_id
      AND e.status = 'active'
      AND (e.expires_at IS NULL OR e.expires_at > now())
  );
$$;

REVOKE ALL ON FUNCTION public.can_access_my_course(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.can_access_my_course(uuid) TO anon, authenticated;

COMMENT ON FUNCTION public.can_access_my_course(uuid) IS
  'Returns whether the current signed-in user can read all lectures for a course: free courses, or an active unexpired enrolment. No PII or arbitrary user lookup is exposed.';

-- Close the direct anonymous/public API loophole for paid non-preview lecture video URLs.
-- Public users still receive free-course lectures and admin-marked free previews;
-- enrolled students receive their full course lecture deck; admins keep full access
-- through the existing admin lecture policies.
DROP POLICY IF EXISTS "Lectures of published courses are viewable by everyone" ON public.lectures;
CREATE POLICY "Lectures of published courses are viewable by everyone"
  ON public.lectures FOR SELECT
  USING (
    EXISTS (
      SELECT 1
      FROM public.courses c
      WHERE c.id = lectures.course_id
        AND c.status = 'published'
        AND (
          COALESCE(c.price, 0) <= 0
          OR lectures.is_free = true
          OR public.can_access_my_course(lectures.course_id)
        )
    )
  );

-- Keep uploaded scanned notes aligned with the app's 45 MB guidance and the Free
-- plan's practical single-file ceiling. Existing objects are untouched.
UPDATE storage.buckets
SET file_size_limit = 47185920
WHERE id = 'course-content';

-- Do not let an anonymous caller mint fresh signed URLs merely because an object
-- path leaks. Stored signed URLs already granted by admins continue to be used by
-- the app's material-access flow; administrators retain full storage management.
DROP POLICY IF EXISTS "Course content is readable" ON storage.objects;
CREATE POLICY "Admins read course content"
  ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'course-content' AND public.has_role(auth.uid(), 'admin'));

-- ============================================================================
-- 20260930110000_mask_private_material_urls.sql
-- ============================================================================
-- KKCC private material URL masking hardening.
-- Safe update: no student, course, wallet, payment, material or storage object data is changed.
--
-- What this closes:
--   Direct anonymous/PostgREST reads of published materials can no longer download rows
--   containing a paid/course-included private file_url merely because the material metadata
--   is visible in the public app. Public metadata is still available through a masked RPC;
--   entitled users receive the real URL through the existing authenticated access RPC.

-- Keep blocked students from continuing to use access that was granted before they were blocked.
CREATE OR REPLACE FUNCTION public.can_access_my_course(_course_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_catalog
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.courses c
    WHERE c.id = _course_id
      AND c.status = 'published'
      AND COALESCE(c.price, 0) <= 0
  )
  OR (
    auth.uid() IS NOT NULL
    AND EXISTS (
      SELECT 1
      FROM public.course_enrollments e
      WHERE e.user_id = auth.uid()
        AND e.course_id = _course_id
        AND e.status = 'active'
        AND (e.expires_at IS NULL OR e.expires_at > now())
    )
    AND NOT EXISTS (
      SELECT 1
      FROM public.student_blocks sb
      WHERE sb.user_id = auth.uid()
        AND sb.is_active = true
    )
  );
$$;

REVOKE ALL ON FUNCTION public.can_access_my_course(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.can_access_my_course(uuid) TO anon, authenticated;

COMMENT ON FUNCTION public.can_access_my_course(uuid) IS
  'Returns whether the current caller can read a full course deck: open published course, or active unexpired enrolment and no active student block.';

-- The helper only answers about the current caller. It cannot be used to inspect
-- another student's purchases and it returns false for blocked students.
CREATE OR REPLACE FUNCTION public.has_my_material_purchase(_material_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_catalog
AS $$
  SELECT auth.uid() IS NOT NULL
    AND EXISTS (
      SELECT 1
      FROM public.material_purchases mp
      WHERE mp.user_id = auth.uid()
        AND mp.material_id = _material_id
        AND mp.status = 'active'
    )
    AND NOT EXISTS (
      SELECT 1
      FROM public.student_blocks sb
      WHERE sb.user_id = auth.uid()
        AND sb.is_active = true
    );
$$;

REVOKE ALL ON FUNCTION public.has_my_material_purchase(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.has_my_material_purchase(uuid) TO anon, authenticated;

COMMENT ON FUNCTION public.has_my_material_purchase(uuid) IS
  'True only when the current unblocked authenticated caller has an active purchase for the given material.';

-- Hide private material rows from ordinary direct table reads. Public free items stay
-- visible, entitled students can read their own unlocked rows, and admins keep the
-- existing separate all-materials/admin policies.
DROP POLICY IF EXISTS "Published materials are viewable by everyone" ON public.materials;
CREATE POLICY "Published free and entitled materials are viewable"
  ON public.materials FOR SELECT
  USING (
    is_published
    AND (
      course_id IS NULL
      OR EXISTS (
        SELECT 1
        FROM public.courses c
        WHERE c.id = course_id
          AND c.status = 'published'
      )
    )
    AND (
      COALESCE(access_type, 'course') = 'free'
      OR (course_id IS NULL AND COALESCE(access_type, 'course') <> 'paid')
      OR public.can_access_my_course(course_id)
      OR (
        COALESCE(access_type, 'course') = 'paid'
        AND public.has_my_material_purchase(id)
      )
    )
  );

-- Public metadata listing: every published material/title/price remains discoverable,
-- but private file URLs are replaced with NULL unless the caller is entitled.
-- This keeps the paid-notes shop/buy buttons usable without exposing source URLs.
CREATE OR REPLACE FUNCTION public.list_public_materials(_course_id uuid DEFAULT NULL)
RETURNS TABLE (
  id uuid,
  course_id uuid,
  lecture_id uuid,
  title text,
  material_type text,
  subject text,
  chapter text,
  class_level text,
  pages integer,
  file_url text,
  is_published boolean,
  sort_order integer,
  description text,
  thumbnail_url text,
  module_title text,
  batch text,
  access_type text,
  price integer,
  coin_price integer,
  created_at timestamptz,
  updated_at timestamptz
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_catalog
AS $$
  SELECT
    m.id,
    m.course_id,
    m.lecture_id,
    m.title,
    m.material_type,
    m.subject,
    m.chapter,
    m.class_level,
    m.pages,
    CASE
      WHEN COALESCE(m.access_type, 'course') = 'free'
        OR (m.course_id IS NULL AND COALESCE(m.access_type, 'course') <> 'paid')
        OR public.can_access_my_course(m.course_id)
        OR (
          COALESCE(m.access_type, 'course') = 'paid'
          AND public.has_my_material_purchase(m.id)
        )
      THEN m.file_url
      ELSE NULL
    END AS file_url,
    m.is_published,
    m.sort_order,
    m.description,
    m.thumbnail_url,
    m.module_title,
    m.batch,
    m.access_type,
    m.price,
    m.coin_price,
    m.created_at,
    m.updated_at
  FROM public.materials m
  WHERE m.is_published = true
    AND (_course_id IS NULL OR m.course_id = _course_id)
    AND (
      m.course_id IS NULL
      OR EXISTS (
        SELECT 1
        FROM public.courses c
        WHERE c.id = m.course_id
          AND c.status = 'published'
      )
    )
  ORDER BY m.sort_order ASC, m.created_at DESC;
$$;

REVOKE ALL ON FUNCTION public.list_public_materials(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.list_public_materials(uuid) TO anon, authenticated;

COMMENT ON FUNCTION public.list_public_materials(uuid) IS
  'Returns published material metadata with private file URLs masked to NULL for unauthorized callers.';
-- KKCC AI Question Intelligence Engine
-- Stores only compact question candidates/settings; raw web research is never persisted.

CREATE TABLE IF NOT EXISTS public.ai_question_targets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  exam text NOT NULL,
  subject text NOT NULL,
  topic text NOT NULL,
  enabled boolean NOT NULL DEFAULT true,
  priority integer NOT NULL DEFAULT 50 CHECK (priority BETWEEN 0 AND 100),
  last_run_at timestamptz,
  next_run_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (exam, subject, topic)
);

CREATE TABLE IF NOT EXISTS public.ai_question_candidates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  prompt text NOT NULL,
  options jsonb NOT NULL,
  correct_index integer NOT NULL CHECK (correct_index BETWEEN 0 AND 3),
  explanation text NOT NULL,
  exam text NOT NULL,
  subject text NOT NULL,
  topic text NOT NULL,
  difficulty text NOT NULL DEFAULT 'Moderate' CHECK (difficulty IN ('Easy','Moderate','Difficult')),
  quality_score integer NOT NULL DEFAULT 0 CHECK (quality_score BETWEEN 0 AND 100),
  source_urls jsonb NOT NULL DEFAULT '[]'::jsonb,
  source_notes text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'review' CHECK (status IN ('review','approved','rejected')),
  duplicate_key text NOT NULL,
  reviewed_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (duplicate_key)
);

CREATE INDEX IF NOT EXISTS idx_ai_candidates_review ON public.ai_question_candidates(status, quality_score DESC, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ai_candidates_topic ON public.ai_question_candidates(exam, subject, topic);
CREATE INDEX IF NOT EXISTS idx_ai_targets_schedule ON public.ai_question_targets(enabled, next_run_at, priority DESC);

ALTER TABLE public.ai_question_targets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_question_candidates ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Admins manage AI targets" ON public.ai_question_targets;
CREATE POLICY "Admins manage AI targets" ON public.ai_question_targets FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
DROP POLICY IF EXISTS "Admins manage AI candidates" ON public.ai_question_candidates;
CREATE POLICY "Admins manage AI candidates" ON public.ai_question_candidates FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_ai_targets_updated_at ON public.ai_question_targets;
CREATE TRIGGER update_ai_targets_updated_at BEFORE UPDATE ON public.ai_question_targets
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
DROP TRIGGER IF EXISTS update_ai_candidates_updated_at ON public.ai_question_candidates;
CREATE TRIGGER update_ai_candidates_updated_at BEFORE UPDATE ON public.ai_question_candidates
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- AI configuration lives in the existing private_settings table.
INSERT INTO public.private_settings(key, value)
VALUES
  ('ai_question_engine_enabled','false'),
  ('ai_question_engine_model','gemini-2.5-flash'),
  ('ai_question_engine_daily_limit','30'),
  ('ai_question_engine_min_quality','85'),
  ('ai_question_engine_auto_publish','false'),
  ('ai_question_engine_google_search','true'),
  ('ai_question_engine_gemini_api_key','')
ON CONFLICT (key) DO NOTHING;

-- Keep the free database lean: old rejected candidates are disposable.
CREATE OR REPLACE FUNCTION public.ai_question_engine_cleanup()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  DELETE FROM public.ai_question_candidates
  WHERE status = 'rejected' AND created_at < now() - interval '14 days';
  DELETE FROM public.ai_question_candidates
  WHERE status = 'approved' AND created_at < now() - interval '90 days';
END;
$$;
GRANT EXECUTE ON FUNCTION public.ai_question_engine_cleanup() TO service_role;
