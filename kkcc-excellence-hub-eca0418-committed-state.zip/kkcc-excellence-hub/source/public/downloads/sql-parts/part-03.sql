-- KKCC Excellence Hub SQL Part 03 of 9. Run in order.



CREATE TABLE IF NOT EXISTS public.payment_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  course_id uuid REFERENCES public.courses(id) ON DELETE SET NULL,
  provider text NOT NULL DEFAULT 'manual',
  status text NOT NULL DEFAULT 'pending',
  amount integer NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'INR',
  provider_order_id text NOT NULL DEFAULT '',
  provider_payment_id text NOT NULL DEFAULT '',
  admin_note text NOT NULL DEFAULT '',
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.payment_transactions TO authenticated;
GRANT ALL ON public.payment_transactions TO service_role;
ALTER TABLE public.payment_transactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own payment transactions" ON public.payment_transactions;
CREATE POLICY "Users can view own payment transactions"
  ON public.payment_transactions FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admins can manage payment transactions" ON public.payment_transactions;
CREATE POLICY "Admins can manage payment transactions"
  ON public.payment_transactions FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_payment_transactions_updated_at ON public.payment_transactions;
CREATE TRIGGER update_payment_transactions_updated_at
  BEFORE UPDATE ON public.payment_transactions
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- 7) Offline payment access grants -----------------------------------------
CREATE TABLE IF NOT EXISTS public.offline_access_grants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  full_name text NOT NULL DEFAULT '',
  course_id uuid NOT NULL REFERENCES public.courses(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'pending',
  amount_paid integer NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'INR',
  payment_method text NOT NULL DEFAULT 'offline',
  admin_note text NOT NULL DEFAULT '',
  expires_at timestamptz,
  activated_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (email, course_id)
);

ALTER TABLE public.offline_access_grants
  ADD COLUMN IF NOT EXISTS email text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS full_name text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS course_id uuid REFERENCES public.courses(id) ON DELETE CASCADE,
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS amount_paid integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS currency text NOT NULL DEFAULT 'INR',
  ADD COLUMN IF NOT EXISTS payment_method text NOT NULL DEFAULT 'offline',
  ADD COLUMN IF NOT EXISTS admin_note text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS expires_at timestamptz,
  ADD COLUMN IF NOT EXISTS activated_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

CREATE UNIQUE INDEX IF NOT EXISTS idx_offline_access_email_course
  ON public.offline_access_grants (email, course_id);
CREATE INDEX IF NOT EXISTS idx_offline_access_status ON public.offline_access_grants(status);
CREATE INDEX IF NOT EXISTS idx_offline_access_activated_user ON public.offline_access_grants(activated_user_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.offline_access_grants TO authenticated;
GRANT ALL ON public.offline_access_grants TO service_role;
ALTER TABLE public.offline_access_grants ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Admins can manage offline access grants" ON public.offline_access_grants;
CREATE POLICY "Admins can manage offline access grants"
  ON public.offline_access_grants FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_offline_access_grants_updated_at ON public.offline_access_grants;
CREATE TRIGGER update_offline_access_grants_updated_at
  BEFORE UPDATE ON public.offline_access_grants
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.activate_offline_access_for_user(_user_id uuid, _email text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.course_enrollments (
    user_id,
    course_id,
    status,
    source,
    payment_method,
    amount_paid,
    currency,
    admin_note,
    expires_at,
    created_by
  )
  SELECT
    _user_id,
    g.course_id,
    'active',
    'offline',
    g.payment_method,
    g.amount_paid,
    g.currency,
    g.admin_note,
    g.expires_at,
    g.created_by
  FROM public.offline_access_grants g
  WHERE lower(g.email) = lower(COALESCE(_email, ''))
    AND g.status IN ('pending', 'activated')
  ON CONFLICT (user_id, course_id) DO UPDATE SET
    status = 'active',
    source = 'offline',
    payment_method = EXCLUDED.payment_method,
    amount_paid = EXCLUDED.amount_paid,
    currency = EXCLUDED.currency,
    admin_note = EXCLUDED.admin_note,
    expires_at = EXCLUDED.expires_at,
    created_by = COALESCE(EXCLUDED.created_by, public.course_enrollments.created_by),
    updated_at = now();

  UPDATE public.profiles p
  SET full_name = COALESCE(
      NULLIF((
        SELECT g.full_name
        FROM public.offline_access_grants g
        WHERE lower(g.email) = lower(COALESCE(_email, ''))
          AND g.full_name <> ''
        ORDER BY g.updated_at DESC
        LIMIT 1
      ), ''),
      p.full_name
    ),
    updated_at = now()
  WHERE p.id = _user_id;

  UPDATE public.offline_access_grants
  SET status = 'activated',
      activated_user_id = _user_id,
      updated_at = now()
  WHERE lower(email) = lower(COALESCE(_email, ''))
    AND status IN ('pending', 'activated');
END;
$$;

REVOKE EXECUTE ON FUNCTION public.activate_offline_access_for_user(uuid, text) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.activate_offline_access_for_user(uuid, text) TO authenticated, service_role;

CREATE OR REPLACE FUNCTION public.handle_new_user_profile()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, mobile, class_level, target_exam)
  VALUES (
    NEW.id,
    COALESCE(NEW.email, ''),
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', NEW.raw_user_meta_data ->> 'name', ''),
    COALESCE(NEW.raw_user_meta_data ->> 'mobile', ''),
    COALESCE(NEW.raw_user_meta_data ->> 'class_level', ''),
    COALESCE(NEW.raw_user_meta_data ->> 'target_exam', '')
  )
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    full_name = COALESCE(NULLIF(EXCLUDED.full_name, ''), public.profiles.full_name),
    mobile = COALESCE(NULLIF(EXCLUDED.mobile, ''), public.profiles.mobile),
    class_level = COALESCE(NULLIF(EXCLUDED.class_level, ''), public.profiles.class_level),
    target_exam = COALESCE(NULLIF(EXCLUDED.target_exam, ''), public.profiles.target_exam),
    updated_at = now();

  IF lower(COALESCE(NEW.email, '')) = 'kkcc23102003@gmail.com' THEN
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;

  PERFORM public.activate_offline_access_for_user(NEW.id, NEW.email);

  RETURN NEW;
END;
$$;

-- Activate pending offline grants for already-existing users.
SELECT public.activate_offline_access_for_user(id, email)
FROM auth.users
WHERE email IS NOT NULL;


-- 8) Coupon codes / limited redemptions -------------------------------------
CREATE TABLE IF NOT EXISTS public.coupon_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL,
  title text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  discount_percent integer NOT NULL DEFAULT 0,
  max_uses integer NOT NULL DEFAULT 0,
  used_count integer NOT NULL DEFAULT 0,
  per_user_limit integer NOT NULL DEFAULT 1,
  starts_at timestamptz,
  expires_at timestamptz,
  is_active boolean NOT NULL DEFAULT true,
  applies_to_course_id uuid REFERENCES public.courses(id) ON DELETE SET NULL,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.coupon_codes
  ADD COLUMN IF NOT EXISTS code text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS title text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS description text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS discount_percent integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS max_uses integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS used_count integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS per_user_limit integer NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS starts_at timestamptz,
  ADD COLUMN IF NOT EXISTS expires_at timestamptz,
  ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS applies_to_course_id uuid REFERENCES public.courses(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

CREATE UNIQUE INDEX IF NOT EXISTS idx_coupon_codes_upper_code ON public.coupon_codes (upper(code));
CREATE INDEX IF NOT EXISTS idx_coupon_codes_active ON public.coupon_codes(is_active, expires_at);
CREATE INDEX IF NOT EXISTS idx_coupon_codes_course ON public.coupon_codes(applies_to_course_id);

CREATE TABLE IF NOT EXISTS public.coupon_redemptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  coupon_id uuid NOT NULL REFERENCES public.coupon_codes(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  course_id uuid NOT NULL REFERENCES public.courses(id) ON DELETE CASCADE,
  discount_percent integer NOT NULL DEFAULT 0,
  discount_amount integer NOT NULL DEFAULT 0,
  original_amount integer NOT NULL DEFAULT 0,
  final_amount integer NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'INR',
  status text NOT NULL DEFAULT 'redeemed',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (coupon_id, user_id, course_id)
);

ALTER TABLE public.coupon_redemptions
  ADD COLUMN IF NOT EXISTS coupon_id uuid REFERENCES public.coupon_codes(id) ON DELETE CASCADE,
  ADD COLUMN IF NOT EXISTS user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  ADD COLUMN IF NOT EXISTS course_id uuid REFERENCES public.courses(id) ON DELETE CASCADE,
  ADD COLUMN IF NOT EXISTS discount_percent integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS discount_amount integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS original_amount integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS final_amount integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS currency text NOT NULL DEFAULT 'INR',
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'redeemed',
  ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();

CREATE UNIQUE INDEX IF NOT EXISTS idx_coupon_redemptions_unique
  ON public.coupon_redemptions(coupon_id, user_id, course_id);
CREATE INDEX IF NOT EXISTS idx_coupon_redemptions_user ON public.coupon_redemptions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_coupon_redemptions_coupon ON public.coupon_redemptions(coupon_id, created_at DESC);

GRANT SELECT ON public.coupon_codes TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.coupon_codes TO authenticated;
GRANT ALL ON public.coupon_codes TO service_role;
ALTER TABLE public.coupon_codes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public can read active coupon codes" ON public.coupon_codes;
CREATE POLICY "Public can read active coupon codes"
  ON public.coupon_codes FOR SELECT
  USING (is_active = true);

DROP POLICY IF EXISTS "Admins can manage coupon codes" ON public.coupon_codes;
CREATE POLICY "Admins can manage coupon codes"
  ON public.coupon_codes FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_coupon_codes_updated_at ON public.coupon_codes;
CREATE TRIGGER update_coupon_codes_updated_at
  BEFORE UPDATE ON public.coupon_codes
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

GRANT SELECT ON public.coupon_redemptions TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.coupon_redemptions TO authenticated;
GRANT ALL ON public.coupon_redemptions TO service_role;
ALTER TABLE public.coupon_redemptions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own coupon redemptions" ON public.coupon_redemptions;
CREATE POLICY "Users can view own coupon redemptions"
  ON public.coupon_redemptions FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admins can manage coupon redemptions" ON public.coupon_redemptions;
CREATE POLICY "Admins can manage coupon redemptions"
  ON public.coupon_redemptions FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));