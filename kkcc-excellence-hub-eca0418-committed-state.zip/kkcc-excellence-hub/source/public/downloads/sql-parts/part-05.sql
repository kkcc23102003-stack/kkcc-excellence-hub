-- KKCC Excellence Hub SQL Part 05 of 9. Run in order.


CREATE POLICY "Authenticated users can read targeted published notifications"
  ON public.notifications FOR SELECT TO authenticated
  USING (
    is_published = true
    AND (send_at IS NULL OR send_at <= now())
    AND (expires_at IS NULL OR expires_at > now())
    AND (
      audience IN ('all', 'students')
      OR (audience = 'admins' AND public.has_role(auth.uid(), 'admin'))
      OR (audience = 'user' AND target_user_id = auth.uid())
      OR (
        audience = 'course'
        AND EXISTS (
          SELECT 1 FROM public.course_enrollments ce
          WHERE ce.user_id = auth.uid()
            AND ce.course_id = notifications.course_id
            AND ce.status = 'active'
        )
      )
    )
  );

CREATE TABLE IF NOT EXISTS public.student_doubts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  course_id uuid REFERENCES public.courses(id) ON DELETE SET NULL,
  subject text NOT NULL DEFAULT 'General',
  title text NOT NULL,
  message text NOT NULL,
  attachment_url text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'open',
  priority text NOT NULL DEFAULT 'normal',
  admin_reply text NOT NULL DEFAULT '',
  answered_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  answered_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT student_doubts_status_check CHECK (status IN ('open', 'answered', 'closed')),
  CONSTRAINT student_doubts_priority_check CHECK (priority IN ('low', 'normal', 'high'))
);

ALTER TABLE public.student_doubts
  ADD COLUMN IF NOT EXISTS course_id uuid REFERENCES public.courses(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS subject text NOT NULL DEFAULT 'General',
  ADD COLUMN IF NOT EXISTS attachment_url text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'open',
  ADD COLUMN IF NOT EXISTS priority text NOT NULL DEFAULT 'normal',
  ADD COLUMN IF NOT EXISTS admin_reply text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS answered_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS answered_at timestamptz,
  ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

CREATE INDEX IF NOT EXISTS idx_student_doubts_user ON public.student_doubts(user_id, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_student_doubts_course ON public.student_doubts(course_id, status);
CREATE INDEX IF NOT EXISTS idx_student_doubts_status ON public.student_doubts(status, priority, updated_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.student_doubts TO authenticated;
GRANT ALL ON public.student_doubts TO service_role;
ALTER TABLE public.student_doubts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Students can create their own doubts" ON public.student_doubts;
CREATE POLICY "Students can create their own doubts"
  ON public.student_doubts FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Students can view their own doubts" ON public.student_doubts;
CREATE POLICY "Students can view their own doubts"
  ON public.student_doubts FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admins can manage all doubts" ON public.student_doubts;
CREATE POLICY "Admins can manage all doubts"
  ON public.student_doubts FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_student_doubts_updated_at ON public.student_doubts;
CREATE TRIGGER update_student_doubts_updated_at
  BEFORE UPDATE ON public.student_doubts
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();



-- 11) Admission enquiry CRM ----------------------------------------------
-- Admission / enquiry CRM for future admissions and follow-ups.

CREATE TABLE IF NOT EXISTS public.admission_enquiries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL DEFAULT '',
  class_level text NOT NULL DEFAULT '',
  interest text NOT NULL DEFAULT '',
  message text NOT NULL DEFAULT '',
  source text NOT NULL DEFAULT 'support',
  status text NOT NULL DEFAULT 'new',
  priority text NOT NULL DEFAULT 'normal',
  admin_note text NOT NULL DEFAULT '',
  last_contacted_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT admission_enquiries_status_check CHECK (status IN ('new', 'contacted', 'admitted', 'closed', 'spam')),
  CONSTRAINT admission_enquiries_priority_check CHECK (priority IN ('low', 'normal', 'high'))
);

ALTER TABLE public.admission_enquiries
  ADD COLUMN IF NOT EXISTS phone text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS class_level text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS interest text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS source text NOT NULL DEFAULT 'support',
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'new',
  ADD COLUMN IF NOT EXISTS priority text NOT NULL DEFAULT 'normal',
  ADD COLUMN IF NOT EXISTS admin_note text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS last_contacted_at timestamptz,
  ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

CREATE INDEX IF NOT EXISTS idx_admission_enquiries_status ON public.admission_enquiries(status, priority, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_admission_enquiries_email ON public.admission_enquiries(lower(email));
CREATE INDEX IF NOT EXISTS idx_admission_enquiries_phone ON public.admission_enquiries(phone);

GRANT INSERT ON public.admission_enquiries TO anon;
GRANT INSERT, SELECT, UPDATE, DELETE ON public.admission_enquiries TO authenticated;
GRANT ALL ON public.admission_enquiries TO service_role;
ALTER TABLE public.admission_enquiries ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anyone can submit admission enquiries" ON public.admission_enquiries;
CREATE POLICY "Anyone can submit admission enquiries"
  ON public.admission_enquiries FOR INSERT
  WITH CHECK (
    status = 'new'
    AND admin_note = ''
    AND last_contacted_at IS NULL
  );

DROP POLICY IF EXISTS "Admins can manage admission enquiries" ON public.admission_enquiries;
CREATE POLICY "Admins can manage admission enquiries"
  ON public.admission_enquiries FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_admission_enquiries_updated_at ON public.admission_enquiries;
CREATE TRIGGER update_admission_enquiries_updated_at
  BEFORE UPDATE ON public.admission_enquiries
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.notify_admins_on_admission_enquiry()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.notifications (
    title,
    message,
    type,
    audience,
    course_id,
    priority,
    action_label,
    action_url,
    is_published,
    send_at,
    expires_at,
    created_by
  ) VALUES (
    'New admission enquiry: ' || NEW.name,
    concat_ws(E'\n',
      'Name: ' || NEW.name,
      'Email: ' || NEW.email,
      CASE WHEN NEW.phone <> '' THEN 'Phone: ' || NEW.phone ELSE NULL END,
      CASE WHEN NEW.class_level <> '' THEN 'Class/target: ' || NEW.class_level ELSE NULL END,
      CASE WHEN NEW.interest <> '' THEN 'Interest: ' || NEW.interest ELSE NULL END,
      NEW.message
    ),
    'enquiry',
    'admins',
    NULL,
    NEW.priority,
    'Open enquiry',
    '/admin/enquiries',
    true,
    NULL,
    NULL,
    NULL
  );
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS admission_enquiries_notify_admins ON public.admission_enquiries;
CREATE TRIGGER admission_enquiries_notify_admins
  AFTER INSERT ON public.admission_enquiries
  FOR EACH ROW EXECUTE FUNCTION public.notify_admins_on_admission_enquiry();


-- Refresh counters for existing rows.
UPDATE public.tests t SET
  questions_count = (SELECT count(*) FROM public.test_questions q WHERE q.test_id = t.id),
  total_marks = COALESCE((SELECT sum(q.marks) FROM public.test_questions q WHERE q.test_id = t.id), 0);

UPDATE public.courses c SET
  lectures_count = (SELECT count(*) FROM public.lectures l WHERE l.course_id = c.id),
  materials_count = (SELECT count(*) FROM public.materials m WHERE m.course_id = c.id),
  tests_count = (SELECT count(*) FROM public.tests t WHERE t.course_id = c.id);

-- Final check message appears in SQL Results if everything above succeeded.
SELECT 'KKCC Supabase setup complete. Now sign up/login with kkcc23102003@gmail.com and open /admin.' AS status;

-- ============================================================================
-- 20260925000000_public_platform_stats.sql
-- Public aggregate counters for the website homepage.
-- This exposes only safe totals (no student names, emails, phones, or private data).
CREATE OR REPLACE FUNCTION public.get_public_platform_stats()
RETURNS TABLE (
  students_joined bigint,
  active_students bigint,
  published_courses bigint,
  published_lectures bigint,
  published_materials bigint,
  published_tests bigint
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    (
      SELECT count(*)
      FROM public.profiles p
      WHERE NOT EXISTS (
        SELECT 1
        FROM public.user_roles ur
        WHERE ur.user_id = p.id
          AND ur.role = 'admin'
      )
    ) AS students_joined,
    (
      SELECT count(DISTINCT ce.user_id)
      FROM public.course_enrollments ce
      WHERE ce.status = 'active'
        AND (ce.expires_at IS NULL OR ce.expires_at > now())
        AND NOT EXISTS (
          SELECT 1
          FROM public.user_roles ur
          WHERE ur.user_id = ce.user_id
            AND ur.role = 'admin'
        )
    ) AS active_students,
    (
      SELECT count(*)
      FROM public.courses c
      WHERE c.status = 'published'
    ) AS published_courses,
    (
      SELECT count(*)
      FROM public.lectures l
      INNER JOIN public.courses c ON c.id = l.course_id
      WHERE c.status = 'published'
    ) AS published_lectures,
    (
      SELECT count(*)
      FROM public.materials m
      WHERE m.is_published = true
    ) AS published_materials,
    (
      SELECT count(*)
      FROM public.tests t
      WHERE t.is_published = true
    ) AS published_tests;
$$;

REVOKE ALL ON FUNCTION public.get_public_platform_stats() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_public_platform_stats() TO anon, authenticated;

-- ============================================================================
-- 20260926000000_uv_logo_branding_refresh.sql
-- Refresh default logo/theme values to the new UV neon KKCC look.
-- This is safe for existing projects: it only replaces old bundled defaults or blank values.
UPDATE public.site_settings
SET value = CASE key
  WHEN 'brand_logo_url' THEN '/logo.png'
  WHEN 'brand_primary_color' THEN '#18f4d6'
  WHEN 'brand_accent_color' THEN '#f5d78e'
  WHEN 'brand_background_color' THEN '#050605'
  WHEN 'brand_foreground_color' THEN '#fff8e7'
  WHEN 'brand_hero_title' THEN 'KKCC Excellence Hub — Study That Makes You Return.'
  WHEN 'brand_hero_highlight' THEN 'Learn with clarity. Practice with courage. Rise with confidence.'
  WHEN 'brand_hero_description' THEN 'KKCC turns lectures, notes, tests, and progress into a bright daily learning loop — so students know exactly what to open next and feel excited to continue.'
  ELSE value
END,
updated_at = now()
WHERE (key = 'brand_logo_url' AND value IN ('', '/favicon.png'))
   OR (key = 'brand_primary_color' AND value IN ('', '#0f766e', '#ff174f'))
   OR (key = 'brand_accent_color' AND value IN ('', '#d9b66f', '#00e5ff'))
   OR (key = 'brand_background_color' AND value = '')
   OR (key = 'brand_foreground_color' AND value = '')
   OR (key = 'brand_hero_title' AND value IN ('Education That Builds Understanding.', 'KKCC Excellence Hub — Learn with Power.', 'KKCC Excellence Hub — Study That Makes You Return.'))
   OR (key = 'brand_hero_highlight' AND value IN ('Logo-Inspired UV Learning for Bright Futures.', 'Neon Smart Learning for Bright Futures.', 'Learning That Builds Futures.', 'KKCC Excellence Learning for Bright Futures.', 'Learn with clarity. Practice with courage. Rise with confidence.'))
   OR (key = 'brand_hero_description' AND value IN ('A bold digital classroom for real KKCC students — courses, lectures, notes, tests and progress in one colourful learning hub.', 'Learn from structured courses, expert guidance, smart practice and powerful study tools — all in one place.', 'KKCC brings courses, lectures, notes, tests, and progress tracking together in one colourful learning hub.', 'KKCC brings courses, lectures, notes, tests, and progress tracking together in one colorful learning hub.', 'KKCC turns lectures, notes, tests, and progress into a bright daily learning loop — so students know exactly what to open next and feel excited to continue.'));

INSERT INTO public.site_settings (key, value)
VALUES
  ('brand_logo_url', '/logo.png'),
  ('brand_primary_color', '#18f4d6'),
  ('brand_accent_color', '#f5d78e'),
  ('brand_background_color', '#050605'),
  ('brand_foreground_color', '#fff8e7'),
  ('brand_hero_title', 'KKCC Excellence Hub — Study That Makes You Return.'),
  ('brand_hero_highlight', 'Learn with clarity. Practice with courage. Rise with confidence.'),
  ('brand_hero_description', 'KKCC turns lectures, notes, tests, and progress into a bright daily learning loop — so students know exactly what to open next and feel excited to continue.')
ON CONFLICT (key) DO NOTHING;

-- ============================================================================
-- 20260926001000_logo_uv_palette_correction.sql
-- Correct the UV palette to match the supplied KKCC K-logo.
-- This safely replaces the earlier temporary red/cyan defaults if they were already applied.
UPDATE public.site_settings
SET value = CASE key
  WHEN 'brand_primary_color' THEN '#18f4d6'
  WHEN 'brand_accent_color' THEN '#f5d78e'
  WHEN 'brand_background_color' THEN '#050605'
  WHEN 'brand_foreground_color' THEN '#fff8e7'
  WHEN 'brand_hero_highlight' THEN 'Learn with clarity. Practice with courage. Rise with confidence.'
  ELSE value
END,
updated_at = now()
WHERE (key = 'brand_primary_color' AND value IN ('#ff174f', '#0f766e', ''))
   OR (key = 'brand_accent_color' AND value IN ('#00e5ff', '#d9b66f', ''))
   OR (key = 'brand_background_color' AND value IN ('#07040d', ''))
   OR (key = 'brand_foreground_color' AND value IN ('#fff7ff', ''))
   OR (key = 'brand_hero_highlight' AND value IN ('Logo-Inspired UV Learning for Bright Futures.', 'Neon Smart Learning for Bright Futures.', 'Learning That Builds Futures.', 'KKCC Excellence Learning for Bright Futures.', 'Learn with clarity. Practice with courage. Rise with confidence.'));

-- 20260926002000_student_comeback_copy_refresh.sql
-- Refresh default KKCC hero copy to the sharper student-comeback wording.
-- Safe for existing projects: only old bundled defaults are replaced, not custom admin text.
UPDATE public.site_settings
SET value = CASE key
  WHEN 'brand_hero_title' THEN 'KKCC Excellence Hub — Study That Makes You Return.'
  WHEN 'brand_hero_highlight' THEN 'Learn with clarity. Practice with courage. Rise with confidence.'
  WHEN 'brand_hero_description' THEN 'KKCC turns lectures, notes, tests, and progress into a bright daily learning loop — so students know exactly what to open next and feel excited to continue.'
  WHEN 'brand_cta_primary_label' THEN 'Find My Next Win'
  WHEN 'brand_cta_secondary_label' THEN 'Continue Learning'
  ELSE value
END,
updated_at = now()
WHERE (key = 'brand_hero_title' AND value IN ('Education That Builds Understanding.', 'KKCC Excellence Hub — Learn with Power.'))
   OR (key = 'brand_hero_highlight' AND value IN ('Logo-Inspired UV Learning for Bright Futures.', 'Neon Smart Learning for Bright Futures.', 'Learning That Builds Futures.', 'KKCC Excellence Learning for Bright Futures.'))
   OR (key = 'brand_hero_description' AND value IN ('A bold digital classroom for real KKCC students — courses, lectures, notes, tests and progress in one colourful learning hub.', 'Learn from structured courses, expert guidance, smart practice and powerful study tools — all in one place.', 'KKCC brings courses, lectures, notes, tests, and progress tracking together in one colourful learning hub.', 'KKCC brings courses, lectures, notes, tests, and progress tracking together in one colorful learning hub.'))
   OR (key = 'brand_cta_primary_label' AND value = 'Explore Courses')
   OR (key = 'brand_cta_secondary_label' AND value = 'Start Learning');

INSERT INTO public.site_settings (key, value)
VALUES
  ('brand_hero_title', 'KKCC Excellence Hub — Study That Makes You Return.'),
  ('brand_hero_highlight', 'Learn with clarity. Practice with courage. Rise with confidence.'),
  ('brand_hero_description', 'KKCC turns lectures, notes, tests, and progress into a bright daily learning loop — so students know exactly what to open next and feel excited to continue.'),
  ('brand_cta_primary_label', 'Find My Next Win'),
  ('brand_cta_secondary_label', 'Continue Learning')
ON CONFLICT (key) DO NOTHING;

-- 20260926003000_kaat_philosophy_hero_highlight.sql
-- Refresh default hero highlight to the KKCC 2-3-KAAT philosophy line.
-- Safe for existing projects: only old bundled/default hero highlights are replaced.
UPDATE public.site_settings
SET value = 'Learn with clarity. Practice with courage. Rise with confidence.',
updated_at = now()
WHERE key = 'brand_hero_highlight'
  AND value IN (
    'Logo-Inspired UV Learning for Bright Futures.',
    'Neon Smart Learning for Bright Futures.',
    'Learning That Builds Futures.',
    'KKCC Excellence Learning for Bright Futures.',
    'One focused session. One clear win. Every day.'
  );

INSERT INTO public.site_settings (key, value)
VALUES
  ('brand_hero_highlight', 'Learn with clarity. Practice with courage. Rise with confidence.')
ON CONFLICT (key) DO NOTHING;


-- 20260926004000_23kaat_hero_highlight.sql
-- Refresh default hero highlight to the 23KAAT philosophy line.
-- Safe for existing projects: only old bundled/default hero highlights are replaced.
UPDATE public.site_settings
SET value = 'Learn with clarity. Practice with courage. Rise with confidence.',
updated_at = now()
WHERE key = 'brand_hero_highlight'
  AND value IN (
    'Logo-Inspired UV Learning for Bright Futures.',
    'Neon Smart Learning for Bright Futures.',
    'Learning That Builds Futures.',
    'KKCC Excellence Learning for Bright Futures.',
    'One focused session. One clear win. Every day.',
    '2 — Double Vision · 3 — Three Tiers: Courage, Patience, Victory · K — Knowledge · A — Action · A — Ambition · T — Trust',
    '23KAAT :– 2 — Double Vision (aim and reality) · 3 — Three Tiers: Courage, Patience, Victory · K — Knowledge · A — Action · A — Ambition · T — Trust'
  );