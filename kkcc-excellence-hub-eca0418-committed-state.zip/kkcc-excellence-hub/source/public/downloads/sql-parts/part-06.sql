-- KKCC Excellence Hub SQL Part 06 of 9. Run in order.



INSERT INTO public.site_settings (key, value)
VALUES
  ('brand_hero_highlight', 'Learn with clarity. Practice with courage. Rise with confidence.')
ON CONFLICT (key) DO NOTHING;

-- 20260926005000_23kaat_rule_of_success_hero_highlight.sql
-- Refresh default hero highlight to the exact 23KAAT rule-of-success text.
-- Safe for existing projects: only old bundled/default hero highlights are replaced.
UPDATE public.site_settings
SET value = 'Learn with clarity. Practice with courage. Rise with confidence.',
updated_at = now()
WHERE key = 'brand_hero_highlight'
  AND value IN (
    'Logo-Inspired UV Learning for Bright Futures.',
    'Neon Smart Learning for Bright Futures.',
    'Learning That Builds Futures.',
    'KKCC Excellence Learning for Bright Futures.',
    'One focused session. One clear win. Every day.',
    '2 — Double Vision · 3 — Three Tiers: Courage, Patience, Victory · K — Knowledge · A — Action · A — Ambition · T — Trust',
    '23KAAT :– 2 — Double Vision (aim and reality) · 3 — Three Tiers: Courage, Patience, Victory · K — Knowledge · A — Action · A — Ambition · T — Trust',
    '23KAAT :– 2 — Double Vision ( aim and reality )· 3 — Three Tiers: Courage, Patience, Victory · K — Knowledge · A — Action · A — Ambition · T — Trust'
  );

INSERT INTO public.site_settings (key, value)
VALUES
  ('brand_hero_highlight', 'Learn with clarity. Practice with courage. Rise with confidence.')
ON CONFLICT (key) DO NOTHING;

-- 20260926006000_confidence_hero_highlight.sql
-- Refresh default hero highlight to a cleaner confidence-focused line.
-- Safe for existing projects: only old bundled/default/23KAAT hero highlights are replaced.
UPDATE public.site_settings
SET value = 'Learn with clarity. Practice with courage. Rise with confidence.',
updated_at = now()
WHERE key = 'brand_hero_highlight'
  AND (
    value IN (
    'Logo-Inspired UV Learning for Bright Futures.',
    'Neon Smart Learning for Bright Futures.',
    'Learning That Builds Futures.',
    'KKCC Excellence Learning for Bright Futures.',
    'One focused session. One clear win. Every day.',
    '2 — Double Vision · 3 — Three Tiers: Courage, Patience, Victory · K — Knowledge · A — Action · A — Ambition · T — Trust',
    '23KAAT :– 2 — Double Vision (aim and reality) · 3 — Three Tiers: Courage, Patience, Victory · K — Knowledge · A — Action · A — Ambition · T — Trust',
    '23KAAT :– 2 — Double Vision ( aim and reality )· 3 — Three Tiers: Courage, Patience, Victory · K — Knowledge · A — Action · A — Ambition · T — Trust'
    )
    OR value = $kkcc_old_23kaat$23KAAT is the rule of success

2 — Double Vision ( aim and reality )·

3 — Three Tiers (Courage, Patience, Victory) ·

K — Knowledge ·

A — Action ·

A — Ambition ·

T — Trust$kkcc_old_23kaat$
  );

INSERT INTO public.site_settings (key, value)
VALUES
  ('brand_hero_highlight', 'Learn with clarity. Practice with courage. Rise with confidence.')
ON CONFLICT (key) DO NOTHING;

-- 20260926007000_hybrid_ui_text_manager.sql
-- Seed safe hybrid UI text defaults for the admin Text Manager.
-- Safe for existing projects: this only inserts the key when it is missing.
INSERT INTO public.site_settings (key, value)
VALUES
  ('ui_text_json', $kkcc_ui_text${"auth":{"side_heading":"Education That Builds Understanding. Learning That Builds Futures.","side_description":"Learn Better. Understand Deeper. Achieve More.","login_title":"Welcome back","login_description":"Sign in to continue your lectures, tests and revision.","login_submit_label":"Sign in","login_footer_prompt":"New to KKCC?","login_footer_link":"Create an account","forgot_password_label":"Forgot password?","secure_login_title":"Secure student login","secure_login_description":"Your session is safely stored in this browser; dashboard and admin routes stay protected.","signup_title":"Create your KKCC account","signup_description":"Join KKCC to access courses, tests, notes and your learning progress.","signup_submit_label":"Create account","signup_footer_prompt":"Already have an account?","signup_footer_link":"Sign in","signup_success_title":"Check your email","signup_success_description":"Your KKCC account was created. If email confirmation is enabled, open the verification link before signing in.","forgot_title":"Reset your password","forgot_description":"Enter your registered email and we will send a secure reset link.","forgot_submit_label":"Send reset link","forgot_back_label":"Back to login","forgot_success_title":"Check your email","forgot_success_description":"If this email is registered with KKCC, a password reset link has been sent.","reset_title":"Set a new password","reset_description":"Choose a strong password to continue your KKCC learning journey.","reset_submit_label":"Update password","reset_success_title":"Password updated","reset_success_description":"You can now sign in with your new password."},"dashboard":{"welcome_eyebrow":"Welcome back","welcome_title":"Your learning today","student_section_label":"Student Section","student_profile_title":"Profile & batch validity","student_profile_description":"View your profile, enrolled batches/courses, payment source, and remaining validity in one place.","active_batches_title":"My active batches","no_active_batch_title":"No active batch right now","no_active_batch_description":"Start a free batch or contact KKCC support to activate paid/offline access.","browse_courses_label":"Explore courses","support_cta_title":"Need access extension?","support_cta_description":"If your validity is about to expire, send a message from the Support page for renewal help.","support_cta_label":"Contact support"},"system":{"not_found_title":"Page not found","not_found_description":"The page you're looking for doesn't exist or has been moved.","not_found_home_label":"Go home","error_title":"This page didn't load","error_description":"Something went wrong on our end. You can try refreshing or head back home.","error_retry_label":"Try again","error_home_label":"Go home","install_title":"Install KKCC for a faster app feel","install_chrome_description":"Add it from Chrome to open full screen, launch quickly, and keep core files cached.","install_ios_description":"On iPhone or iPad, open the browser share menu and choose Add to Home Screen.","install_button_label":"Install app","offline_title":"You are offline","offline_description":"KKCC is ready to continue when your connection returns. Some recently opened pages and app files may still work from cache.","offline_retry_label":"Try again"}}$kkcc_ui_text$)
ON CONFLICT (key) DO NOTHING;

-- Migration: 20260929090000_lecture_linked_materials_and_tests.sql
-- KKCC lecture-linked study packs + optional paid notes
-- Run this after the previous KKCC migrations. It is additive and non-destructive.

ALTER TABLE public.materials
  ADD COLUMN IF NOT EXISTS lecture_id uuid REFERENCES public.lectures(id) ON DELETE SET NULL;

ALTER TABLE public.materials
  ADD COLUMN IF NOT EXISTS access_type text NOT NULL DEFAULT 'course';

ALTER TABLE public.materials
  ADD COLUMN IF NOT EXISTS price integer NOT NULL DEFAULT 0;

ALTER TABLE public.tests
  ADD COLUMN IF NOT EXISTS lecture_id uuid REFERENCES public.lectures(id) ON DELETE SET NULL;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'materials_access_type_check'
      AND conrelid = 'public.materials'::regclass
  ) THEN
    ALTER TABLE public.materials
      ADD CONSTRAINT materials_access_type_check
      CHECK (access_type IN ('course', 'free', 'paid'));
  END IF;

  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'materials_price_check'
      AND conrelid = 'public.materials'::regclass
  ) THEN
    ALTER TABLE public.materials
      ADD CONSTRAINT materials_price_check
      CHECK (price >= 0);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_materials_lecture ON public.materials(lecture_id, sort_order);
CREATE INDEX IF NOT EXISTS idx_materials_access_type ON public.materials(access_type, price);
CREATE INDEX IF NOT EXISTS idx_tests_lecture ON public.tests(lecture_id, sort_order);

COMMENT ON COLUMN public.materials.lecture_id IS 'Optional lecture this note/PDF/resource is attached to.';
COMMENT ON COLUMN public.materials.access_type IS 'course = included with course access, free = open/free note, paid = standalone paid note.';
COMMENT ON COLUMN public.materials.price IS 'Standalone material price in INR paise-free whole rupees for KKCC admin UI.';
COMMENT ON COLUMN public.tests.lecture_id IS 'Optional lecture this test/practice set is attached to.';

-- Migration: 20260929100000_student_blocks_and_secure_video.sql
-- KKCC student app block/unblock security
-- Additive and non-destructive. Students cannot remove their own block.

CREATE TABLE IF NOT EXISTS public.student_blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  is_active boolean NOT NULL DEFAULT true,
  reason text NOT NULL DEFAULT '',
  blocked_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  blocked_at timestamptz NOT NULL DEFAULT now(),
  unblocked_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  unblocked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id)
);

ALTER TABLE public.student_blocks
  ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS reason text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS blocked_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS blocked_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS unblocked_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS unblocked_at timestamptz,
  ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'student_blocks_user_id_key'
      AND conrelid = 'public.student_blocks'::regclass
  ) THEN
    ALTER TABLE public.student_blocks ADD CONSTRAINT student_blocks_user_id_key UNIQUE (user_id);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_student_blocks_active ON public.student_blocks(user_id, is_active);
CREATE INDEX IF NOT EXISTS idx_student_blocks_blocked_at ON public.student_blocks(blocked_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.student_blocks TO authenticated;
GRANT ALL ON public.student_blocks TO service_role;
ALTER TABLE public.student_blocks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own block status" ON public.student_blocks;
CREATE POLICY "Users can view own block status"
  ON public.student_blocks FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admins can view all student blocks" ON public.student_blocks;
CREATE POLICY "Admins can view all student blocks"
  ON public.student_blocks FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins can manage student blocks" ON public.student_blocks;
CREATE POLICY "Admins can manage student blocks"
  ON public.student_blocks FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_student_blocks_updated_at ON public.student_blocks;
CREATE TRIGGER update_student_blocks_updated_at
  BEFORE UPDATE ON public.student_blocks
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.is_user_blocked(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.student_blocks sb
    WHERE sb.user_id = _user_id
      AND sb.is_active = true
  )
$$;

CREATE OR REPLACE FUNCTION public.get_my_block_status()
RETURNS TABLE(is_blocked boolean, reason text, blocked_at timestamptz)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    COALESCE(sb.is_active, false) AS is_blocked,
    COALESCE(sb.reason, '') AS reason,
    sb.blocked_at
  FROM (SELECT auth.uid() AS uid) me
  LEFT JOIN public.student_blocks sb
    ON sb.user_id = me.uid
   AND sb.is_active = true
  LIMIT 1
$$;

REVOKE EXECUTE ON FUNCTION public.is_user_blocked(uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.get_my_block_status() FROM anon, public;
GRANT EXECUTE ON FUNCTION public.is_user_blocked(uuid) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.get_my_block_status() TO authenticated, service_role;

-- Migration: 20260929110000_23kaat_coin_wallet.sql
-- KKCC 23KAAT coin currency wallet
-- 1 coin = ₹1 app credit for KKCC purchases unless admin changes pricing copy later.
-- All grant/spend operations are server-side database functions; students cannot edit their balance.

CREATE TABLE IF NOT EXISTS public.coin_packages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT '23KAAT Coin Pack',
  coins integer NOT NULL DEFAULT 0,
  bonus_coins integer NOT NULL DEFAULT 0,
  price integer NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'INR',
  description text NOT NULL DEFAULT '',
  is_active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (coins >= 0),
  CHECK (bonus_coins >= 0),
  CHECK (price >= 0)
);

CREATE TABLE IF NOT EXISTS public.coin_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount integer NOT NULL,
  source text NOT NULL DEFAULT 'admin_grant',
  reason text NOT NULL DEFAULT '',
  related_type text NOT NULL DEFAULT '',
  related_id uuid,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (amount <> 0)
);

CREATE TABLE IF NOT EXISTS public.material_purchases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  material_id uuid NOT NULL REFERENCES public.materials(id) ON DELETE CASCADE,
  paid_coins integer NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'active',
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, material_id),
  CHECK (paid_coins >= 0)
);

CREATE INDEX IF NOT EXISTS idx_coin_transactions_user ON public.coin_transactions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_coin_transactions_source ON public.coin_transactions(source, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_coin_packages_active ON public.coin_packages(is_active, sort_order);
CREATE INDEX IF NOT EXISTS idx_material_purchases_user ON public.material_purchases(user_id, status);
CREATE INDEX IF NOT EXISTS idx_material_purchases_material ON public.material_purchases(material_id, status);

GRANT SELECT ON public.coin_packages TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.coin_packages TO authenticated;
GRANT SELECT ON public.coin_transactions TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.coin_transactions TO authenticated;
GRANT SELECT ON public.material_purchases TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.material_purchases TO authenticated;
GRANT ALL ON public.coin_packages, public.coin_transactions, public.material_purchases TO service_role;

ALTER TABLE public.coin_packages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.coin_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.material_purchases ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Active coin packages are public" ON public.coin_packages;
CREATE POLICY "Active coin packages are public"
  ON public.coin_packages FOR SELECT
  USING (is_active OR public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins manage coin packages" ON public.coin_packages;
CREATE POLICY "Admins manage coin packages"
  ON public.coin_packages FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Users view own coin transactions" ON public.coin_transactions;
CREATE POLICY "Users view own coin transactions"
  ON public.coin_transactions FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admins view all coin transactions" ON public.coin_transactions;
CREATE POLICY "Admins view all coin transactions"
  ON public.coin_transactions FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins manage coin transactions" ON public.coin_transactions;
CREATE POLICY "Admins manage coin transactions"
  ON public.coin_transactions FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Users view own material purchases" ON public.material_purchases;
CREATE POLICY "Users view own material purchases"
  ON public.material_purchases FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admins view all material purchases" ON public.material_purchases;
CREATE POLICY "Admins view all material purchases"
  ON public.material_purchases FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins manage material purchases" ON public.material_purchases;
CREATE POLICY "Admins manage material purchases"
  ON public.material_purchases FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_coin_packages_updated_at ON public.coin_packages;
CREATE TRIGGER update_coin_packages_updated_at
  BEFORE UPDATE ON public.coin_packages
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

DROP TRIGGER IF EXISTS update_material_purchases_updated_at ON public.material_purchases;
CREATE TRIGGER update_material_purchases_updated_at
  BEFORE UPDATE ON public.material_purchases
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.get_23kaat_balance(_user_id uuid)
RETURNS integer
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(SUM(amount), 0)::integer
  FROM public.coin_transactions
  WHERE user_id = _user_id
$$;