-- KKCC Excellence Hub SQL Part 08 of 9. Run in order.



CREATE OR REPLACE FUNCTION public.get_my_material_access_url(_material_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid uuid := auth.uid();
  material_row public.materials%ROWTYPE;
  course_price integer;
  course_coin_price integer;
  course_cost integer;
  material_cost integer;
  has_course_access boolean;
  has_purchase boolean;
  balance integer;
BEGIN
  IF uid IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'locked', true, 'reason', 'login_required');
  END IF;
  IF public.is_user_blocked(uid) THEN
    RETURN jsonb_build_object('ok', false, 'locked', true, 'reason', 'blocked');
  END IF;

  SELECT * INTO material_row
  FROM public.materials
  WHERE id = _material_id AND is_published = true;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'locked', true, 'reason', 'not_found');
  END IF;

  IF COALESCE(material_row.access_type, 'course') = 'free' THEN
    RETURN jsonb_build_object('ok', true, 'locked', false, 'file_url', material_row.file_url, 'price', 0, 'rupee_price', 0, 'coin_price', 0);
  END IF;

  IF COALESCE(material_row.access_type, 'course') = 'paid' THEN
    material_cost := CASE
      WHEN COALESCE(material_row.price, 0) <= 0 THEN 0
      WHEN COALESCE(material_row.coin_price, 0) > 0 THEN GREATEST(0, material_row.coin_price)
      ELSE GREATEST(0, COALESCE(material_row.price, 0))
    END;

    SELECT EXISTS(
      SELECT 1 FROM public.material_purchases
      WHERE user_id = uid AND material_id = _material_id AND status = 'active'
    ) INTO has_purchase;
    IF has_purchase THEN
      RETURN jsonb_build_object('ok', true, 'locked', false, 'file_url', material_row.file_url, 'price', material_cost, 'rupee_price', COALESCE(material_row.price, 0), 'coin_price', material_cost);
    END IF;
    balance := public.get_23kaat_balance(uid);
    RETURN jsonb_build_object('ok', true, 'locked', true, 'reason', 'paid', 'price', material_cost, 'rupee_price', COALESCE(material_row.price, 0), 'coin_price', material_cost, 'balance', balance);
  END IF;

  IF material_row.course_id IS NULL THEN
    RETURN jsonb_build_object('ok', true, 'locked', false, 'file_url', material_row.file_url, 'price', 0, 'rupee_price', 0, 'coin_price', 0);
  END IF;

  SELECT COALESCE(price, 0), COALESCE(coin_price, 0)
  INTO course_price, course_coin_price
  FROM public.courses
  WHERE id = material_row.course_id AND status = 'published';

  course_cost := CASE
    WHEN COALESCE(course_price, 0) <= 0 THEN 0
    WHEN COALESCE(course_coin_price, 0) > 0 THEN GREATEST(0, course_coin_price)
    ELSE GREATEST(0, COALESCE(course_price, 0))
  END;

  IF COALESCE(course_price, 0) <= 0 THEN
    RETURN jsonb_build_object('ok', true, 'locked', false, 'file_url', material_row.file_url, 'price', 0, 'rupee_price', 0, 'coin_price', 0);
  END IF;

  SELECT EXISTS(
    SELECT 1 FROM public.course_enrollments
    WHERE user_id = uid AND course_id = material_row.course_id AND status = 'active'
      AND (expires_at IS NULL OR expires_at > now())
  ) INTO has_course_access;

  IF has_course_access THEN
    RETURN jsonb_build_object('ok', true, 'locked', false, 'file_url', material_row.file_url, 'price', 0, 'rupee_price', 0, 'coin_price', 0);
  END IF;

  RETURN jsonb_build_object('ok', true, 'locked', true, 'reason', 'course_required', 'price', course_cost, 'rupee_price', course_price, 'coin_price', course_cost, 'balance', public.get_23kaat_balance(uid));
END;
$$;

CREATE OR REPLACE FUNCTION public.spend_23kaat_for_material(_material_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid uuid := auth.uid();
  material_row public.materials%ROWTYPE;
  current_balance integer;
  cost integer;
BEGIN
  IF uid IS NULL THEN
    RAISE EXCEPTION 'Login required';
  END IF;
  IF public.is_user_blocked(uid) THEN
    RAISE EXCEPTION 'Account blocked by admin';
  END IF;

  SELECT * INTO material_row
  FROM public.materials
  WHERE id = _material_id AND is_published = true;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Material not found';
  END IF;

  IF COALESCE(material_row.access_type, 'course') <> 'paid' THEN
    RETURN public.get_my_material_access_url(_material_id);
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.material_purchases
    WHERE user_id = uid AND material_id = _material_id AND status = 'active'
  ) THEN
    RETURN jsonb_build_object('ok', true, 'already_owned', true, 'file_url', material_row.file_url, 'balance', public.get_23kaat_balance(uid));
  END IF;

  cost := CASE
    WHEN COALESCE(material_row.price, 0) <= 0 THEN 0
    WHEN COALESCE(material_row.coin_price, 0) > 0 THEN GREATEST(0, material_row.coin_price)
    ELSE GREATEST(0, COALESCE(material_row.price, 0))
  END;

  IF cost <= 0 THEN
    INSERT INTO public.material_purchases(user_id, material_id, paid_coins, status, created_by)
    VALUES (uid, _material_id, 0, 'active', uid)
    ON CONFLICT (user_id, material_id) DO UPDATE SET status = 'active', updated_at = now();
    RETURN jsonb_build_object('ok', true, 'free', true, 'spent', 0, 'price', 0, 'rupee_price', COALESCE(material_row.price, 0), 'coin_price', 0, 'file_url', material_row.file_url, 'balance', public.get_23kaat_balance(uid));
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext(uid::text));
  current_balance := public.get_23kaat_balance(uid);
  IF current_balance < cost THEN
    RAISE EXCEPTION 'Not enough 23KAAT coins. Need %, available %.', cost, current_balance;
  END IF;

  INSERT INTO public.coin_transactions(user_id, amount, source, reason, related_type, related_id, created_by)
  VALUES (uid, -cost, 'material_purchase', 'Notes/material purchase: ' || material_row.title, 'material', _material_id, uid);

  INSERT INTO public.material_purchases(user_id, material_id, paid_coins, status, created_by)
  VALUES (uid, _material_id, cost, 'active', uid)
  ON CONFLICT (user_id, material_id) DO UPDATE SET
    paid_coins = EXCLUDED.paid_coins,
    status = 'active',
    updated_at = now();

  RETURN jsonb_build_object('ok', true, 'spent', cost, 'price', cost, 'rupee_price', COALESCE(material_row.price, 0), 'coin_price', cost, 'file_url', material_row.file_url, 'balance', public.get_23kaat_balance(uid));
END;
$$;

REVOKE EXECUTE ON FUNCTION public.spend_23kaat_for_course(uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.get_my_material_access_url(uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.spend_23kaat_for_material(uuid) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.spend_23kaat_for_course(uuid) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.get_my_material_access_url(uuid) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.spend_23kaat_for_material(uuid) TO authenticated, service_role;

-- ============================================================================
-- 20260929140000_test_question_timer_and_ai_drafts.sql
-- ============================================================================
-- Per-test question timer controls for admin-created tests.

ALTER TABLE public.tests
  ADD COLUMN IF NOT EXISTS question_timer_seconds integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS timer_mode text NOT NULL DEFAULT 'test';

ALTER TABLE public.tests
  DROP CONSTRAINT IF EXISTS tests_timer_mode_check;
ALTER TABLE public.tests
  ADD CONSTRAINT tests_timer_mode_check CHECK (timer_mode IN ('test', 'question', 'unlimited'));

ALTER TABLE public.tests
  DROP CONSTRAINT IF EXISTS tests_question_timer_seconds_check;
ALTER TABLE public.tests
  ADD CONSTRAINT tests_question_timer_seconds_check CHECK (question_timer_seconds >= 0 AND question_timer_seconds <= 7200);

COMMENT ON COLUMN public.tests.question_timer_seconds IS 'Per-question timer in seconds when timer_mode is question. 0 means no per-question limit.';
COMMENT ON COLUMN public.tests.timer_mode IS 'test = normal whole-test timer, question = per-question timer, unlimited = no timer; next question appears when student clicks Next.';

-- ============================================================================
-- ============================================================================
-- ============================================================================
-- ============================================================================
-- 20260929150000_security_app_controls_and_health.sql
-- ============================================================================
-- KKCC security/app controls and admin system health.
-- Safe additive migration: no student, course, wallet, storage or payment data is changed.
-- Run this file once in Supabase SQL Editor after the earlier KKCC migrations.

-- Public-safe app flags. Admin writes through existing site_settings RLS admin policies.
INSERT INTO public.site_settings (key, value) VALUES
  ('app_maintenance_mode', 'false'),
  ('app_maintenance_message', 'KKCC learning services are temporarily being refreshed. Please check back shortly.'),
  ('security_protection_enabled', 'true'),
  ('security_copy_guard_enabled', 'true'),
  ('security_context_menu_guard_enabled', 'true'),
  ('security_shortcut_guard_enabled', 'true'),
  ('security_watermark_enabled', 'true'),
  ('security_screenshot_blur_enabled', 'true'),
  ('security_print_guard_enabled', 'true'),
  ('feature_kittu_quiz_enabled', 'true'),
  ('feature_test_series_enabled', 'true'),
  ('feature_study_material_enabled', 'true'),
  ('kittu_daily_reward_cap', '160'),
  ('kittu_daily_practice_hours', '8'),
  ('kittu_daily_gift', '5'),
  ('kittu_practice_batches', '[]')
ON CONFLICT (key) DO NOTHING;

-- Refresh the earlier placeholder-style offline payment instruction only when it is
-- still the exact old default; admin-edited custom text is preserved.
UPDATE public.site_settings
SET value = 'Use the KKCC inquiry flow for UPI, cash or bank-transfer access. Course access is activated after the KKCC team confirms the payment.', updated_at = now()
WHERE key = 'offline_payment_instructions'
  AND value = 'Contact admin for UPI/cash/bank-transfer access. After payment, admin will unlock your course.';

-- Refresh old auto-default UI text in saved public JSON. Exact placeholder sentences only;
-- custom admin edits remain untouched.
UPDATE public.site_settings
SET value = replace(
    replace(
      value,
      'Start a free batch or ask admin to activate access after paid/offline payment.',
      'Start a free batch or contact KKCC support to activate paid/offline access.'
    ),
    'If your validity is about to expire, send a message from the Support page or contact admin.',
    'If your validity is about to expire, send a message from the Support page for renewal help.'
  ),
  updated_at = now()
WHERE key = 'ui_text_json'
  AND (
    value LIKE '%Start a free batch or ask admin to activate access after paid/offline payment.%'
    OR value LIKE '%If your validity is about to expire, send a message from the Support page or contact admin.%'
  );

-- Compact, read-only health metrics for admins. This exposes no emails, user IDs,
-- secrets, file URLs, payment keys, student personal data or quiz progress.
CREATE OR REPLACE FUNCTION public.get_kkcc_admin_system_health()
RETURNS TABLE (area text, label text, value text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_catalog
AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Forbidden — admin access required';
  END IF;

  RETURN QUERY
    SELECT
      'database'::text AS area,
      'database used'::text AS label,
      pg_size_pretty(pg_database_size(current_database()))::text AS value
    UNION ALL
    SELECT 'database', 'students', count(*)::text FROM public.profiles
    UNION ALL
    SELECT 'database', 'courses', count(*)::text FROM public.courses
    UNION ALL
    SELECT 'database', 'lectures', count(*)::text FROM public.lectures
    UNION ALL
    SELECT 'database', 'materials', count(*)::text FROM public.materials
    UNION ALL
    SELECT 'database', 'tests', count(*)::text FROM public.tests
    UNION ALL
    SELECT 'database', 'question rows', count(*)::text FROM public.test_questions
    UNION ALL
    SELECT 'database', 'enrollments', count(*)::text FROM public.course_enrollments
    UNION ALL
    SELECT 'database', 'file metadata rows', count(*)::text FROM public.files
    UNION ALL
    SELECT 'database', 'coin packages', count(*)::text FROM public.coin_packages
    UNION ALL
    SELECT 'database', 'coin transactions', count(*)::text FROM public.coin_transactions
    UNION ALL
    SELECT 'database', 'notifications', count(*)::text FROM public.notifications
    UNION ALL
    SELECT 'database', 'student doubts', count(*)::text FROM public.student_doubts
    UNION ALL
    SELECT 'database', 'admission enquiries', count(*)::text FROM public.admission_enquiries
    UNION ALL
    SELECT 'database', 'payment transactions', count(*)::text FROM public.payment_transactions
    UNION ALL
    SELECT 'database', 'settings rows', count(*)::text FROM public.site_settings
    UNION ALL
    SELECT 'largest tables', 'courses size', pg_size_pretty(pg_total_relation_size('public.courses'))
    UNION ALL
    SELECT 'largest tables', 'lectures size', pg_size_pretty(pg_total_relation_size('public.lectures'))
    UNION ALL
    SELECT 'largest tables', 'materials size', pg_size_pretty(pg_total_relation_size('public.materials'))
    UNION ALL
    SELECT 'largest tables', 'tests size', pg_size_pretty(pg_total_relation_size('public.tests'))
    UNION ALL
    SELECT 'largest tables', 'test questions size', pg_size_pretty(pg_total_relation_size('public.test_questions'))
    UNION ALL
    SELECT 'largest tables', 'files metadata size', pg_size_pretty(pg_total_relation_size('public.files'))
    UNION ALL
    SELECT 'storage', 'storage objects row', count(*)::text FROM storage.objects
    UNION ALL
    SELECT 'free-plan', 'database shared budget', '500 MB on Supabase Free'
    UNION ALL
    SELECT 'free-plan', 'storage shared budget', '1 GB file storage on Supabase Free'
    UNION ALL
    SELECT 'recommendation', 'large media', 'Keep videos on YouTube; move large files to external storage before storage quota is near.'
    UNION ALL
    SELECT 'recommendation', 'Kit 2 Coins Quiz data', 'Browser-local rewards and recent-question signatures do not use Supabase storage.';
END;
$$;

REVOKE ALL ON FUNCTION public.get_kkcc_admin_system_health() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_kkcc_admin_system_health() TO authenticated;

COMMENT ON FUNCTION public.get_kkcc_admin_system_health() IS
  'Admin-only read-only KKCC platform health summary. Returns counts and sizes only; never secrets, PII, URLs, or quiz progress.';

-- ============================================================================
-- 20260930103000_secure_course_media_and_upload_limit.sql
-- ============================================================================
-- KKCC paid-course media hardening and scanned-PDF upload limit alignment.
-- Safe update: no student, course, wallet, payment or storage object data is changed.

-- Let policies check the signed-in student's active, unexpired course entitlement
-- without exposing other students' enrollment data through function arguments.
CREATE OR REPLACE FUNCTION public.can_access_my_course(_course_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_catalog
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.courses c
    WHERE c.id = _course_id
      AND c.status = 'published'
      AND COALESCE(c.price, 0) <= 0
  )
  OR EXISTS (
    SELECT 1
    FROM public.course_enrollments e
    WHERE e.user_id = auth.uid()
      AND e.course_id = _course_id
      AND e.status = 'active'
      AND (e.expires_at IS NULL OR e.expires_at > now())
  );
$$;

REVOKE ALL ON FUNCTION public.can_access_my_course(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.can_access_my_course(uuid) TO anon, authenticated;

COMMENT ON FUNCTION public.can_access_my_course(uuid) IS
  'Returns whether the current signed-in user can read all lectures for a course: free courses, or an active unexpired enrolment. No PII or arbitrary user lookup is exposed.';

-- Close the direct anonymous/public API loophole for paid non-preview lecture video URLs.
-- Public users still receive free-course lectures and admin-marked free previews;
-- enrolled students receive their full course lecture deck; admins keep full access
-- through the existing admin lecture policies.
DROP POLICY IF EXISTS "Lectures of published courses are viewable by everyone" ON public.lectures;
CREATE POLICY "Lectures of published courses are viewable by everyone"
  ON public.lectures FOR SELECT
  USING (
    EXISTS (
      SELECT 1
      FROM public.courses c
      WHERE c.id = lectures.course_id
        AND c.status = 'published'
        AND (
          COALESCE(c.price, 0) <= 0
          OR lectures.is_free = true
          OR public.can_access_my_course(lectures.course_id)
        )
    )
  );

-- Keep uploaded scanned notes aligned with the app's 45 MB guidance and the Free
-- plan's practical single-file ceiling. Existing objects are untouched.
UPDATE storage.buckets
SET file_size_limit = 47185920
WHERE id = 'course-content';

-- Do not let an anonymous caller mint fresh signed URLs merely because an object
-- path leaks. Stored signed URLs already granted by admins continue to be used by
-- the app's material-access flow; administrators retain full storage management.
DROP POLICY IF EXISTS "Course content is readable" ON storage.objects;
CREATE POLICY "Admins read course content"
  ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'course-content' AND public.has_role(auth.uid(), 'admin'));

-- ============================================================================
-- 20260930110000_mask_private_material_urls.sql
-- ============================================================================
-- KKCC private material URL masking hardening.
-- Safe update: no student, course, wallet, payment, material or storage object data is changed.
--
-- What this closes:
--   Direct anonymous/PostgREST reads of published materials can no longer download rows
--   containing a paid/course-included private file_url merely because the material metadata
--   is visible in the public app. Public metadata is still available through a masked RPC;