-- KKCC Excellence Hub SQL Part 02 of 9. Run in order.



-- 3) Public/admin editable settings -----------------------------------------
CREATE TABLE IF NOT EXISTS public.site_settings (
  key text PRIMARY KEY,
  value text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.site_settings TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.site_settings TO authenticated;
GRANT ALL ON public.site_settings TO service_role;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Site settings are readable by everyone" ON public.site_settings;
CREATE POLICY "Site settings are readable by everyone"
  ON public.site_settings FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Admins can manage site settings" ON public.site_settings;
CREATE POLICY "Admins can manage site settings"
  ON public.site_settings FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_site_settings_updated_at ON public.site_settings;
CREATE TRIGGER update_site_settings_updated_at
  BEFORE UPDATE ON public.site_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.site_settings (key, value) VALUES
  ('social_youtube', ''),
  ('social_instagram', ''),
  ('social_facebook', ''),
  ('social_telegram', ''),
  ('social_whatsapp', ''),
  ('social_links_json', ''),
  ('app_builder_json', ''),
  ('brand_app_name', 'Kusum Kartik Coaching Centre'),
  ('brand_short_name', 'KKCC'),
  ('brand_tagline', 'Learn Better. Understand Deeper. Achieve More.'),
  ('brand_logo_url', '/logo.png'),
  ('brand_logo_alt', 'KKCC logo'),
  ('brand_show_logo_text', 'true'),
  ('brand_primary_color', '#18f4d6'),
  ('brand_accent_color', '#f5d78e'),
  ('brand_background_color', '#050605'),
  ('brand_foreground_color', '#fff8e7'),
  ('brand_hero_eyebrow', 'Learn Better. Understand Deeper. Achieve More.'),
  ('brand_hero_title', 'KKCC Excellence Hub — Study That Makes You Return.'),
  ('brand_hero_highlight', 'Learn with clarity. Practice with courage. Rise with confidence.'),
  ('brand_hero_description', 'KKCC turns lectures, notes, tests, and progress into a bright daily learning loop — so students know exactly what to open next and feel excited to continue.'),
  ('brand_cta_primary_label', 'Find My Next Win'),
  ('brand_cta_secondary_label', 'Continue Learning'),
  ('website_content_json', ''),
  ('payment_provider', 'razorpay'),
  ('payment_enabled', 'false'),
  ('payment_mode', 'test'),
  ('razorpay_key_id', ''),
  ('offline_payment_instructions', 'Use the KKCC inquiry flow for UPI, cash or bank-transfer access. Course access is activated after the KKCC team confirms the payment.'),
  ('storage_provider', 'supabase'),
  ('storage_bucket', 'course-content'),
  ('storage_region', ''),
  ('storage_endpoint', ''),
  ('storage_public_base_url', ''),
  ('storage_migration_status', 'idle')
ON CONFLICT (key) DO NOTHING;

-- 4) Profiles / auth trigger / owner admin ----------------------------------
CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL DEFAULT '',
  full_name text NOT NULL DEFAULT '',
  mobile text NOT NULL DEFAULT '',
  class_level text NOT NULL DEFAULT '',
  target_exam text NOT NULL DEFAULT '',
  avatar_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS email text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS full_name text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS mobile text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS class_level text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS target_exam text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS avatar_url text,
  ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

CREATE INDEX IF NOT EXISTS idx_profiles_email ON public.profiles (lower(email));

GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
CREATE POLICY "Users can view own profile"
  ON public.profiles FOR SELECT TO authenticated
  USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can insert own profile" ON public.profiles;
CREATE POLICY "Users can insert own profile"
  ON public.profiles FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "Admins can view all profiles" ON public.profiles;
CREATE POLICY "Admins can view all profiles"
  ON public.profiles FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_profiles_updated_at ON public.profiles;
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.handle_new_user_profile()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, mobile, class_level, target_exam)
  VALUES (
    NEW.id,
    COALESCE(NEW.email, ''),
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', NEW.raw_user_meta_data ->> 'name', ''),
    COALESCE(NEW.raw_user_meta_data ->> 'mobile', ''),
    COALESCE(NEW.raw_user_meta_data ->> 'class_level', ''),
    COALESCE(NEW.raw_user_meta_data ->> 'target_exam', '')
  )
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    full_name = COALESCE(NULLIF(EXCLUDED.full_name, ''), public.profiles.full_name),
    mobile = COALESCE(NULLIF(EXCLUDED.mobile, ''), public.profiles.mobile),
    class_level = COALESCE(NULLIF(EXCLUDED.class_level, ''), public.profiles.class_level),
    target_exam = COALESCE(NULLIF(EXCLUDED.target_exam, ''), public.profiles.target_exam),
    updated_at = now();

  IF lower(COALESCE(NEW.email, '')) = 'kkcc23102003@gmail.com' THEN
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created_profile ON auth.users;
CREATE TRIGGER on_auth_user_created_profile
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user_profile();

INSERT INTO public.profiles (id, email, full_name, mobile, class_level, target_exam)
SELECT
  u.id,
  COALESCE(u.email, ''),
  COALESCE(u.raw_user_meta_data ->> 'full_name', u.raw_user_meta_data ->> 'name', ''),
  COALESCE(u.raw_user_meta_data ->> 'mobile', ''),
  COALESCE(u.raw_user_meta_data ->> 'class_level', ''),
  COALESCE(u.raw_user_meta_data ->> 'target_exam', '')
FROM auth.users u
ON CONFLICT (id) DO UPDATE SET
  email = EXCLUDED.email,
  full_name = COALESCE(NULLIF(EXCLUDED.full_name, ''), public.profiles.full_name),
  mobile = COALESCE(NULLIF(EXCLUDED.mobile, ''), public.profiles.mobile),
  class_level = COALESCE(NULLIF(EXCLUDED.class_level, ''), public.profiles.class_level),
  target_exam = COALESCE(NULLIF(EXCLUDED.target_exam, ''), public.profiles.target_exam),
  updated_at = now();

INSERT INTO public.user_roles (user_id, role)
SELECT id, 'admin'::public.app_role
FROM auth.users
WHERE lower(email) = 'kkcc23102003@gmail.com'
ON CONFLICT (user_id, role) DO NOTHING;

-- Disable legacy first-user admin claim.
CREATE OR REPLACE FUNCTION public.claim_admin()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RAISE EXCEPTION 'Admin claiming is disabled. Assign admins in public.user_roles from Supabase/Admin panel.';
END;
$$;

REVOKE EXECUTE ON FUNCTION public.claim_admin() FROM anon, public, authenticated;
GRANT EXECUTE ON FUNCTION public.claim_admin() TO service_role;

-- 5) Storage bucket / upload policies ---------------------------------------
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('course-content', 'course-content', false, 209715200, NULL)
ON CONFLICT (id) DO UPDATE SET
  public = EXCLUDED.public,
  file_size_limit = EXCLUDED.file_size_limit,
  allowed_mime_types = EXCLUDED.allowed_mime_types;

DROP POLICY IF EXISTS "Course content is readable" ON storage.objects;
CREATE POLICY "Course content is readable"
  ON storage.objects FOR SELECT TO anon, authenticated
  USING (bucket_id = 'course-content');

DROP POLICY IF EXISTS "Admins upload course content" ON storage.objects;
CREATE POLICY "Admins upload course content"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'course-content' AND public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins update course content" ON storage.objects;
CREATE POLICY "Admins update course content"
  ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'course-content' AND public.has_role(auth.uid(), 'admin'))
  WITH CHECK (bucket_id = 'course-content' AND public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins delete course content" ON storage.objects;
CREATE POLICY "Admins delete course content"
  ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'course-content' AND public.has_role(auth.uid(), 'admin'));

-- 6) Enrolments / files / private settings / payments -----------------------
CREATE TABLE IF NOT EXISTS public.course_enrollments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  course_id uuid NOT NULL REFERENCES public.courses(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'active',
  source text NOT NULL DEFAULT 'manual',
  payment_method text NOT NULL DEFAULT 'manual',
  amount_paid integer NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'INR',
  admin_note text NOT NULL DEFAULT '',
  expires_at timestamptz,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, course_id)
);

CREATE INDEX IF NOT EXISTS idx_course_enrollments_user ON public.course_enrollments(user_id, status);
CREATE INDEX IF NOT EXISTS idx_course_enrollments_course ON public.course_enrollments(course_id, status);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.course_enrollments TO authenticated;
GRANT ALL ON public.course_enrollments TO service_role;
ALTER TABLE public.course_enrollments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own enrollments" ON public.course_enrollments;
CREATE POLICY "Users can view own enrollments"
  ON public.course_enrollments FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admins can view all enrollments" ON public.course_enrollments;
CREATE POLICY "Admins can view all enrollments"
  ON public.course_enrollments FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Users can claim free published enrollments" ON public.course_enrollments;
CREATE POLICY "Users can claim free published enrollments"
  ON public.course_enrollments FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = user_id
    AND source = 'free'
    AND amount_paid = 0
    AND EXISTS (
      SELECT 1 FROM public.courses c
      WHERE c.id = course_enrollments.course_id
        AND c.status = 'published'
        AND c.price = 0
    )
  );

DROP POLICY IF EXISTS "Admins can manage enrollments" ON public.course_enrollments;
CREATE POLICY "Admins can manage enrollments"
  ON public.course_enrollments FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_course_enrollments_updated_at ON public.course_enrollments;
CREATE TRIGGER update_course_enrollments_updated_at
  BEFORE UPDATE ON public.course_enrollments
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE IF NOT EXISTS public.files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider text NOT NULL DEFAULT 'supabase',
  bucket text NOT NULL DEFAULT 'course-content',
  path text NOT NULL,
  public_url text NOT NULL DEFAULT '',
  original_url text NOT NULL DEFAULT '',
  mime_type text NOT NULL DEFAULT '',
  size_bytes bigint NOT NULL DEFAULT 0,
  linked_table text NOT NULL DEFAULT '',
  linked_id uuid,
  migration_status text NOT NULL DEFAULT 'active',
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_files_provider ON public.files(provider, migration_status);
CREATE INDEX IF NOT EXISTS idx_files_linked ON public.files(linked_table, linked_id);

GRANT SELECT ON public.files TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.files TO authenticated;
GRANT ALL ON public.files TO service_role;
ALTER TABLE public.files ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Published file metadata is readable" ON public.files;
CREATE POLICY "Published file metadata is readable"
  ON public.files FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Admins can manage file metadata" ON public.files;
CREATE POLICY "Admins can manage file metadata"
  ON public.files FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_files_updated_at ON public.files;
CREATE TRIGGER update_files_updated_at
  BEFORE UPDATE ON public.files
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE IF NOT EXISTS public.private_settings (
  key text PRIMARY KEY,
  value text NOT NULL DEFAULT '',
  updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.private_settings TO authenticated;
GRANT ALL ON public.private_settings TO service_role;
ALTER TABLE public.private_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Admins can manage private settings" ON public.private_settings;
CREATE POLICY "Admins can manage private settings"
  ON public.private_settings FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS update_private_settings_updated_at ON public.private_settings;
CREATE TRIGGER update_private_settings_updated_at
  BEFORE UPDATE ON public.private_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();