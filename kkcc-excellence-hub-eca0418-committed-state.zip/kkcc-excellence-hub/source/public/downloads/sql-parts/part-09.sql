-- KKCC Excellence Hub SQL Part 09 of 9. Run in order.


--   entitled users receive the real URL through the existing authenticated access RPC.

-- Keep blocked students from continuing to use access that was granted before they were blocked.
CREATE OR REPLACE FUNCTION public.can_access_my_course(_course_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_catalog
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.courses c
    WHERE c.id = _course_id
      AND c.status = 'published'
      AND COALESCE(c.price, 0) <= 0
  )
  OR (
    auth.uid() IS NOT NULL
    AND EXISTS (
      SELECT 1
      FROM public.course_enrollments e
      WHERE e.user_id = auth.uid()
        AND e.course_id = _course_id
        AND e.status = 'active'
        AND (e.expires_at IS NULL OR e.expires_at > now())
    )
    AND NOT EXISTS (
      SELECT 1
      FROM public.student_blocks sb
      WHERE sb.user_id = auth.uid()
        AND sb.is_active = true
    )
  );
$$;

REVOKE ALL ON FUNCTION public.can_access_my_course(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.can_access_my_course(uuid) TO anon, authenticated;

COMMENT ON FUNCTION public.can_access_my_course(uuid) IS
  'Returns whether the current caller can read a full course deck: open published course, or active unexpired enrolment and no active student block.';

-- The helper only answers about the current caller. It cannot be used to inspect
-- another student's purchases and it returns false for blocked students.
CREATE OR REPLACE FUNCTION public.has_my_material_purchase(_material_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_catalog
AS $$
  SELECT auth.uid() IS NOT NULL
    AND EXISTS (
      SELECT 1
      FROM public.material_purchases mp
      WHERE mp.user_id = auth.uid()
        AND mp.material_id = _material_id
        AND mp.status = 'active'
    )
    AND NOT EXISTS (
      SELECT 1
      FROM public.student_blocks sb
      WHERE sb.user_id = auth.uid()
        AND sb.is_active = true
    );
$$;

REVOKE ALL ON FUNCTION public.has_my_material_purchase(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.has_my_material_purchase(uuid) TO anon, authenticated;

COMMENT ON FUNCTION public.has_my_material_purchase(uuid) IS
  'True only when the current unblocked authenticated caller has an active purchase for the given material.';

-- Hide private material rows from ordinary direct table reads. Public free items stay
-- visible, entitled students can read their own unlocked rows, and admins keep the
-- existing separate all-materials/admin policies.
DROP POLICY IF EXISTS "Published materials are viewable by everyone" ON public.materials;
CREATE POLICY "Published free and entitled materials are viewable"
  ON public.materials FOR SELECT
  USING (
    is_published
    AND (
      course_id IS NULL
      OR EXISTS (
        SELECT 1
        FROM public.courses c
        WHERE c.id = course_id
          AND c.status = 'published'
      )
    )
    AND (
      COALESCE(access_type, 'course') = 'free'
      OR (course_id IS NULL AND COALESCE(access_type, 'course') <> 'paid')
      OR public.can_access_my_course(course_id)
      OR (
        COALESCE(access_type, 'course') = 'paid'
        AND public.has_my_material_purchase(id)
      )
    )
  );

-- Public metadata listing: every published material/title/price remains discoverable,
-- but private file URLs are replaced with NULL unless the caller is entitled.
-- This keeps the paid-notes shop/buy buttons usable without exposing source URLs.
CREATE OR REPLACE FUNCTION public.list_public_materials(_course_id uuid DEFAULT NULL)
RETURNS TABLE (
  id uuid,
  course_id uuid,
  lecture_id uuid,
  title text,
  material_type text,
  subject text,
  chapter text,
  class_level text,
  pages integer,
  file_url text,
  is_published boolean,
  sort_order integer,
  description text,
  thumbnail_url text,
  module_title text,
  batch text,
  access_type text,
  price integer,
  coin_price integer,
  created_at timestamptz,
  updated_at timestamptz
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_catalog
AS $$
  SELECT
    m.id,
    m.course_id,
    m.lecture_id,
    m.title,
    m.material_type,
    m.subject,
    m.chapter,
    m.class_level,
    m.pages,
    CASE
      WHEN COALESCE(m.access_type, 'course') = 'free'
        OR (m.course_id IS NULL AND COALESCE(m.access_type, 'course') <> 'paid')
        OR public.can_access_my_course(m.course_id)
        OR (
          COALESCE(m.access_type, 'course') = 'paid'
          AND public.has_my_material_purchase(m.id)
        )
      THEN m.file_url
      ELSE NULL
    END AS file_url,
    m.is_published,
    m.sort_order,
    m.description,
    m.thumbnail_url,
    m.module_title,
    m.batch,
    m.access_type,
    m.price,
    m.coin_price,
    m.created_at,
    m.updated_at
  FROM public.materials m
  WHERE m.is_published = true
    AND (_course_id IS NULL OR m.course_id = _course_id)
    AND (
      m.course_id IS NULL
      OR EXISTS (
        SELECT 1
        FROM public.courses c
        WHERE c.id = m.course_id
          AND c.status = 'published'
      )
    )
  ORDER BY m.sort_order ASC, m.created_at DESC;
$$;

REVOKE ALL ON FUNCTION public.list_public_materials(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.list_public_materials(uuid) TO anon, authenticated;

COMMENT ON FUNCTION public.list_public_materials(uuid) IS
  'Returns published material metadata with private file URLs masked to NULL for unauthorized callers.';

-- ============================================================================
-- 20260930120000_paid_test_series_exam_tracks.sql
-- ============================================================================
-- Paid test series support for public.tests.
--
-- Adds the fields the Test section needs to sell a test series and to state,
-- on every single test, which exam that test is oriented for. Rupee and coin
-- pricing sit side by side because students can pay either way.
--
-- Every column is added with IF NOT EXISTS and a safe default, so existing
-- rows stay valid and free tests keep working exactly as before.

alter table public.tests
  add column if not exists exam_track text not null default '',
  add column if not exists level text not null default 'Mixed',
  add column if not exists series_name text not null default '',
  add column if not exists is_paid boolean not null default false,
  add column if not exists price_inr integer not null default 0,
  add column if not exists price_coins integer not null default 0;

-- A test is either free or priced; never a paid test with no price at all.
do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'tests_paid_needs_price'
  ) then
    alter table public.tests
      add constraint tests_paid_needs_price
      check (is_paid = false or price_inr > 0 or price_coins > 0);
  end if;
end $$;

-- Prices can never be negative.
do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'tests_prices_non_negative'
  ) then
    alter table public.tests
      add constraint tests_prices_non_negative
      check (price_inr >= 0 and price_coins >= 0);
  end if;
end $$;

-- Only the three ladder levels, or Mixed for a full-length paper.
do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'tests_level_allowed'
  ) then
    alter table public.tests
      add constraint tests_level_allowed
      check (level in ('Easy', 'Moderate', 'Difficult', 'Mixed'));
  end if;
end $$;

comment on column public.tests.exam_track is
  'Which exam this test is oriented for, shown on the test card.';
comment on column public.tests.level is
  'Easy, Moderate, Difficult or Mixed. Drives the three-level ladder order.';
comment on column public.tests.series_name is
  'Groups tests that belong to the same series.';
comment on column public.tests.is_paid is
  'True when the test needs a purchase before it can be started.';

-- Listing a series is a filter on exam and publication state, so index those.
create index if not exists tests_exam_track_idx
  on public.tests (exam_track)
  where is_published = true;

create index if not exists tests_series_sort_idx
  on public.tests (series_name, sort_order);

-- Column-level grants follow the table grants already in place.
grant select on public.tests to anon;
grant select, insert, update, delete on public.tests to authenticated;


-- ============================================================================
-- 20261001000000_series_test_access_bridge.sql
-- ============================================================================
-- Bridge a paid series grant to the individual tests inside that series.
--
-- A series grant must unlock every published paper whose tests.series_name
-- matches the purchased series id. Existing individual grants continue to work.
-- Expiry is honoured for both grant types.

CREATE OR REPLACE FUNCTION public.has_test_access(p_test_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    COALESCE(
      (
        SELECT NOT t.is_paid
        FROM public.tests t
        WHERE t.id = p_test_id
      ),
      false
    )
    OR EXISTS (
      SELECT 1
      FROM public.test_access_grants g
      WHERE g.test_id = p_test_id
        AND g.user_id = auth.uid()
        AND g.revoked_at IS NULL
        AND (g.expires_at IS NULL OR g.expires_at > now())
    )
    OR EXISTS (
      SELECT 1
      FROM public.tests t
      JOIN public.series_access_grants g
        ON g.series_id = t.series_name
      WHERE t.id = p_test_id
        AND g.user_id = auth.uid()
        AND g.revoked_at IS NULL
        AND (g.expires_at IS NULL OR g.expires_at > now())
    );
$$;

GRANT EXECUTE ON FUNCTION public.has_test_access(uuid) TO authenticated;

COMMENT ON FUNCTION public.has_test_access(uuid) IS
  'A test is open when free, individually granted, or covered by a live grant for its series.';
-- KKCC on-demand deterministic test papers.
--
-- A published generated test stores ONLY its generation recipe. The actual
-- question text/options/explanations are generated in the server request from
-- the local deterministic template bank and are never inserted into
-- public.test_questions.

ALTER TABLE public.tests
  ADD COLUMN IF NOT EXISTS question_source text NOT NULL DEFAULT 'manual',
  ADD COLUMN IF NOT EXISTS generation_exam text NOT NULL DEFAULT 'All Exams',
  ADD COLUMN IF NOT EXISTS generation_subject text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS generation_topic text NOT NULL DEFAULT 'Mixed',
  ADD COLUMN IF NOT EXISTS generation_difficulty text NOT NULL DEFAULT 'Difficult',
  ADD COLUMN IF NOT EXISTS generation_count integer NOT NULL DEFAULT 0;

ALTER TABLE public.tests
  DROP CONSTRAINT IF EXISTS tests_question_source_check;
ALTER TABLE public.tests
  ADD CONSTRAINT tests_question_source_check
  CHECK (question_source IN ('manual', 'deterministic'));

ALTER TABLE public.tests
  DROP CONSTRAINT IF EXISTS tests_generation_difficulty_check;
ALTER TABLE public.tests
  ADD CONSTRAINT tests_generation_difficulty_check
  CHECK (generation_difficulty IN ('Easy', 'Moderate', 'Difficult', 'Mixed'));

ALTER TABLE public.tests
  DROP CONSTRAINT IF EXISTS tests_generation_count_check;
ALTER TABLE public.tests
  ADD CONSTRAINT tests_generation_count_check
  CHECK (generation_count >= 0 AND generation_count <= 1000);

COMMENT ON COLUMN public.tests.question_source IS
  'manual = questions come from public.test_questions; deterministic = fresh questions are generated on demand and are never stored.';
COMMENT ON COLUMN public.tests.generation_exam IS 'Exam filter used by the deterministic question generator.';
COMMENT ON COLUMN public.tests.generation_subject IS 'Subject filter used by the deterministic question generator.';
COMMENT ON COLUMN public.tests.generation_topic IS 'Topic/chapter filter; Mixed means all chapters in the subject.';
COMMENT ON COLUMN public.tests.generation_difficulty IS 'Difficulty layer for generated papers; Mixed splits the requested count across all three levels.';
COMMENT ON COLUMN public.tests.generation_count IS 'Number of fresh questions requested each time the paper is opened.';

-- The current KKCC build intentionally does not use the AI question engine.
-- Keep its legacy tables for compatibility, but make the engine explicitly off.
INSERT INTO public.private_settings(key, value)
VALUES
  ('ai_question_engine_enabled', 'false'),
  ('ai_question_engine_auto_publish', 'false'),
  ('ai_question_engine_google_search', 'false'),
  ('ai_question_engine_gemini_api_key', '')
ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = now();

-- IMPORTANT: Existing manually-authored questions are untouched. When an
-- admin switches a test to deterministic generation through the app, the app
-- removes that test's old test_questions rows before enabling generation so
-- the generated paper has no stored MCQ copies.
