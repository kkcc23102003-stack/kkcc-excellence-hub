-- KKCC Excellence Hub — ADDITIVE SQL for the current test-series/on-demand changes.
-- Run this only after the older KKCC SQL is already installed.
-- Do NOT run the old cleaner or the old combined SQL again.

BEGIN;

-- Whole-series student access. This is required for an enrolled paid series
-- to unlock its chapter tests. NULL expiry means lifetime access.
CREATE TABLE IF NOT EXISTS public.series_access_grants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  series_id text NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  granted_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  method text NOT NULL DEFAULT 'offline',
  amount_inr integer NOT NULL DEFAULT 0,
  note text NOT NULL DEFAULT '',
  expires_at timestamptz,
  revoked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT series_access_grants_series_id_not_blank CHECK (length(btrim(series_id)) > 0),
  CONSTRAINT series_access_grants_amount_sane CHECK (amount_inr BETWEEN 0 AND 1000000)
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_series_access_grants_one_live
  ON public.series_access_grants(series_id, user_id)
  WHERE revoked_at IS NULL;

ALTER TABLE public.series_access_grants ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.series_access_grants TO authenticated;
GRANT ALL ON public.series_access_grants TO service_role;

DROP POLICY IF EXISTS "Students read their own series grants" ON public.series_access_grants;
CREATE POLICY "Students read their own series grants"
  ON public.series_access_grants FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins manage series grants" ON public.series_access_grants;
CREATE POLICY "Admins manage series grants"
  ON public.series_access_grants FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE FUNCTION public.has_series_access(p_series_id text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.series_access_grants g
    WHERE g.series_id = p_series_id
      AND g.user_id = auth.uid()
      AND g.revoked_at IS NULL
      AND (g.expires_at IS NULL OR g.expires_at > now())
  );
$$;
GRANT EXECUTE ON FUNCTION public.has_series_access(text) TO authenticated;

-- Bridge a live series grant to every published paid test in that series.
-- Accept both the stable catalogue id and the human-readable series name.
CREATE OR REPLACE FUNCTION public.has_test_access(p_test_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT
    COALESCE((SELECT NOT t.is_paid FROM public.tests t WHERE t.id = p_test_id), false)
    OR EXISTS (
      SELECT 1 FROM public.test_access_grants g
      WHERE g.test_id = p_test_id
        AND g.user_id = auth.uid()
        AND g.revoked_at IS NULL
        AND (g.expires_at IS NULL OR g.expires_at > now())
    )
    OR EXISTS (
      SELECT 1
      FROM public.tests t
      JOIN public.series_access_grants g
        ON lower(trim(g.series_id)) IN (lower(trim(t.series_name)))
      WHERE t.id = p_test_id
        AND g.user_id = auth.uid()
        AND g.revoked_at IS NULL
        AND (g.expires_at IS NULL OR g.expires_at > now())
    );
$$;
GRANT EXECUTE ON FUNCTION public.has_test_access(uuid) TO authenticated;

COMMIT;

-- NOTE: The new chapter paper itself is generated in the app on demand.
-- Generated question text/options/explanations are NOT inserted into test_questions.
